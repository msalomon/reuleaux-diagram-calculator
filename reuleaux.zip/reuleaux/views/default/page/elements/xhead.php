<?php

/* 
 * audit pugin
 * for transparency & sustainability
 * against neoliberalism theories
 * lisha
 * revision 31.08.2017
 */
?>
<meta name="google-site-verification" content="mPKEYFZFsFUh5C-Wbfsw_PiJO3G9NwyXdf3WB-2MD54" />