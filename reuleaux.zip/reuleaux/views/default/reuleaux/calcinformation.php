<?php
/*
 * reuleaux-diagram calculator 
 * elgg-plugin
 * @purpose transform soziocultur, economy and ecology to sustainability
 * with sustainability metrics that are used in the quality-management system
 * @autor manfred salomon 
 * revision 27.07.2017
 * @link http://reuleaux-calculator.eu
 * 
 * page content
 */

$site_url = elgg_get_site_url();
//$js_url = 'mod/reuleaux/vendors/analyticstracking.js';
//elgg_register_js('analyticstracking', $js_url, 'head', 500);
//elgg_load_js('analyticstracking');
$css_url = 'mod/reuleaux/vendors/bootstrap.min.css';
elgg_register_css('bootstrap', $css_url, 500);
elgg_load_css('bootstrap');

$css_url = 'mod/reuleaux/vendors/style.css';
elgg_register_css('reuleaux_style', $css_url, 500);
elgg_load_css('reuleaux_style');
Global $_COOKIE;
Global $CONFIG;
$dummy = get_language() ;
?>
<!--<script type="text/javascript">
setCookie("language", <?php $dummy ?>  30);
				setCookie("client_language", <?php $dummy ?>  30);
	setCookie("language", <?php $dummy ?>  30);
</script>-->

<?php
//reload_all_translations();
//Global $CONFIG;
//Global $_COOKIE;
//                $_COOKIE['client_language'] = 'en';
////                $_COOKIE->language = 'en';
if (strstr($_SERVER['REDIRECT_URL'],'/en/') || strstr($_SERVER['REDIRECT_URL'],'/de/') || strstr($_SERVER['REDIRECT_URL'],'/fr/') || strstr($_SERVER['REDIRECT_URL'],'/es/') || strstr($_SERVER['REDIRECT_URL'],'/it/') || strstr($_SERVER['REDIRECT_URL'],'/nl/')) {
        $no_flags = True;


}
 else {
    $no_flags = False;     
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script type="text/javascript">


			function setLanguage(lang_id) {
				setCookie("client_language", lang_id, 30);
				document.location.href = document.location.href;			
			}
			function setCookie(c_name,value,expiredays) {
				var exdate = new Date();
				exdate.setDate(exdate.getDate() + expiredays);
				document.cookie = c_name + "=" + escape(value) + ";Path=/" + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
                        }
</script>

<!--<div class="elgg-page-body">
    <div class="elgg-inner">
        <div class="elgg-layout elgg-layout-one-column clearfix">
            <div class="elgg-body elgg-main">-->

<body>
    <div class="container con-des">

     

            <div class="clearfix top-space">
                <div class="row">
                    <div class="col-md-7 col-sm-5 col-xs-8" style="padding-right:0px; color:blue;">
                        <div class="header-text">
                            <span class="clsfontsmall"><?php echo elgg_echo('rel_main_label',$dummy) ?></span><br/>
                            <span class="bold clsfontsmalltext"><?php echo elgg_echo('rel_main_label_sub',$dummy) ?></span>
                        </div>
                    </div>
                    <div class="col-md-5 col-sm-7 col-xs-4">
                        <img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux-diagram-logo.png" alt="calculate sustainability" class="img-responsive logo">
                    </div>	
                </div>
            </div>
                
        <div class="cf-padding">
            <div class="row well well-sm bgbutton panel-padding msg-space">
                <div class="col-xs-7"      style="margin-top: 7px;padding-left:0px"> 
                    <span class="clsfontsmall" style="color: #6168AE;"><strong><?php echo elgg_echo('rel_main_label_information',$dummy) ?></strong></span>
                    <!--<button type="button" class="btn btn-primary active btn-prozent">Prozent</button>-->
                </div>  
                <div class="col-md-1 col-xs-5 col-sm-6 btn-padding"><a id="btn_zurück"  type="button" href="<?php echo $site_url ?>rate" target="_self" class="btn btn-primary btn-punkte"><?php echo elgg_echo('rel_btn_back',$dummy) ?></a>
                </div>

            </div></div>
        <div class="cf-padding">
            <div class="col-md-12 text text-scroll " style="padding-right:5px; color:blue; font-size: 13px;">
                <?php
                switch (get_language()) {
                        case 'de':
                                ?>                                                            
                                Der Reuleaux-Diagramm Rechner berechnet die Nachhaltigkeit und ein Rating, basierend auf dem <a href="https://de.wikipedia.org/wiki/Drei-S%C3%A4ulen-Modell_(Nachhaltigkeit)" target="_blank"> Drei-Säulen-Modell der Nachhaltigkeit</a>, kann aber auch als "Konsens-Meter" für andere Zwecke hilfreich sein.</a>
                                <div style="height:4px;"></div>
                                Der Reuleaux-Diagramm Rechner berechnet die Schnittfläche von drei Kreis-Entitäten, deren Mittelpunkt auf jeweils einer Spitze eines gleichseitigen Dreiecks liegt und deren maximaler Radius der Seite des gleichseitigen Dreiecks entspricht.
                                <div style="height:4px;"></div>
                                Hier konkret, die Bereiche/Entitäten des       
                                <a href="https://de.wikipedia.org/wiki/Drei-S%C3%A4ulen-Modell_(Nachhaltigkeit)" target="_blank"> Drei-Säulen-Modells der Nachhaltigkeit: Soziokultur (Mensch/Gesellschaft), Ökologie (Umwelt), Ökonomie (Wirtschaft).</a>
                                <div style="height:4px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagram-of-sustainability_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagram-of-sustainability" class="info"></div>
                                <div style="height:13px;"></div>
                                Im Idealfall erfüllen die drei Bereiche/Entitäten (Soziokultur, Ökologie, Ökonomie) des Drei-Säulen-Modells, zu 100%, die Anforderung an ihre Nachhaltigkeit.
                                <div style="height:4px;"></div>
                                Die Schnittfläche der drei Bereiche wird, beim Drei-Säulen-Modell der Nachhaltigkeit, als Nachhaltigkeit bezeichnet.
                                <div style="height:4px;"></div>
                                Diese enspricht der Schnittfläche der drei Entitäten des Reuleaux-Diagramms, wenn dessen Schnittflächen alle den gleichen und maximalen Flächeninhalt gleichzeitig haben, oder flappsig formuliert, 100% Konsens haben.
                                <div style="height:13px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/strong-sustainability_<?php echo get_language() ?>.jpg"  alt="strong-sustainability" class="info"></div>
                                <div style="font-style:italic">Beispiel für starke Nachhaltigkeit</div>
                                <div style="height:4px;"></div>
                                95% Anteile an Soziokultur und <br> 95% Anteile an Umwelt und <br> 90% Anteile an Ökonomie entsprechen <br> 85,4% Anteile an Nachhaltigkeit.
                                <div style="height:4px;"></div>

                                <div style="height:30px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/average-sustainability_<?php echo get_language() ?>.jpg"  alt="average-sustainability" class="info"></div>
                                <div style="font-style:italic">Beispiel für durchschnittliche Nachhaltigkeit</div>
                                <div style="height:4px;"></div>
                                85% Anteile an Soziokultur und <br> 60% Anteile an Umwelt und <br> 80% Anteile an Ökonomie entsprechen <br> 47,3% Anteile an Nachhaltigkeit.
                                <div style="height:4px;"></div>

                                <div style="height:30px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/weak-sustainability_<?php echo get_language() ?>.jpg"  alt="weak-sustainability" class="info"></div>
                                <div style="font-style:italic">Beispiel für schwache Nachhaltigkeit</div>
                                <div style="height:4px;"></div>
                                100% Anteile an Soziokultur und <br> 50% Anteile an Umwelt und <br> 25% Anteile an Ökonomie entsprechen <br> 10,2% Anteile an Nachhaltigkeit.
                                <div style="height:4px;"></div>

                                <br><div style="height:20px;"></div>
                                Die drei o. g. Beispiele zeigen, wie intuitiv erkannt werden kann, wie stark oder schwach die Nachhaltigkeit z. B. eines Gewerks ausgeprägt ist.<br>
                                Das Rechenprinzip ist sehr einfach und leicht nachvollziehbar, es wird der Flächeninhalt der Schnittflächen berechet, die Berechung ist allerdings nicht so einfach.
                                Aus diesem Grund gibt es den Reuleaux-Diagramm-Rechner.

                                <div style="font-weight:bold;margin-bottom: 13px;margin-top: 30px">Der Ratingcode</div>

                                Der Ratingcode ist ein Statement zur Bonität, das sich aus dem erzielten Nachhaltigkeitswerts herleitet. <br>
                                Die Ratingcodes des Reuleaux-Diagramm Rechners sind aus den Ratingcodes der internationalen Ratingagenturen hergeleitet, mit dem Unterschied, dass nicht der Profit sondern die Nachhaltigkeit als Kriterium für die Bonität verwendet wird.<br>
                                Die Prozentzahl der Nachhaltigkeit bestimmt den 22-stufigen Ratingcode.<br>
                                <a href="<?php echo $site_url ?>mod/reuleaux/images/rating/comparison-ratingcode-scales_<?php echo get_language() ?>.pdf" target="_blank"><img style="width:60px;padding-bottom: 30px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/pdf-download.png"   alt="comparison-ratingcode-scales.pdf" class="info center"><br>PDF: Vergleich der Ratingcode-Skalen von internationalen Ratingagenturen</a>
                                <br><br><br>
                                <div style="font-weight:bold;margin-bottom: 13px">Konvertierung von anderen Nachhaltigkeitsberechnungen</div>
                                Du kannst andere Nachhaltigkeits- berechnungen in ein Reuleaux-Diagramm konvertieren, wenn du den Fragenkatalog und die Werte in die Bereiche Soziokultur, Ökologie und Ökonomie aufteilst. 
                                Wichtig! Wird ein Bereich nicht tangiert, oder können wir einen Bereich, mangels Informationen oder Kompetenz nicht bewerten, dann verwenden wir faierweise 100% für diesen Bereich und weisen in unserer Auswertung darauf hin. 
                                Gibt es einen Bereich nicht, dann können wir, per Definition, keine Nachhaltigkeit berechnen. Siehe Fundamentals.
                                         <div style="height:13px;"></div>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-conversion_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-conversion" class="info"></div><br> 

                                <div style="font-weight:bold;margin-bottom: 13px">Konsolidierung von Nachhaltigkeitsberechnungen </div>


                                Die Konsolidierung von mehreren Nachhaltigkeitsberechnungen z. B. Risiko-Analysen, Meilensteine, Unternehmensbereiche, Abteilungen usw, kann sehr einfach mit dem Reuleaux-Diagramm Rechner durchgeführt werden.
                                Gib die Summe der maximal zu ereichenden Punkte für jeden Bereich/Entität ein. Dann gib die Summe der erreichten Punkte für jeden Bereich/Entität ein.
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-consolidation_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-consolidation" class="info"></div>

                                <div style="font-weight:bold;margin-bottom: 13px">Fundamentals</div>

                                <div style="font-weight:bold;margin-bottom: 13px">Das Drei-Säulen-Modell der Nachhaltigkeit </div>
                                Jeder Bereich wird als gleich wichtig und gleichberechtigt angesehen. <br>
                                Aussage: Nachhaltigkeit kann nur bei gleichwertiger Rücksichtnahme auf alle drei Bereiche erreicht werden
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/three-pillars-model-of-sustainability_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>

                                <div style="font-weight:bold;margin-bottom: 13px">Vorrangmodell der Nachhaltigkeit</div>
                                Einzelne Bereiche werden in ihrer Beziehung und Abhängigkeit zueinander gesehen. <br>
                                Aussage: Keine Wirtschaft ohne eine Gesellschaft, keine Gesellschaft ohne Ökologie. 
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/sustainability-priority-model_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>

                                <div style="font-weight:bold;margin-bottom: 13px">Zum Schluß</div>
                                Der Ratingcode ist ein Statement zur Bönität eines Landes, Unternehmens, Projekts etc, der von internationalen Ratingagenturen zur Risikobewertung ermittelt wird.
                                Bei der Ermittlung der Ratingcodes durch die Ratingagenturen werden zwar Nachhaltigkeitsaspekte berücksichtigt, dies geschieht aber nicht transparent und nachvollziehbar.
                                Hauptkriterium für die Ermittlung des Ratingcodes, ist die bei den internationalen Ratingagenturen der wirtschaftliche Erfolg, in Form von Marktbeherrschung und Profit.
                                <br>
                                Die Prozentzahl der Nachhaltigkeit und der daraus resultierende Ratingcode, sind ein Statement zur ethischen Verantwortung, die z. B. ein Unternehmen gegenüber der Gesellschaft und der Umwelt übernimmt.
                                Nachhaltigkeit könnte das Hauptkriterium zur Ermittlung des Ratingcodes sein, ohne die Wirtschaft zu behindern, denn auch die Nachhaltigkeit sieht Profite vor, allerdings nur Profite die die Gesellschaft oder die Umwelt in akzeptabler Form beeinträchtigen.
                                <br>
                                Der Ratingcode bzw. das Statement zur Nachhaltigkeit errechnet sich aus der Bewertung der Fragen eines Fragenkatalogs. Für den Start kann der Fragenkatalog der <a href="https://de.wikipedia.org/wiki/Gemeinwohl-Bilanz" target="_blank">Gemeinwohl-Bilanz</a> empfohlen werden, der bei Bedarf geändert werden kann, da das Reuleaux Diagramm der Nachhaltigkeit
                                kein statisches Punktesystem verwendet. 
                                Grundsätzlich sollte angestrebt werden, dass mehrere Audits von verschiedenen Auditoren, auch mit verschiedenen Fragenkatalogen zu einem Ratingcode konsolodiert werden.
                                <br>
                                Zum Schluss muss gesagt werden, dass mit dem Reuleaux-Diagramm Rechner auch ganz einfache Projekte, mit einem einfachen Fragenkatalog, auf ihre Nachhaltigkeit geprüft werden können und das Ergebnis in einer Projekt-Dokumentation Verwendung finden sollte.
                                Es geht darum, transparent zu machen, wie nachhaltig das eigene Projekt ist und dies mit dem eigenen Fragekatalog und daraus resultierenden Kennzahlen zu belegen und ggf. den Fragenkatalog der Gegenpartei auf seine Nachhaltigkeit zu prüfen und mit dem ReuleauxDiagramm Rechner umzurechen und zu vergleichen.
                                Dafür ist er eigentlich gemacht.<br>
                                Deshalb gibt es einen Docu-Clipp-Button der zu eurer Berechnung Grafiken erstellt, die ihr, wegen der Professionalität, Glaubwürdigkeit und Transparenz in eure Dokumentation einfügen solltet.
                                <br><br>
                                Viel Spaß und gutes Gelingen!
                                <br><br>
                                Manfred Salomon
                                <?php
                                break;
                        case 'en':
                                ?>
                                The Reuleaux chart calculator calculates the sustainability and a rating, based on the <a href="https://en.wikipedia.org/wiki/Drei-%C3%A4ulen-Modell_(Sustainability)" target="_blank"> Three-pillar model of sustainability </a>, but can also be useful as a "consensus meter" for other purposes. 
                                <div style="height:4px;"></div>
                                The Reuleaux diagram calculates the intersection of three circle entities whose center is on a respective vertex of an equilateral triangle and whose maximum radius corresponds to the equilateral triangle side. <br> In this case, the areas / entities of the
                                <a href="https://en.wikipedia.org/wiki/Drei-A%53A4ulen-Modell_(Sustainability)" target="_blank"> Three-pillar model of sustainability: Socioculture (People / Society) , Ecology, economy.</a>
                                <div style="height:4px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagram-of-sustainability_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagram-of-sustainability" class="info"></div>
                                Ideally, the three areas / entities (socioculture, ecology, economics) of the three-pillar model, 100%, meet the requirements of their sustainability
                                The intersection of the three areas is called sustainability in the three-pillar model of sustainability
                                This corresponds to the intersection of the three entities of the Reuleaux diagram, if its intersections all have the same and maximum surface content at the same time, or formulated flapsily, have 100% consensus
                                <div style="height:13px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/strong-sustainability_<?php echo get_language() ?>.jpg"  alt="strong-sustainability" class="info"></div>
                                <div style="font-style:italic">Example of strong sustainability: </div>
                                <div style="height:4px;"></div>
                                95% shares in socioculture and <br> 95% shares in the environment and <br> 90% shares in economics correspond to 85.4% shares in sustainability.
                                <div style="height:4px;"></div>
                                <div style="height:30px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/average-sustainability_<?php echo get_language() ?>.jpg"  alt="average-sustainability" class="info"></div>
                                <div style="font-style:italic">Example of average sustainability </div>                             
                                85% shares in socioculture and <br> 60% shares in the environment and <br> 80% shares in economics correspond to 47.3% shares in sustainability.
                                <div style="height:4px;"></div>
                                <div style="height:30px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/weak-sustainability_<?php echo get_language() ?>.jpg"  alt="weak-sustainability" class="info"></div>                              
                                <div style="font-style:italic">Example of weak sustainability <br></div>
                                <div style="height:4px;"></div>
                                100% shares in socioculture and <br> 50% shares in the environment and <br> 25% shares in the economy correspond to 10.2% shares in sustainability.
                                <div style="height:4px;"></div>
                                <br><div style="height:20px;"></div>
                                The three o. Examples show how intuitively it can be recognized how strong or weak the sustainability, for example, For example of a trade
                                The raking principle is very simple and easy to understand, the surface area of ​​the cut surfaces is calculated, the calculation is however not so simple. <br>
                                For this reason, there is the Reuleaux Chart Calculator.

                                <div style="font-weight:bold;margin-bottom: 13px;margin-top: 30px">The rating code</div>
                                The rating code is a statement of the creditworthiness that is derived from the achieved sustainability value. <br>
                                The rating codes of the Reuleaux chart calculator are derived from the rating codes of the international rating agencies, with the difference that not the profit but the sustainability is used as a criterion for the credit rating
                                The percentage of sustainability determines the 22-rating rating code. <br> 

                                <a href="<?php echo $site_url ?>mod/reuleaux/images/rating/comparison-ratingcode-scales_<?php echo get_language() ?>.pdf" target="_blank"><img style="width:60px;padding-bottom: 30px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/pdf-download.png"   alt="comparison-ratingcode-scales.pdf" class="info center"><br>PDF: Vergleich der Ratingcode-Skalen von internationalen Ratingagenturen</a>
                                <br><br>

                                <div style="font-weight:bold;margin-bottom: 13px">Conversion of other sustainability calculations</div>
                                You can convert other sustainability calculations into a Reuleaux diagram by dividing the questionnaire and the values ​​into the areas of socioculture, ecology and economics.
                                Important! If an area is not affected, or we can not evaluate an area for lack of information or competence, we will use 100% for this area and point out in our evaluation.
                                If there is no area, we can not, by definition, calculate sustainability. See Fundamentals.  
                                <div style="height:13px;"></div>

                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-conversion_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-conversion" class="info"></div><br> 

                                <div style="font-weight:bold;margin-bottom: 13px">Consolidation of sustainability calculations</div>
                                The consolidation of several sustainability calculations, Such as risk analyzes, milestones, business units, departments, etc., can be easily implemented using the Reuleaux chart calculator.
                                Enter the sum of the maximum points to reach for each area / entity. Then enter the sum of the points reached for each area / entity.
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-consolidation_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-consolidation" class="info"></div>

                                <div style="font-weight:bold;margin-bottom: 13px">Fundamentals</div>

                                <div style="font-weight:bold;margin-bottom: 13px">The three-pillar model of sustainability </div>
                                Each area is considered equally important and equitable. <br>
                                Statement: Sustainability can only be achieved with equivalent consideration for all three areas
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/three-pillars-model-of-sustainability_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>
                                <div style="font-weight:bold;margin-bottom: 13px">Priority model of sustainability</div>
                                Individual areas are seen in their relationship and dependence on each other. <br>
                                Statement: No economy without a society, no society without ecology. <br>
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/sustainability-priority-model_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>
                                <div style="font-weight:bold;margin-bottom: 13px">In the end</div>
                                The rating code is a statement about the kindness of a country, company, project etc, which is determined by international rating agencies for risk assessment.
                                While rating ratings are determined by rating agencies, sustainability aspects are taken into account, but this is not transparent and comprehensible.
                                The main criterion for the evaluation of the rating code is that of the international rating agencies the economic success, in the form of market domination and profit.
                                <br>
                                The percentage of sustainability and the resulting rating code are a statement of ethical responsibility, For example, a company is opposed to society and the environment.
                                Sustainability could be the key criterion for assessing the rating without hampering the economy, since sustainability also provides for profits, but only profits that affect society or the environment in an acceptable form.
                                <br>
                                The rating code or the sustainability statement is calculated from the evaluation of the questions in a questionnaire. For the start, the questionnaire of the <a href="https://de.wikipedia.org/wiki/Gemeinwohl-Bilanz" target="_blank">public welfare balance sheet</a> can be recommended, which can be changed if necessary, as the Reuleaux diagram of sustainability
                                No static point system is used.
                                In principle, efforts should be made to ensure that several audits are consoli- dated to a rating code by various auditors, including various question catalogs.
                                <br>
                                Finally, it must be said that the Reuleaux diagram calculator can also be used to examine very simple projects, with a simple question catalog, for their sustainability, and the results should be used in a project documentation.
                                The aim is to make transparent how sustainable your own project is and to prove this with your own questionnaire and the results of the key performance indicators of sustainability. If necessary, check the list of questions of the opposing party for its sustainability (or re-compile it with the Reuleaux diagram).
                                He is actually made for it
                                That's why there is a Docu-Clipp-Button which creates graphics for your calculations. You should add credibility and transparency to your documentation because of the professionalism.
                                <br><br>
                                Have fun and good luck!
                                <br><br>
                                Manfred Salomon
                                <?php
                                break;
                        case 'fr':
                                ?>
                                Le calculateur de cartes Reuleaux calcule la durabilité et la notation, en fonction de la <a href="https://en.wikipedia.org/wiki/Drei-%C3%A4ulen-Modell_(Sustainability)" target="_blank"> Modèle à trois piliers de la durabilité </a>, mais peut également être utile en tant que «compteur de consensus» à d'autres fins. 
                                <div style="height:4px;"></div>
                                Le diagramme de Reuleaux calcule l'intersection de trois entités circulaires dont le centre est sur un sommet respectif d'un triangle équilatéral et dont le rayon maximal correspond au côté du triangle équilatéral. 
                                <div style="height:4px;"></div>
                                Dans ce cas, les domaines / entités de la
                                <a href="https://en.wikipedia.org/wiki/Drei-A%53A4ulen-Modell_(Sustainability)" target="_blank"> Modèle à trois piliers de durabilité: Socioculture (People / Society) , Écologie, Économie.</a>
                                <div style="height:4px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagram-of-sustainability_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagram-of-sustainability" class="info"></div>
                                <div style="height:13px;"></div>
                                Idéalement, les trois domaines / entités (socioculture, écologie, économie) du modèle à trois piliers, à 100%, répondent aux exigences de leur durabilité.
                                <div style="height:4px;"></div>
                                L'intersection des trois zones s'appelle la durabilité dans le modèle à trois volets de la durabilité.
                                <div style="height:4px;"></div>
                                Cela correspond à l'intersection des trois entités du diagramme de Reuleaux, si ses intersections ont tous le même contenu et la surface maximale en même temps, ou formulées en flaps, ont un consensus à 100%.
                                <div style="height:13px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/strong-sustainability_<?php echo get_language() ?>.jpg"  alt="strong-sustainability" class="info"></div>
                                <div style="font-style:italic">Exemple de forte durabilité:</div>
                                <div style="height:4px;"></div>
                                95% d'actions en socioculture et <br> 95% d'actions en environnement et <br> 90% d'actions en économie correspondent à <br> 85,4% de parts de viabilité.
                                <div style="height:4px;"></div>
                                <div style="height:30px;"></div>                                   <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/average-sustainability_<?php echo get_language() ?>.jpg"  alt="average-sustainability" class="info"></div>

                                <div style="font-style:italic">Exemple de soutenabilité moyenne</div>
                                <div style="height:4px;"></div>
                                85% d'actions en socioculture et <br> 60% d'actions dans l'environnement et <br> 80% d'actions en économie correspondent à  <br>47,3% de parts de viabilité.
                                <div style="height:4px;"></div>
                                <div style="height:30px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/weak-sustainability_<?php echo get_language() ?>.jpg"  alt="weak-sustainability" class="info"></div>
                                <div style="font-style:italic">Exemple de faible durabilité </div>
                                <div style="height:4px;"></div>
                                100% d'actions en socioculture et <br> 50% d'actions dans l'environnement et <br> 25% d'actions dans l'économie correspondent<br> à  10,2% de parts de viabilité.

                                <div style="height:4px;"></div>

                                <br><div style="height:20px;"></div>
                                Les trois o. Les exemples montrent combien intuitivement on peut reconnaître la force ou la faiblesse de la durabilité, par exemple, Par exemple, un métier
                                Le principe du ratissage est très simple et facile à comprendre, la surface des surfaces coupées est calculée, mais le calcul n'est pas si simple. <br>
                                Pour cette raison, il y a la Calculatrice Graphique Reuleaux
                                <br>
                                <br>
                                <br>
                                <br>
                                <div style="font-weight:bold;margin-bottom: 13px;margin-top: 30px">Le code de rating</div>
                                Le code de rating est un énoncé de la solvabilité qui découle de la valeur de durabilité obtenue. <br>
                                Les codes de notation du calculateur de cartes Reuleaux sont dérivés des codes de notation des agences de notation internationales, à la différence que le profit, mais la durabilité, n'est pas utilisé comme critère pour la notation de crédit
                                Le pourcentage de durabilité détermine le code de notation de 22 cotes. <br> 
                                <a href="<?php echo $site_url ?>mod/reuleaux/images/rating/comparison-ratingcode-scales_<?php echo get_language() ?>.pdf" target="_blank"><img style="width:60px;padding-bottom: 30px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/pdf-download.png"   alt="comparison-ratingcode-scales.pdf" class="info center"><br>PDF: Comparaison des échelles de codes de rating par des agences de notation internationales</a>

                                <br><br>
                                <div style="font-weight:bold;margin-bottom: 13px">Conversion d'autres calculs de durabilité </div>
                                Vous pouvez convertir d'autres calculs de durabilité en un diagramme de Reuleaux en divisant le questionnaire et les valeurs dans les domaines de la socioculture, de l'écologie et de l'économie.
                                Important! N'est pas affecté une zone ou nous ne pouvons pas évaluer une zone, le manque d'information ou d'expertise, alors nous utilisons faierweise 100% pour ce domaine et le point dans notre analyse suggère.
                                S'il n'y a pas de zone, nous ne pouvons pas, par définition, calculer la durabilité. Voir les principes fondamentaux. 

                                         <div style="height:13px;"></div>

                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-conversion_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-conversion" class="info"></div><br> 
                                <div style="font-weight:bold;margin-bottom: 13px">Consolidation des calculs de durabilité </div>
                                La consolidation de plusieurs calculs de durabilité, Comme les analyses de risque, les jalons, les unités d'affaires, les départements, etc., peuvent être facilement implémentés à l'aide du calculateur de graphiques Reuleaux.
                                Entrez la somme des points maximum à atteindre pour chaque zone / entité. Ensuite, entrez la somme des points atteints pour chaque zone / entité.
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-consolidation_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-consolidation" class="info"></div>
                                <br>
                                <<div style="font-weight:bold;margin-bottom: 13px">Principes fondamentaux </div>
                                <div style="font-weight:bold;margin-bottom: 13px">Le modèle à trois piliers de la durabilité</div>
                                Chaque zone est considérée comme tout aussi importante et équitable. <br>
                                Déclaration: la durabilité ne peut être réalisée qu'avec une considération équivalente pour les trois domaines
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/three-pillars-model-of-sustainability_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>

                                <div style="font-weight:bold;margin-bottom: 13px">Modèle prioritaire de durabilité</div>
                                Les zones individuelles sont observées dans leur relation et leur dépendance mutuelle. <br>
                                Déclaration: Aucune économie sans société, aucune société sans écologie. <br>
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/sustainability-priority-model_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>

                                <div style="font-weight:bold;margin-bottom: 13px">À la fin</div>
                                Le code de notation est un énoncé sur la gentillesse d'un pays, d'une entreprise, d'un projet, etc., déterminé par des agences de notation internationales pour l'évaluation des risques.
                                Bien que les notations soient déterminées par les agences de notation, les aspects de la durabilité sont pris en compte, mais cela n'est pas transparent et compréhensible.
                                Le principal critère pour déterminer les codes de notation des agences de notation internationales, le succès économique, sous la forme de domination du marché et du profit.
                                <br>
                                Le pourcentage de durabilité et le code de notation qui en résulte sont un énoncé de responsabilité éthique, Par exemple, une entreprise s'oppose à la société et à l'environnement.
                                La viabilité pourrait être le principal critère pour déterminer les Ratingcodes sans entraver l'économie, ainsi que la durabilité prévoit des bénéfices, mais seulement des bénéfices qui affectent la société et l'environnement sous une forme acceptable.
                                <br>
                                Le code de notation ou l'énoncé de durabilité est calculé à partir de l'évaluation des questions dans un questionnaire. Pour le début, le questionnaire du bilan de bien-être public peut être recommandé, qui peut être modifié si nécessaire, comme le schéma de Durabilité de Reuleaux
                                Aucun système de point statique n'est utilisé.
                                En principe, il conviendrait de veiller à ce que plusieurs audits soient intégrés à un code de notation par divers auditeurs, y compris les catalogues de questions diverses.
                                <br>
                                Enfin, il faut dire que le calculateur de diagramme de Reuleaux peut également être utilisé pour examiner des projets très simples, avec un catalogue de questions simples, pour leur durabilité, et les résultats doivent être utilisés dans une documentation de projet.
                                L'objectif est de rendre transparent le degré de pérennité de votre propre projet et de le prouver avec votre propre questionnaire et les chiffres clés qui en résultent. Si nécessaire, vérifiez la liste des questions de la partie adverse pour sa durabilité (ou re-compilez-le avec le diagramme de Reuleaux).
                                Il est réellement fait pour ça
                                C'est pourquoi il existe un Docu-Clipp-Button qui crée des graphiques pour vos calculs. Vous devez ajouter de la crédibilité et de la transparence à votre documentation en raison du professionnalisme.
                                <br><br>
                                Amusez-vous bien et bonne chance!
                                <br><br>
                                Manfred Salomon
                                <?php
                                break;
                        case 'es':
                                ?>
                                La calculadora gráfica Reuleaux calcula la sostenibilidad y la clasificación basada en el <a href="https://de.wikipedia.org/wiki/Drei-S%C3%A4ulen-Modell_(Nachhaltigkeit)" target="_blank"> Modelo de sostenibilidad de tres pilares</a>, pero también puede ser útil como un "medidor de consenso" para otros fines.                                                                <br>
                                El ordenador diagrama de Reuleaux calcula el área de la sección de tres entidades circular cuyo centro está situado en un vértice respectivo de un triángulo equilátero, y se corresponde con el radio máximo de la lado del triángulo equilátero. 
                                <br> En este caso, las áreas / entidades de la
                                <a href="https://de.wikipedia.org/wiki/Drei-S%C3%A4ulen-Modell_(Nachhaltigkeit)" target="_blank"> Drei-Säulen-Modells der Nachhaltigkeit: Soziokultur (Mensch/Gesellschaft), Ökologie (Umwelt), Ökonomie (Wirtschaft).</a>
                                <div style="height:4px;"></div>

                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagram-of-sustainability_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagram-of-sustainability" class="info"></div>
                                <div style="height:13px;"></div>
                                Idealmente, las tres áreas / entidades se reúnen (Socio-cultural, ambiental y económico) del modelo de tres pilares a 100%, el requisito de sostenibilidad. <br>
                                La intersección de las tres áreas se denomina sostenibilidad en el modelo de sostenibilidad de tres pilares
                                Esto corresponde a la superficie de la sección de las tres entidades de la tabla de Reuleaux cuando las superficies de corte son todos de igual y máxima área de superficie al mismo tiempo, o flappsig formulado, tener 100% de consenso. <br>
                                <br>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/strong-sustainability_<?php echo get_language() ?>.jpg"  alt="strong-sustainability" class="info"></div>

                                <div style="font-style:italic">   Ejemplo de sostenibilidad fuerte: </div>
                                <div style="height:4px;"></div>
                                95% de las acciones en socioculturales y  interés del <br> 95% en el medio ambiente y participación del <br> 90% en economía  corresponden <br>85,4% interés por la sostenibilidad.
                                <div style="height:4px;"></div>
                                <div style="height:30px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/average-sustainability_<?php echo get_language() ?>.jpg"  alt="average-sustainability" class="info"></div>
                                Ejemplo de sostenibilidad media <br>
                                85% acciones en sociocultura y <br> 60% acciones en medio ambiente y <br> 80% acciones en economía corresponden a <br>47,3% acciones en sostenibilidad.
                                <div style="height:4px;"></div>
                                <div style="height:30px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/weak-sustainability_<?php echo get_language() ?>.jpg"  alt="weak-sustainability" class="info"></div>
                                Ejemplo de sostenibilidad débil <br>
                                100% acciones en sociocultura y <br> 50% acciones en el medio ambiente y <br> 25% acciones en la economía corresponden a <br>10,2% acciones en sostenibilidad.
                                <div style="height:4px;"></div>
                                <div style="height:30px;"></div>
                                Los tres o. Los ejemplos muestran cómo intuitivamente se puede reconocer lo fuerte o débil que es la sostenibilidad, por ejemplo, Por ejemplo de un comercio
                                El principio de rastrillo es muy simple y fácil de entender, se calcula el área superficial de las superficies cortadas, pero el cálculo no es tan simple. <br>
                                Por esta razón, existe la Calculadora de Gráficos de Reuleaux

                                <div style="font-weight:bold;margin-bottom: 13px;margin-top: 30px">El código de rating</div>
                                El código de rating es una declaración de la solvencia que se deriva del valor de sostenibilidad alcanzado. <br>
                                El código de clasificación del equipo gráfico de Reuleaux se derivan de la Ratingcodes las agencias internacionales de rating, con la diferencia que no beneficio, pero la sostenibilidad se utiliza como criterio para el crédito. <br>
                                El porcentaje de sostenibilidad determina el código de rating de 22-grado.
                                <a href="<?php echo $site_url ?>mod/reuleaux/images/rating/comparison-ratingcode-scales_<?php echo get_language() ?>.pdf" target="_blank"><img style="width:60px;padding-bottom: 30px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/pdf-download.png"   alt="comparison-ratingcode-scales.pdf" class="info center"><br>PDF. Comparación de Ratingcode- Escalas de las agencias internacionales de rating </a>
                                <br><br>
                                <div style="font-weight:bold;margin-bottom: 13px">Conversión de otros cálculos de sostenibilidad</div>
                                Puede otros cálculos de sostenibilidad convertir en un gráfico de Reuleaux cuando estás dividiendo el cuestionario y los valores en las áreas de desarrollo socio-cultura, ecología y economía.
                                Importante! no se ve afectado un área o no podemos evaluar un área, la falta de información o conocimientos, a continuación, utilizamos faierweise 100% para esta zona y punto de nuestro análisis sugiere.
                                Si no hay un área, no podemos, por definición, calcular la sostenibilidad. Ver Fundamentos.

                                         <div style="height:13px;"></div>

                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-conversion_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-conversion" class="info"></div><br> 

                                <div style="font-weight:bold;margin-bottom: 13px">Consolidación de cálculos de sostenibilidad </div>
                                La consolidación de varios cálculos de sostenibilidad, B. Análisis de Riesgos, hitos, divisiones, departamentos, etc, se puede realizar fácilmente con la calculadora gráfica Reuleaux.
                                Introduzca la suma de los puntos máximos a alcanzar para cada área / entidad. A continuación, introduzca la suma de los puntos alcanzados para cada área/entidad.

                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-consolidation_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-consolidation" class="info"></div>

                                <div style="font-weight:bold;margin-bottom: 13px">Fundamentos</div>
                                <div style="font-weight:bold;margin-bottom: 13px">El modelo de sostenibilidad de tres pilares</div>
                                Cada área se considera igualmente importante y equitativa. <br>
                                Declaración: La sostenibilidad sólo puede lograrse con una consideración equivalente para las tres áreas
                                <<br>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/three-pillars-model-of-sustainability_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>



                                <div style="font-weight:bold;margin-bottom: 13px">Modelo prioritario de sostenibilidad </div>
                                Las áreas individuales se ven en su relación y dependencia el uno del otro. <br>
                                Declaración: Sin economía sin sociedad, sin sociedad sin ecología. <br>
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/sustainability-priority-model_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>

                                <div style="font-weight:bold;margin-bottom: 13px">Al final</div>
                                El código de rating es una declaración a Bonität un país, empresa, proyecto, etc., que se determina por las agencias internacionales de rating para la evaluación de riesgos.
                                Si bien las calificaciones son determinadas por agencias de rating, se tienen en cuenta los aspectos de sostenibilidad, pero esto no es transparente y comprensible.
                                El principal criterio para determinar los códigos de clasificación en la agencias internacionales de rating, el éxito económico, en forma de dominación del mercado y la ganancia.
                                <br>
                                El porcentaje de sostenibilidad y el código de rating resultante son una declaración de responsabilidad ética, Por ejemplo, una empresa se opone a la sociedad y al medio ambiente.
                                Sostenibilidad podría ser el criterio principal para determinar las Ratingcodes sin obstaculizar la economía, así como la sostenibilidad prevé ganancias, pero sólo los beneficios que afectan a la sociedad y el medio ambiente en una forma aceptable.
                                <br>
                                El código de rating o la declaración de sostenibilidad se calcula a partir de la evaluación de las preguntas en un cuestionario. Para empezar, se puede recomendar el cuestionario del balance de bienestar público, que puede ser modificado si es necesario, ya que el diagrama Reuleaux de sostenibilidad
                                No se utiliza ningún sistema de puntos estáticos.
                                En principio, se deben hacer esfuerzos para asegurar que varias auditorías estén consolidadas a un código de rating por varios auditores, incluyendo varios catálogos de preguntas.
                                <br>
                                Por último, hay que decir que con la calculadora gráfica Reuleaux también proyectos muy simples, con un sencillo cuestionario que puede ser probado por su sostenibilidad y el resultado se debe utilizar en una documentación del proyecto.
                                El punto es hacer transparente la forma de proyecto sostenible y propio para probar esto con sus propias preguntas y las métricas resultantes y, si es necesario, para examinar las cuestiones de la otra parte para su sostenibilidad (o al rastrillo con los ordenadores ReuleauxDiagramm) y comparar.
                                Él es realmente hecho para él
                                Por lo tanto, hay un botón de docu-Clipp crea gráficos para su cálculo, usted, usted debe incluir en su documentación debido a la profesionalidad, credibilidad y transparencia.
                                <br><br>
                                ¡Diviértete y buena suerte!
                                <br><br>
                                Manfred Salomon

                                <?php
                                break;
                        case 'it':
                                ?>
                                Il calcolatore grafico Reuleaux calcola la sostenibilità e la rating basata sul href <a href="https://de.wikipedia.org/wiki/Drei-S%C3%A4ulen-Modell_(Nachhaltigkeit)" target="_blank"> tripla riga inferiore del codice sostenibilità</a>, ma può essere utile come "consenso-meter" per altri scopi. 
                                <br>
                                Il computer diagramma Reuleaux calcola l'area di sezione di tre entità circolari il cui centro è situato su un rispettivo vertice di un triangolo equilatero, e corrisponde al raggio massimo del lato del triangolo equilatero. <br> 
                                In questo caso, le aree / entità del
                                <a href="https://de.wikipedia.org/wiki/Drei-S%C3%A4ulen-Modell_(Nachhaltigkeit)" target="_blank"> modello a tre pilastri della sostenibilità: cultura sociale (/ società umana) , Ecologia, economia.</a>
                                <br>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagram-of-sustainability_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagram-of-sustainability" class="info"></div>
                                <div style="height:13px;"></div>
                                Idealmente, le tre aree / entità si incontrano (socio-culturale, ambientale, economica) del modello a tre pilastri al 100%, il requisito per la sostenibilità. <br>
                                L'area della sezione delle tre aree è la linea inferiore triplice sostenibilità, chiamato sostenibilità. <br>
                                Ciò corrisponde all'area in sezione di tre entità del grafico Reuleaux quando le superfici di taglio sono tutti uguali e la massima area superficiale allo stesso tempo, o flappsig formulato, avere il 100% di consenso. 
                                <div style="height:13px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/strong-sustainability_<?php echo get_language() ?>.jpg"  alt="strong-sustainability" class="info"></div>
                                <div style="font-style:italic">Esempio di forte sostenibilità</div>
                                <div style="height:4px;"></div>
                                Il 95% delle azioni sul socio-culturale e vendere l'interesse del <br>95% per l'ambiente e vendere il <br>90% del capitale di economia  corrispondono <br>85,4% di interesse nel campo della sostenibilità.
                                <div style="height:4px;"></div>
                                <div style="height:30px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/average-sustainability_<?php echo get_language() ?>.jpg"  alt="average-sustainability" class="info"></div>
                                <div style="font-style:italic">Esempio di sostenibilità media </div>
                                <div style="height:4px;"></div>
                                interessi 85% degli interessi socio-culturale e <br>60% nell'ambiente e vendere il 80% del capitale di economia corrispondono <br>47,3% di interesse nel campo della sostenibilità.
                                <div style="height:4px;"></div>
                                <div style="height:30px;"></div>
                                <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/weak-sustainability_<?php echo get_language() ?>.jpg"  alt="weak-sustainability" class="info"></div>
                                <div style="font-style:italic">Esempio di debole sostenibilità</div>
                                <div style="height:4px;"></div>
                                100% di interesse socio-culturale e <br>50% nell'ambiente e vendere il <br>25% del capitale di economia <br> corrispondono al <br>10,2% del capitale di sostenibilità.
                                <div style="height:4px;"></div>

                                <br><div style="height:20px;"></div>
                                Le tre o. mostrare esempi, come si può vedere intuitivamente come forte o debole z sostenibilità. Ad esempio di un commercio
                                Il principio di calcolo è molto semplice e di facile comprensione, è l'area della superficie di taglio Berechet, ma il calcolo non è così semplice. <br>
                                Per questo motivo, c'è il Calcolatore Grafico Reuleaux
                                <br>
                                <br>
                                <br>
                                <br>
                                <div style="font-weight:bold;margin-bottom: 13px;margin-top: 30px">Il codice di rating </div>
                                Il codice di punteggio è una dichiarazione al credito, che è derivato dal valore di sostenibilità raggiunto. <br>
                                Il codice rating di Reuleaux calcolatore grafico sono derivati ​​dal Ratingcodes le agenzie internazionali di rating, con la differenza che non il profitto, ma la sostenibilità è utilizzato come criterio per il credito. <br>
                                La percentuale di sostenibilità determina il codice di voto 22 punti. <br>
                                <a href="<?php echo $site_url ?>mod/reuleaux/images/rating/comparison-ratingcode-scales_<?php echo get_language() ?>.pdf" target="_blank"><img style="width:60px;padding-bottom: 30px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/pdf-download.png"   alt="comparison-ratingcode-scales.pdf" class="info center"><br>PDF. Confronto di Ratingcode- Bilance delle agenzie di rating internazionali </a>
                                <br><br>
                                <div style="font-weight:bold;margin-bottom: 13px">Conversione di altri calcoli di sostenibilità </div>
                                Puoi altri calcoli di sostenibilità convertire in un grafico Reuleaux quando si sta dividendo il questionario e dei valori nei settori della socio-cultura, ecologia ed economia.
                                Importante! non è influenzato un'area o non possiamo valutare una zona, la mancanza di informazioni o di competenza, allora usiamo faierweise 100% per questa zona e punto della nostra analisi suggerisce.
                                Se non esiste alcuna area, non possiamo definire, per definizione, la sostenibilità. Vedere i principi fondamentali.
                                 <div style="height:13px;"></div>

                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-conversion_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-conversion" class="info"></div><br> 

                                <div style="font-weight:bold;margin-bottom: 13px">Consolidamento dei calcoli di sostenibilità </div>
                                Il consolidamento di diversi calcoli di sostenibilità, Come analisi di rischio, pietre miliari, unità aziendali, dipartimenti, ecc., È possibile implementare facilmente utilizzando il calcolatore tabella Reuleaux.
                                Inserisci la somma dei punti massimi da raggiungere per ogni area / entità. Quindi inserire la somma dei punti raggiunti per ogni area / entità.
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-consolidation_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-consolidation" class="info"></div>
                                <div style="font-weight:bold;margin-bottom: 13px">Fondamenti</div>
                                <div style="font-weight:bold;margin-bottom: 13px">Il modello di sostenibilità a tre pilastri</div>
                                Ogni area è considerata altrettanto importante e equa. <br>
                                Dichiarazione: la sostenibilità può essere raggiunta solo con considerazione equivalente per tutte e tre le aree
                                <br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/three-pillars-model-of-sustainability_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>

                                <div style="font-weight:bold;margin-bottom: 13px">Modello prioritario di sostenibilità </div>
                                Le aree individuali sono viste nei loro rapporti e dipendenza tra loro. <br>
                                Dichiarazione: Nessuna economia senza una società, nessuna società senza ecologia. <br>

                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/sustainability-priority-model_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>
                                <br>
                                <br>
                                <div style="font-weight:bold;margin-bottom: 13px">Alla fine</div>
                                Il codice di punteggio è una dichiarazione per Bonität un paese, la società, di progetto, ecc, che è determinato da agenzie internazionali di rating per la rating del rischio.
                                Se le valutazioni sono determinate dalle agenzie di rating, si considerano gli aspetti della sostenibilità, ma ciò non è trasparente e comprensibile.
                                Il criterio principale per la rating del codice di rating è quello delle agenzie di rating internazionali il successo economico, sotto forma di dominio del mercato e profitto.
                                <br>
                                La percentuale di sostenibilità e il codice di rating risultante sono una dichiarazione di responsabilità etica, Ad esempio, un'azienda si oppone alla società e all'ambiente.
                                La sostenibilità potrebbe essere il criterio principale per determinare le Ratingcodes senza ostacolare l'economia, così come la sostenibilità prevede per i profitti, ma solo gli utili che riguardano la società e l'ambiente in una forma accettabile.
                                <br>
                                Il codice di rating o l'istruzione di sostenibilità sono calcolati dalla rating delle domande in un questionario. Per iniziare il questionario del buon equilibrio comune possono essere raccomandato, che può essere modificato in base alle esigenze, perché lo schema Reuleaux della sostenibilità
                                Non viene utilizzato alcun sistema statico.
                                Fondamentalmente, l'obiettivo dovrebbe essere quello più verifiche di revisori diversi sono konsolodiert con vari questionari ad un codice di rating.
                                <br>
                                Infine, va detto che con la calcolatrice grafico Reuleaux anche progetti molto semplici, con un semplice questionario che può essere testato per la loro sostenibilità e il risultato dovrebbe essere utilizzato in una documentazione di progetto.
                                Il punto è quello di rendere trasparente come progetto sostenibile e proprio per dimostrare questo con le proprie domande e le metriche risultanti e, se necessario, per esaminare le questioni dell'altra parte alla sua sostenibilità (o per rastrellare con i computer ReuleauxDiagramm) e confrontare.
                                È realmente fatto per esso
                                Pertanto, v'è un pulsante docu-Clipp crea grafica per il calcolo, si, si dovrebbe includere nella documentazione per la professionalità, la credibilità e la trasparenza.
                                <br><br>
                                Divertiti e buona fortuna!
                                <br><br>
                                Manfred Salomon
                                <?php
                                break;
                        case 'nl':
                                ?>
                                De Reuleaux grafiek calculator berekent de duurzaamheid en de rating gebaseerd op de <a href="https://de.wikipedia.org/wiki/Drei-S%C3%A4ulen-Modell_(Nachhaltigkeit)" target="_blank"> Drie-pillar model van duurzaamheid, maar kan ook nuttig zijn als een "consensus meter" voor andere doeleinden. </a>
                                <br>
                                De Reuleaux diagram computer berekent het doorsnedeoppervlak van drie ronde entiteiten waarvan het middelpunt is gelegen op een respectieve top van een gelijkzijdige driehoek, en komt overeen met de maximale straal van de kant van de gelijkzijdige driehoek. <br> In dit geval, de gebieden / entiteiten van de
                                <a href="https://de.wikipedia.org/wiki/Drei-S%C3%A4ulen-Modell_(Nachhaltigkeit)" target="_blank"> drie pijlers model van duurzaamheid: sociaal cultuur (mens / samenleving) , Ecologie, economie
                                    <br>
                                    <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagram-of-sustainability_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagram-of-sustainability" class="info"></div>
                                    Ideaal gezien voldoen de drie gebieden / entiteiten (sociocultuur, ecologie, economie) van het driepijlermodel, 100%, aan de eisen van hun duurzaamheid
                                    Het kruispunt van de drie gebieden heet duurzaamheid in het drie-pijler model van duurzaamheid
                                    Dit komt overeen met het oppervlak van de drie eenheden van de Reuleaux grafiek wanneer de snijvlakken zijn allemaal even en maximale oppervlakte tegelijkertijd of flappsig geformuleerd, hebben 100% consensus. <br>
                                    <br>
                                    <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/strong-sustainability_<?php echo get_language() ?>.jpg"  alt="strong-sustainability" class="info"></div>
                                    <div style="font-style:italic">Voorbeeld van sterke duurzaamheid: </div>
                                    <div style="height:4px;"></div>
                                    95% van de aandelen  over de sociaal-culturele en verkopen <br>95% -belang in het milieu en verkopen <br>90% -belang in de economie overeen <br>85,4% belang in duurzaamheid.
                                    <div style="height:4px;"></div>
                                    <div style="height:30px;"></div>

                                    <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/average-sustainability_<?php echo get_language() ?>.jpg"  alt="average-sustainability" class="info"></div>
                                    <div style="font-style:italic">Voorbeeld van gemiddelde duurzaamheid  </div>
                                    <div style="height:4px;"></div>
                                    85% aandelen in sociocultuur en <br>60% aandelen in het milieu en <br>80% aandelen in de economie komen overeen met <br>47,3% aandelen in duurzaamheid.
                                    <div style="height:4px;"></div>
                                    <div style="height:30px;"></div>

                                    <div class="col-md-12 center" style="padding:0px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/weak-sustainability_<?php echo get_language() ?>.jpg"  alt="weak-sustainability" class="info"></div>
                                    <div style="font-style:italic">Voorbeeld van zwakke duurzaamheid </div>
                                    <div style="height:4px;"></div>

                                <br><div style="height:20px;"></div>
                                    De drie o. Voorbeelden laten zien hoe intuïtief het kan worden herkend hoe sterk of zwak de duurzaamheid, bijvoorbeeld, Bijvoorbeeld van een handel
                                    Het rakprincipe is heel eenvoudig en gemakkelijk te begrijpen, het oppervlak van de snijvlakken wordt berekend, maar de berekening is echter niet zo simpel. <br>
                                    Om deze reden is er de Reuleaux Chart Calculator
                                                              <div style="font-weight:bold;margin-bottom: 13px;margin-top: 30px">De rating code</div>
                                    De rating code is een verklaring van de kredietwaardigheid die is afgeleid van de bereikte duurzaamheidswaarde. <br>
                                    De rating code van Reuleaux grafiek computer zijn afgeleid van de Ratingcodes de internationale rating agencies, met het verschil dat geen voordeel, maar de duurzaamheid wordt gebruikt als criterium voor het krediet. <br>
                                    Het percentage duurzaamheid bepaalt de 22-rating rating code. <br>
                                    
                                <a href="<?php echo $site_url ?>mod/reuleaux/images/rating/comparison-ratingcode-scales_<?php echo get_language() ?>.pdf" target="_blank"><img style="width:60px;padding-bottom: 30px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/pdf-download.png"   alt="comparison-ratingcode-scales.pdf" class="info center"><br>PDF: Vergleich der Ratingcode-Skalen von internationalen Ratingagenturen</a>
                                <br><br>
                                    <div style="font-weight:bold;margin-bottom: 13px">Conversie van andere duurzaamheidsberekeningen</div>
                                
                                    U kunt andere duurzaamheidsberekeningen omzetten in een Reuleaux-diagram door de vragenlijst en de waarden te verdelen in de gebieden van sociocultuur, ecologie en economie.
                                    Belangrijk! Als een gebied niet wordt beïnvloed, of we kunnen geen gebied beoordelen voor gebrek aan informatie of competentie, gebruiken we 100% voor dit gebied en wijzen erop in onze evaluatie.
                                    Als er geen gebied is, kunnen we niet per definitie duurzaamheid berekenen. Zie fundamenten.
                                    
                                         <div style="height:13px;"></div>
                                
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-conversion_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-conversion" class="info"></div><br> 
                                    <div style="font-weight:bold;margin-bottom: 13px">Consolidatie van duurzaamheidsberekeningen </div>
                                    De consolidatie van diverse duurzaamheidsberekeningen, B. Risicoanalyses, mijlpalen, divisies, afdelingen, enz, kan gemakkelijk worden uitgevoerd met de Reuleaux grafiek rekenmachine.
                                    Voer de som van de maximale punten in voor elk gebied / entiteit. Voer vervolgens de som van de punten in die voor elke zone / entiteit zijn bereikt.
<br>
                                <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagramm-consolidation_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagramm-consolidation" class="info"></div>
                                    <div style="font-weight:bold;margin-bottom: 13px">Fundamentals</div>
                                        <div style="font-weight:bold;margin-bottom: 13px">Het drie-pijler model van duurzaamheid </div>
                                        Elk gebied wordt even belangrijk en billijk beschouwd. <br>
                                        Verklaring: Duurzaamheid kan alleen bereikt worden met een gelijkwaardige overweging voor alle drie de gebieden
                                        <br>
                                         <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/three-pillars-model-of-sustainability_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>
                            
                                        <div style="font-weight:bold;margin-bottom: 13px">Prioriteitsmodel duurzaamheid</div>
                                        Individuele gebieden worden gezien in hun relatie en afhankelijkheid van elkaar. <br>
                                        Verklaring: Geen economie zonder een samenleving, geen samenleving zonder ecologie. <br>
                                        <br>
                                        <div class="col-md-12 center" style="padding-bottom: 30px"><img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/sustainability-priority-model_<?php echo get_language() ?>.jpg"  alt="logo" class="info"></div>
                                        <br>
                                        <br>
                                        <div style="font-weight:bold;margin-bottom: 13px">Op het einde</div>
                                            De rating code is een verklaring naar een land, bedrijf, project, etc, die wordt bepaald door de internationale rating agencies voor de risicobeoordeling Bönität.
                                            Terwijl rating ratings worden bepaald door ratingbureaus, worden duurzaamheidsaspecten in aanmerking genomen, maar dit is niet transparant en begrijpelijk.
                                            Het belangrijkste criterium voor het bepalen van de rating codes in de internationale rating agencies, economisch succes, in de vorm van markt dominantie en winst.
                                            <br>
                                            Het percentage duurzaamheid en de daaruit voortvloeiende ratingcode zijn een verklaring van ethische verantwoordelijkheid, Bijvoorbeeld, een bedrijf staat tegenover de samenleving en het milieu.
                                            Duurzaamheid zou het belangrijkste criterium voor het bepalen van de Ratingcodes zonder hinder voor de economie, evenals de duurzaamheid biedt voor de winst, maar alleen winst die de samenleving beïnvloeden en het milieu in een aanvaardbare vorm zijn.
                                            <br>
                                            De ratingcode of de duurzaamheidsverklaring wordt berekend uit de evaluatie van de vragen in een vragenlijst. Om de vragenlijst van de gemeenschappelijke goede balans te beginnen kan worden aanbevolen, die kan worden veranderd als dat nodig is, omdat de Reuleaux diagram van duurzaamheid
                                            Er wordt geen statisch punt systeem gebruikt.
                                            In beginsel moet worden gestreefd naar het verzekeren dat meerdere audits door een aantal auditors worden geconsolideerd naar een ratingcode, waaronder diverse vragencatalogussen.
                                            <br>
                                            Ten slotte moet gezegd worden dat met de Reuleaux grafiek rekenmachine ook heel eenvoudige projecten, met een eenvoudige vragenlijst die kan worden getest op hun duurzaamheid en het resultaat moet worden gebruikt in een project documentatie.
                                            Het punt is transparant hoe duurzaam en eigen project om dit te bewijzen met hun eigen vragen en de daaruit voortvloeiende statistieken en, indien nodig, op de vragen van de andere partij onderzoeken om de duurzaamheid ervan (of te harken met de ReuleauxDiagramm computers) en vergelijk te maken.
                                            Hij is er eigenlijk voor gemaakt
                                            Daarom is er een docu-Clipp knop creëert graphics voor uw berekening, u, u moet opnemen in de documentatie als gevolg van de professionaliteit, geloofwaardigheid en transparantie.
                                            <br><br>
                                            Veel plezier en succes!
                                            <br><br>
                                            Manfred Salomon

                                            <?php
                                            break;
                            }
                            ?>
                            <!--switch div--> 
                            </div> 


                            </div>

                            
                                <div class="footer-text" >

                                    <div class="col-md-2 col-xs-2 footer-drop" style="top:15px;">
                                        <p> <a href="<?php echo $site_url ?>info" target="_self"><?php echo elgg_echo('rel_label_link_information',$dummy); ?></a></p>
                                    </div>
                                    <div class="col-md-8 col-xs-8 language_selector footer-drop-center"style="top:20px;">
                                        <?php      if (!$no_flags){ ?>
                                        <a href='javascript:setLanguage("en");' title='<?php echo elgg_echo('rel_label_translation_en'); ?>'>
                                            <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/en.gif' alt='<?php echo elgg_echo('rel_label_translation_en'); ?>' title='<?php echo elgg_echo('rel_label_translation_en'); ?>'>
                                        </a>
                                        <a href='javascript:setLanguage("de");' title='<?php echo elgg_echo('rel_label_translation_de'); ?>'>
                                            <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/de.gif' alt='<?php echo elgg_echo('rel_label_translation_de'); ?>' title='<?php echo elgg_echo('rel_label_translation_de'); ?>'>
                                            <a>
                                                <a href='javascript:setLanguage("fr");' title='<?php echo elgg_echo('rel_label_translation_fr'); ?>'>
                                                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/fr.gif' alt='<?php echo elgg_echo('rel_label_translation_fr'); ?>' title='<?php echo elgg_echo('rel_label_translation_fr'); ?>'>
                                                </a>  
                                                <a href='javascript:setLanguage("es");' title='<?php echo elgg_echo('rel_label_translation_es'); ?>'>
                                                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/es.gif' alt='<?php echo elgg_echo('rel_label_translation_es'); ?>' title='<?php echo elgg_echo('rel_label_translation_es'); ?>'>
                                                </a>  
                                                <a href='javascript:setLanguage("it");' title='<?php echo elgg_echo('rel_label_translation_it'); ?>'>
                                                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/it.gif' alt='<?php echo elgg_echo('rel_label_translation_it'); ?>' title='<?php echo elgg_echo('rel_label_translation_it'); ?>'>
                                                </a>                    
                                                <a href='javascript:setLanguage("nl");' title='<?php echo elgg_echo('rel_label_translation_nl'); ?>'>
                                                    <img   style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/nl.gif' alt='<?php echo elgg_echo('rel_label_translation_nl'); ?>' title='<?php echo elgg_echo('rel_label_translation_nl'); ?>'>
                                                </a>  
                                                <?php } ?>
                                                </div>
                                                <div class="col-md-2 col-xs-2 footer-drop" style="top:15px;">
                                                    <p class="float-right"><a href="<?php echo $site_url ?>impressum" target="_self"><?php echo elgg_echo('rel_label_link_impressum',$dummy); ?></a></p>
                                                </div>
                                                </div>
                                               

                                                </div>