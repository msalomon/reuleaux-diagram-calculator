<?php
/*
 * reuleaux-diagram calculator 
 * elgg-plugin
 * @purpose transform soziocultur, economy and ecology to sustainability
 * with sustainability metrics that are used in the quality-management system
 * @autor manfred salomon 
 * revision 27.07.2017
 * @link http://reuleaux-calculator.eu
 * 
 * page content
 */
global $CONFIG;
$site_url = elgg_get_site_url();
$select_language = $vars['select_language'];
                        if (get_language() <> $select_language) {
                                $new_lang = $_COOKIE['select_language'];
                                $CONFIG->language = $select_language;
                                reload_all_translations();
                        }  
$tokenID = $vars['tokenID'];
$mensch_percent = $vars['mensch'];
$umwelt_percent = $vars['umwelt'];
$wirtschaft_percent = $vars['wirtschaft'];
$menschpunkte = $vars['menschpunkte'];
$umweltpunkte = $vars['umweltpunkte'];
$wirtschaftpunkte = $vars['wirtschaftpunkte'];
$menschmaxpunkte = $vars['menschmaxpunkte'];
$umweltmaxpunkte = $vars['umweltmaxpunkte'];
$wirtschaftmaxpunkte = $vars['wirtschaftmaxpunkte'];
$menschPercent = $vars['mensch'];
$umweltPercent = $vars['umwelt'];
$wirtschaftPercent = $vars['wirtschaft'];
$r_standard = $vars['r_standard'];
$r_human = $vars['r_human'];
$r_environment = $vars['r_environment'];
$r_economic = $vars['r_economic'];
$a_max = $vars['a_max'];
$is_survivable_p_t = $vars['is_survivable_p_t'];
$is_fair_p_t = $vars['is_fair_p_t'];
$is_acceptable_p_t = $vars['is_acceptable_p_t'];
$s_max = $vars['s_max'];
$is_sustainable = $vars['is_sustainable'];
$is_sustainable_p_t = $vars['is_sustainable_p_t'];
$audit_text = $vars['audit_text'];
$was = $vars['was'];
$ampel_background = $vars['ampel_background'];
$ampel_fontcolor = $vars['ampel_fontcolor'];
$ampel_img_panel = $vars['ampel_img_panel'];
$audit_candidate = $vars['audit_candidate'];
$rating_ext = $vars['rating_ext'];
$tokenID = $vars['tokenID'];
$file_guid = $vars['file_guid'];
$image_guid = $vars['image_guid'];
$originalfilename = $vars['originalfilename'];
$called = $vars['called'];

//$js_url = 'mod/reuleaux/vendors/jquery.wijmo.wijupload.js';
//elgg_register_js('wijmoall', $js_url, 'head', 500);
//elgg_load_js('wijmoall');
//$css_url = 'mod/reuleaux/vendors/jquery.wijmo.wijupload.css';
//elgg_register_css('wijmocss', $css_url, 500);
//elgg_load_css('wijmocss');


$css_url = 'mod/reuleaux/vendors/bootstrap.min.css';
elgg_register_css('bootstrap', $css_url, 500);
elgg_load_css('bootstrap');

$css_url = 'mod/reuleaux/vendors/style.css';
elgg_register_css('reuleaux_style', $css_url, 500);
elgg_load_css('reuleaux_style');
$js_url = 'mod/reuleaux/vendors/raphael-min.js';
elgg_register_js('raphael', $js_url, 'head', 500);
elgg_load_js('raphael');

$js_url = 'mod/reuleaux/vendors/bootstrap.min.js';
elgg_register_js('bootstrap', $js_url, 'head', 500);
elgg_load_js('bootstrap');
$js_url = 'mod/reuleaux/vendors/html2canvas.js';
elgg_register_js('html2canvas', $js_url, 'head', 500);
elgg_load_js('html2canvas');
$js_url = 'mod/reuleaux/vendors/html2canvas.svg.js';
elgg_register_js('html2canvassvg', $js_url, 'head', 500);
elgg_load_js('html2canvassvg');
Global $CONFIG;
if (strstr($_SERVER['REDIRECT_URL'],'/en/') || strstr($_SERVER['REDIRECT_URL'],'/de/') || strstr($_SERVER['REDIRECT_URL'],'/fr/') || strstr($_SERVER['REDIRECT_URL'],'/es/') || strstr($_SERVER['REDIRECT_URL'],'/it/') || strstr($_SERVER['REDIRECT_URL'],'/nl/')) {
        $no_flags = True;
}
 else {
    $no_flags = False;     
}
?>
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<?php
?>
<style>

    /* DivTable.com */
    .elgg-layout {
     min-height: 20px; 
}
    .divTable{
        display: table;
        width: 100%;
    }
    .divTableRow {
        display: table-row;
    }
    .divTableHeading {
        background-color: #EEE;
        display: table-header-group;
    }
    .divTableCell, .divTableHead {
        border: 1px solid #999999;
        display: table-cell;
        padding: 3px 10px;
    }
    .divTableHeading {
        background-color: #EEE;
        display: table-header-group;
        font-weight: bold;
    }
    .divTableFoot {
        background-color: #EEE;
        display: table-footer-group;
        font-weight: bold;
    }
    .divTableBody {
        display: table-row-group;
    }
    panel-design-white-border {
        background-color: white;
        border-color: #6168AE;
        border-width: medium;
        border-style: solid;
        padding:0px;
    }
    hr.styleblue{
        border-top: 1px solid #6168AE;
    }
    .stylebluedisclaimer{
        margin-top:-18px;
        color: #6168AE;
        font-size: 70%;
    }
    .boder-padding {
        padding-right: 0px; 
        padding-left: 0px;     
    }
    .panel-design-border {
        background-color: white;
        border-color: #6168AE;
        border-width: medium;
        border-style: solid;
        padding:0px;
    }

</style>
<script id="scriptInit" type="text/javascript">

        $(document).ready(function () {
//            $("#upload").wijupload({
//            });
selecedlanguage = '<?php echo get_language() ?>';
$("#textarea_" + selecedlanguage).show();
//        onetime = false;
//        requestedlanguage = '<?php echo $select_language ?>';
//
//        if (requestedlanguage.length) {
//                if (!onetime) {
//        setLanguage(requestedlanguage) ;  
//        onetime = true;
//                }
//        }
            $(".error").hide();
            $("#singlebutton").attr("disabled", true);
            $(".form-control").on("keyup", function () {
                $(".error").hide();

                if ($.isNumeric($(this).val())) {
                    $(this).parent().find(".error").html("<?php echo elgg_echo('rel_msg_error_entry'); ?>").show();
                    $(this).val('');
                    return;
                }

                var check = $(".form-control").filter(function () {
                    return $.trim($(this).val()) === '';

                });

                if (!check.length) {

                    $("#singlebutton").attr("disabled", false);
//                    if (step2 === true) {
////                        $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>');
//                    }
                } else {
                    $("#singlebutton").attr("disabled", true);
//                    if (step2 === true) {
////                        $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
//                    }
                }

            });
            is_paper_canvas = false;
            sustainable_correct = 0;
            mensch_percent = <?php echo $mensch_percent ?>;
            umwelt_percent = <?php echo $umwelt_percent ?>;
            economy_percent = <?php echo $wirtschaft_percent ?>;
            r_standard = <?php echo $r_standard ?>;
            r_human = <?php echo $r_human ?>;
            r_environment = <?php echo $r_environment ?>;
            r_economic = <?php echo $r_economic ?>;
//                                                                                      // alert(p_standard);
//                                                                                      // alert(f_standard);
            // e. g. 50% Fläche = 21125.919999999995 entsprechen 82.02438661763951 Radius
            $(".txt_human").text($(".txt_human").text() + ' (' + mensch_percent + '%)');

            $(".txt_environment").text($(".txt_environment").text() + ' (' + umwelt_percent + '%)');

            $(".txt_economy").text($(".txt_economy").text() + ' (' + economy_percent + '%)');

            if (is_paper_canvas === false) {

                paper = Raphael("derp", r_standard + 5, r_standard + 6); // for testing delete  5
                paper2 = Raphael("derp2", r_standard + 5, r_standard + 5); // for testing delete  5
                paper3 = Raphael("derp3", r_standard + 5, r_standard + 5); // for testing delete  5
                paper4 = Raphael("derp4", r_standard + 5, r_standard + 5); // for testing delete  5
                paper5 = Raphael("derp5", r_standard + 5, r_standard + 5); // for testing delete  5
                is_paper_canvas = true;
            }
            //      paper.clear();
            // Zeichne Kreis mit X-Radius an Postion Gleichseitiges Dreieck 
            var circle = paper.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
            var circle2 = paper.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
            var circle3 = paper.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2
            var circlex = paper2.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
            var circlex2 = paper2.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
            var circlex3 = paper2.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2
            var circle3x = paper3.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
            var circle3x2 = paper3.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
            var circle3x3 = paper3.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2
            var circle4x1 = paper4.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
            var circle4x2 = paper4.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
            var circle4x3 = paper4.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2
            var circle5x1 = paper5.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
            var circle5x2 = paper5.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
            var circle5x3 = paper5.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2
            r_116 = 116;                                                                        // 
            // Schnittflächen 100%
            a_max = <?php echo $a_max ?>;

                            
            is_survivable_p_t = <?php echo $is_survivable_p_t ?>;
            $(".gauge3-text").text('<?php echo elgg_echo("rel_survivable") ?>' + ' (' + is_survivable_p_t + '%)');


            is_fair_p_t = <?php echo $is_fair_p_t ?>;
            $(".gauge4-text").text('<?php echo elgg_echo("rel_fair") ?>' + ' (' + is_fair_p_t + '%)');

            is_acceptable_p_t = <?php echo $is_acceptable_p_t ?>;
            $(".gauge2-text").text('<?php echo elgg_echo("rel_acceptable") ?>' + ' (' + is_acceptable_p_t + '%)');

            s_max = <?php echo $s_max ?>;
            is_sustainable = <?php echo $is_sustainable ?>;

            $(".total_percentage").text(<?php echo $is_sustainable_p_t ?> + '%');
            $(".gauge1-text").text('<?php echo elgg_echo("rel_sustainability") ?>' + ' (' + <?php echo $is_sustainable_p_t ?> + '%)');

            var rating_ext = <?php echo $rating_ext ?>;
//            // alert(rating_ext);
            rating_ext = rating_ext.toFixed(0);
//            // alert(rating_ext);
            rating_ext = rating_ext.toString();
            ratingcode_content(rating_ext);
            $(".ratingcode_img").attr('src', '<?php echo $site_url ?>' + 'mod/reuleaux/images/codes/' + rating_ext + '.jpg')
            //           $(".ratingcode_img_arrow").attr('src', '<?php echo $site_url ?>' + 'mod/reuleaux/images/codes/' + rating_ext + '.jpg')
            circle.attr("fill", "#FF3A3A");
            circle.attr("stroke", "whitesmoke");
            circle.animate({"fill-opacity": .8}, 600);

            circle3.attr("fill", "#FFCE8C");
            circle3.animate({"fill-opacity": .5}, 600);
            circle3.attr("stroke", "#ffffff");

            // Sets the fill attribute of the circle to red (#f00)
            circle2.attr("fill", "#68C2FF");
            circle2.animate({"fill-opacity": .6}, 600);
            //Sets the stroke attribute of the circle to white
            circle2.attr("stroke", "#ffffff");
            is_paper_canvas = true;

            circle.attr("fill", "#FF3A3A");
            circle.attr("stroke", "darkgray");
            circle.animate({"fill-opacity": .8}, 600);
                       // Sets the fill attribute of the circle to red (#f00)
            circle2.attr("fill", "#68C2FF");
            circle2.animate({"fill-opacity": .6}, 600);
            //Sets the stroke attribute of the circle to white
            circle2.attr("stroke", "darkgray");

            circle3.attr("fill", "#FFCE8C");
            circle3.animate({"fill-opacity": .5}, 600);
            circle3.attr("stroke", "darkgray");

 


            circlex.attr("fill", "#FF3A3A");
            circlex.attr("stroke", "#999999");
            circlex.animate({"fill-opacity": .8}, 600);

            circlex3.attr("fill", "#FFCE8C");
            circlex3.animate({"fill-opacity": .5}, 600);
            circlex3.attr("stroke", "#999999");

            // Sets the fill attribute of the circle to red (#f00)
            circlex2.attr("fill", "#68C2FF");
            circlex2.animate({"fill-opacity": .6}, 600);
            //Sets the stroke attribute of the circle to white
            circlex2.attr("stroke", "#999999");

            circle3x.attr("fill", "#FF3A3A");
            circle3x.attr("stroke", "#999999");
            circle3x.animate({"fill-opacity": .8}, 600);

            circle3x3.attr("fill", "#FFCE8C");
            circle3x3.animate({"fill-opacity": .5}, 600);
            circle3x3.attr("stroke", "#999999");

            // Sets the fill attribute of the circle to red (#f00)
            circle3x2.attr("fill", "#68C2FF");
            circle3x2.animate({"fill-opacity": .6}, 600);
            //Sets the stroke attribute of the circle to white
            circle3x2.attr("stroke", "#999999");


            circle4x1.attr("fill", "#FF3A3A");
            circle4x1.attr("stroke", "#999999");
            circle4x1.animate({"fill-opacity": .8}, 600);

            circle4x3.attr("fill", "#FFCE8C");
            circle4x3.animate({"fill-opacity": .5}, 600);
            circle4x3.attr("stroke", "#999999");

            // Sets the fill attribute of the circle to red (#f00)
            circle4x2.attr("fill", "#68C2FF");
            circle4x2.animate({"fill-opacity": .6}, 600);
            //Sets the stroke attribute of the circle to white
            circle4x2.attr("stroke", "#999999");
            circle5x1.attr("fill", "#FF3A3A");
            circle5x1.attr("stroke", "#999999");
            circle5x1.animate({"fill-opacity": .8}, 600);

            circle5x3.attr("fill", "#FFCE8C");
            circle5x3.animate({"fill-opacity": .5}, 600);
            circle5x3.attr("stroke", "#999999");

            // Sets the fill attribute of the circle to red (#f00)
            circle5x2.attr("fill", "#68C2FF");
            circle5x2.animate({"fill-opacity": .6}, 600);
            //Sets the stroke attribute of the circle to white
            circle5x2.attr("stroke", "#999999");
            function ratingcode_content(code) {
                switch (code) {
                    case '22':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_22'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_22'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_22'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_22'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '21':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_21'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_21'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_21'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_21'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '20':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_20'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_20'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_20'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_20'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '19':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_19'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_19'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_19'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_19'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '18':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_18'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_18'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_18'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_18'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '17':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_17'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_17'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_17'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_17'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '16':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_16'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_16'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_16'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_16'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '15':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_15'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_15'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_15'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_15'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '14':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_14'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_14'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_14'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_14'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '13':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_13'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_13'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_13'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_13'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '12':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_12'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_12'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_12'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_12'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '11':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_11'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_11'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_11'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_11'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '10':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_10'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_10'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_10'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_10'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '9':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_9'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_9'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_9'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_9'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '8':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_8'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_8'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_8'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_8'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '7':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_7'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_7'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_7'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_7'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '6':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_6'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_6'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_6'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_6'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '5':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_5'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_5'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_5'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_5'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '4':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_4'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_4'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_4'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_4'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '3':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_3'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_3'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_3'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_3'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '2':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_2'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_2'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_2'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_2'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '1':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_1'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_1'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_1'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_1'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '0':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_1'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_1'); ?>');
                        $(".txt_code").text('<?php echo elgg_echo('rel_code_1'); ?>');
                        dummy = '<?php echo elgg_echo('rel_rated_1'); ?>';
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                }
            }
            function showDialog() {
                var currentFolder = $("#fileexplorer").wijfileexplorer("option", "currentFolder");
                //debugger;
                var action = "./upload.ashx?folder=" + currentFolder;
                $("#upload").wijupload("option", "action", action);
                $('#dialog').wijdialog({title: "Upload to: " + currentFolder}).wijdialog("open");
            }
            $("#flag_de").dblclick(function () {
                   stextarea('de'); 
                  }
        ); 
                   $("#flag_es").dblclick(function () {
                   stextarea('es'); 
                  }
        );   
                   $("#flag_en").dblclick(function () {
                   stextarea('en'); 
                  }
        ); 
                    $("#flag_fr").dblclick(function () {
                   stextarea('fr'); 
                  }
        ); 
                   $("#flag_it").dblclick(function () {
                   stextarea('it'); 
                  }
        );   
                   $("#flag_nl").dblclick(function () {
                   stextarea('nl'); 
                  }
        ); 
//                           $("#flag_tr").dblclick(function () {
//                   stextarea('tr'); 
//                  }
//        ); 
            $("#flag_de").click(function () {
                   sstextarea('de'); 
                  }
        ); 
                   $("#flag_es").click(function () {
                   sstextarea('es'); 
                  }
        );   
                   $("#flag_en").click(function () {
                   sstextarea('en'); 
                  }
        ); 
                    $("#flag_fr").click(function () {
                   sstextarea('fr'); 
                  }
        ); 
                   $("#flag_it").click(function () {
                   sstextarea('it'); 
                  }
        );   
                   $("#flag_nl").click(function () {
                   sstextarea('nl'); 
                  }
        ); 
//                           $("#flag_tr").click(function () {
//                   sstextarea('tr'); 
//                  }
//        ); 
                    $(".form-control").on("keyup", function () {
//                $(".error").hide();


//                var check = $(".form-control").filter(function () {
//                    return $.trim($(this).val()) === '';
//
//                });   inputtextarea_de
                 var value = $('#inputtextarea_en').val();
    if ( value.length > 0 && value !== $('#inputtextarea_en').attr('placeholder')) { 
                        $("#check_en").show();
                }
                else {
                     $("#check_en").hide();  
        }
        
                           var value = $('#inputtextarea_de').val();
    if ( value.length > 0 && value !== $('#inputtextarea_de').attr('placeholder')) { 
                        $("#check_de").show();
                }
                else {
                     $("#check_de").hide();  
        }
         
                           var value = $('#inputtextarea_fr').val();
    if ( value.length > 0 && value !== $('#inputtextarea_fr').attr('placeholder')) { 
                        $("#check_fr").show();
                }
                else {
                     $("#check_fr").hide();  
        }
        
                           var value = $('#inputtextarea_es').val();
    if ( value.length > 0 && value !== $('#inputtextarea_es').attr('placeholder')) { 
                        $("#check_es").show();
                }
                else {
                     $("#check_es").hide();  
        }
                                   var value = $('#inputtextarea_it').val();
    if ( value.length > 0 && value !== $('#inputtextarea_it').attr('placeholder')) { 
                        $("#check_it").show();
                }
                else {
                     $("#check_it").hide();  
        }
          
                           var value = $('#inputtextarea_nl').val();
    if ( value.length > 0 && value !== $('#inputtextarea_nl').attr('placeholder')) { 
                        $("#check_nl").show();
                }
                else {
                     $("#check_nl").hide();  
        }
//         var value = $('#inputtextarea_tr').val();
//    if ( value.length > 0 && value !== $('#inputtextarea_tr').attr('placeholder')) { 
//                       // $("#check_tr").show();
//                }
//                else {
//                   //  $("#check_tr").hide();  
//        }
                    });
function sstextarea(lang) {
                //    if (!check.length) {
//                alert($("#textarea_de").is(':visible')) ;
//                alert($("#textarea_de").val()) ;
//                alert($("#inputtextarea_de").val().length) ;
        if ( $("#textarea_en").is(':visible') ){
        langselected = "en";
}
        if ( $("#textarea_de").is(':visible') ){
        langselected = "de";
}
        if ( $("#textarea_fr").is(':visible') ){
        langselected = "fr";
}
        if ( $("#textarea_es").is(':visible') ){
        langselected = "es";
}
        if ( $("#textarea_it").is(':visible') ){
        langselected = "it";
}
        if ( $("#textarea_nl").is(':visible') ){
        langselected = "nl";
}
//        if ( $("#textarea_tr").is(':visible') ){
//        langselected = "tr";
//}
//alert(langselected);
//alert($("#inputtextarea_" + langselected).val().length) ;
 $("#textarea_de").hide();
 $("#textarea_es").hide();
 $("#textarea_en").hide();
  $("#textarea_fr").hide();
 $("#textarea_it").hide();
 $("#textarea_nl").hide();
// $("#textarea_tr").hide();
$("#textarea_" + lang).show(); 
}
function stextarea(lang) {
                //    if (!check.length) {
//                alert($("#textarea_de").is(':visible')) ;
//                alert($("#textarea_de").val()) ;
//                alert($("#inputtextarea_de").val().length) ;
        if ( $("#textarea_en").is(':visible') ){
        langselected = "en";
}
        if ( $("#textarea_de").is(':visible') ){
        langselected = "de";
}
        if ( $("#textarea_fr").is(':visible') ){
        langselected = "fr";
}
        if ( $("#textarea_es").is(':visible') ){
        langselected = "es";
}
        if ( $("#textarea_it").is(':visible') ){
        langselected = "it";
}
        if ( $("#textarea_nl").is(':visible') ){
        langselected = "nl";
}
//       if ( $("#textarea_tr").is(':visible') ){
//        langselected = "tr";
//}
//alert(langselected);
//alert($("#inputtextarea_" + langselected).val().length) ;
 $("#textarea_de").hide();
 $("#textarea_es").hide();
 $("#textarea_en").hide();
  $("#textarea_fr").hide();
 $("#textarea_it").hide();
 $("#textarea_nl").hide();
// $("#textarea_tr").hide();
$("#textarea_" + lang).show(); 
//alert(encodeURI($("#inputtextarea_" + langselected).val()));
if ( $("#inputtextarea_" + langselected).val().length > 1){
        var url = "https://translate.google.com/#" + langselected + "/en/"  + encodeURI($("#inputtextarea_" + langselected).val());
        var url2 = "https://translate.google.com/#" + langselected + "/de/"  + encodeURI($("#inputtextarea_" + langselected).val());
        var url3 = "https://translate.google.com/#" + langselected + "/fr/"  + encodeURI($("#inputtextarea_" + langselected).val());
        var url4 = "https://translate.google.com/#" + langselected + "/es/"  + encodeURI($("#inputtextarea_" + langselected).val());
        var url5 = "https://translate.google.com/#" + langselected + "/it/"  + encodeURI($("#inputtextarea_" + langselected).val());
        var url6 = "https://translate.google.com/#" + langselected + "/nl/"  + encodeURI($("#inputtextarea_" + langselected).val());
//        var url7 = "https://translate.google.com/#" + langselected + "/tr/"  + encodeURI($("#inputtextarea_" + langselected).val());
var win = window.open(url, '_blank');
var win = window.open(url2, '_blank');
var win = window.open(url3, '_blank');
var win = window.open(url4, '_blank');
var win = window.open(url5, '_blank');
var win = window.open(url6, '_blank');
//var win = window.open(url7, '_blank');
if (win) {
    //Browser has allowed it to be opened
    win.focus();
} else {
    //Browser has blocked it
    alert('Please allow popups for this website');
}
}
}


            function setLanguage(lang_id) {
                setCookie("client_language", lang_id, 30);
                document.location.href = document.location.href;
            }
            // Cookie to remember language
            function setCookie(c_name, value, expiredays) {
                var exdate = new Date();
                exdate.setDate(exdate.getDate() + expiredays);
                document.cookie = c_name + "=" + escape(value) + ";Path=/" + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
            }
        });

        $(function () {
            $("#check-input").click(function () {
                $("#Calc").hide();
                $("#img-in").show();
                html2canvas($("#img-in"), {
                    onrendered: function (canvas) {
                        theCanvas = canvas;
                        //    document.body.appendChild(canvas);

                        // Convert and download as image 
//                windows.Canvas2Image.saveAsPNG(canvas); 
                        $('canvas').remove();
                        $("#img-out").append(canvas);
                        $("#img-in").hide();

                        $("#img-out").show();
                        $(".form-vertical").show();
                        $('body').css('background-image', 'url(./images/white.png)');

                        $("#go-back").show();
                        // Clean up 
                        //document.body.removeChild(canvas);
                    }
                });
            });


        });
        $(function () {
            $("#go-back").click(function () {



                $("#img-out").hide();
                $(".form-vertical").hide();
                $("#Calc").show();
                $('body').css('background-image', 'url(' + '<?php echo $site_url ?>' + 'mod/reuleaux/images/phone.png)');
                $("#go-back").hide();
            });


        });

</script>

<div id="Calc">
    <div class="container con-des">

        <header>


            <div class="clearfix top-space" >


                <div class="row">
                    <div class="col-md-7 col-sm-5 col-xs-8" style="padding-right:0px; color:blue;">
                        <div class="header-text">
                            <span class="clsfontsmall"><?php echo elgg_echo('rel_main_label') ?></span><br/>
                            <span class="bold clsfontsmalltext"><?php echo elgg_echo('rel_main_label_sub') ?></span>
                        </div>
                    </div>
                    <div class="col-md-5 col-sm-7 col-xs-4">
                        <img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux-diagram-logo.png" alt="calculate sustainability" class="img-responsive logo">
                    </div>	
                </div>
            </div>
        </header>  
        <div class="cf-padding">
            <div class="row well well-sm bgbutton panel-padding msg-space" style="margin-top: 0px; height: 30px;" >
                <div class="col-xs-12"      style="margin-top: -6px;margin-left: -26px"> 
                    <span class="clsfontsmall" style="color: #6168AE;"><strong><?php echo elgg_echo('rel_main_label_result') ?></strong></span>

                </div>  

            </div></div>

 
        
        <!--result-->
        <div class="con-des" style="    height: 337px; margin-top: -5px; margin-left: -2px" >             
            <div class="relframe">
                <div class="relTable  "  >
                    <div class="relTableBody">

                        <div class="relTableRow">
                            <?php
                            if ($audit_candidate != '') {
                                    ?>

                                    <div class="relTableCell" style="font-weight: bold;  border-bottom-width: 0px;"><?php echo $audit_candidate ?></div>
                            <?php } ?>
                        </div></div></div>  
<div class="relframe" style="background:white;padding:0px;margin: 0px;border-width: 0px;margin-top: 0px">
                <div class="relTable" style="margin-top:0px" >
                    <div class="relTableBody">

                        <div class="relTableRow">
                            <div class="relTableCell" style="border-right-width: 0px; border-bottom-width: 0px;" ><?php echo elgg_echo('rel_sustainability_sub') ?></div>
                            <div class="relTableCell" style="border-right-width: 0px; border-bottom-width: 0px;" ><span class="total_percentage" style="color: black;font-weight: normal">0.0%</span></div>
                            <div class="relTableCell" style="border-right-width: 0px; border-bottom-width: 0px;" ><?php echo elgg_echo('rel_rating'); ?></div>
                            <div class="relTableCell" style=" border-bottom-width: 0px;" ><span class="txt_code" style="margin-left:-1px;"></span></div>

                        </div></div></div> 

                <div class="relTable"  >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class="relTableCell" style="border-bottom-width: 0px;" ><span style="font-size:12px;" class="txt_bonitaet"></span></div>
                        </div></div></div>   
                <div class="relTable"  >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class=" text-scroll" style="height:40px;border: 1px solid #999999;
		padding: 3px 6px;
            font-family: sans-serif;
    line-height: normal;
            padding-right: 0px;
            border-bottom-width: 0px; 
   ">
                                <?php if ($audit_text != '') { ?>

                                <span style="font-size:12px;"><?php echo $audit_text ?></span>
                                <?php } else {
                                        ?>
                                        <span style="font-size:12px; 	" class="txt_rated_excerpt" ></span>
                                      <?php } ?>

                            </div>
                        </div></div></div>  

                <!--rating-->

                <!--reuleaux-diagramm-->
                <div class="relTable"  >

                    <div class="relTableBody">
                        <div class="relTableRow" >

                            <div class="relTableCell" style="width:136px; height: 128px; border-bottom-width: 0px; "><div  style="width:118px;  margin-left: 3.5px; padding: 0;z-index: 7  " id="derp">
                                    <div style=" margin-top:0px; margin-left:1px;">

                                        <div class="a_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -93px;margin-left: 47.3px;width: 19px;text-align: center; z-index: 700000;">A</div>

                                        <div class="b_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top:31px;margin-left: 77px;width: 19px;text-align: left;">C</div>

                                        <div class="c_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -10.9px;margin-left: 29px;width: 19px;text-align: left;">B</div> 
                                    </div>
                                </div></div>

                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:32px; padding-top:6px; padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px; margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div class="gauge2-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:31px; padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_survivable") ?>'><div class="gauge3-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:32px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_fair") ?>'><div class="gauge4-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:33px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_sustainability") ?>'><div class="gauge1-text" style=" font-size: 11px;display: inline;" ></div></div>

                        </div></div></div>
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/human.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_human") ?></span></div>
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/economy.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_economy") ?></span></div>                       
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/environment.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_environment") ?></span></div>
                        </div></div></div>
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <?php if (!$was == 'btn_percent') { ?>
                            <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">A (<?php echo round($menschPercent, 1) ?>%)</span></div>
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">B (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>                       
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">C (<?php echo round($umweltPercent, 1) ?>%)</span></div>
                        <?php }
                        else {?>
                         <div class="relTableCell" style="width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">A (<?php echo round($menschPercent, 1) ?>%)</span></div>
                            <div class="relTableCell" style="border-left-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">B (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>                       
                            <div class="relTableCell" style="border-left-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">C (<?php echo round($umweltPercent, 1) ?>%)</span></div>
                        <?php }?>    
                        </div></div></div>

                <!--reuleaux-diagramm-->


                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <?php if ($was == 'btn_percent') { ?>
<!--                                    <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>
                                    <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($wirtschaftPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>                       
                                    <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($umweltPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>-->
                            <?php } ?>


                        </div></div></div>
                <div class="relTable" style=" " >
                    <div class="relTableBody">
                        <div class="relTableRow">  
                            <?php if ($was == 'btn_points') {
                                    ?>
                                    <div class="relTableCell" style=" border-top-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                                    <div class="relTableCell" style="border-left-width: 0px; border-top-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($wirtschaftpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>                       
                                    <div class="relTableCell" style="border-left-width: 0px; border-top-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($umweltpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                            <?php } ?>
                        </div></div></div> 

                <!--atachment-->
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <?php
                        if ($originalfilename != '') {
                                ?>
                                <div class="relTableRow">
                                    <div class="relTableCell" style="border-top-width: 0px;"><span style="font-size: 11px;"><?php echo elgg_echo('rel_Anlage') ?><a href='<?php echo elgg_get_inline_url(get_entity($file_guid)) ?>'><?php echo (strlen($originalfilename) > 25 ? substr($originalfilename, 0, 25) . '. . . ' : substr($originalfilename, 0, 25)) ?></span></div>
                                </div>
                        <?php } ?>
                    </div></div>   


            </div>                 






        </div> </div> <!-- relframe-->
 

 

        <!--result-->

        <!--buttons-->
        <div class="row" >
            <div class="col-md-4  btn-padding" style=" margin-top: 5px; margin-left: -1px"><a id="btn_zurück"  type="button" href="<?php echo $site_url ?>rate" target="_blank" class="btn btn-primary btn-punkte"><?php echo elgg_echo('rel_btn_new') ?></a>
            </div>
            <div class=" col-md-8 btn-padding" style="margin-top: 5px; margin-left: -1px" >
                <button type="button" id="check-input" class="btn btn-block button-step-3" >Docu-Clipps</button>
            </div>




        </div>                                         

        <!--buttons-->

          <footer>
                                                                                                <div class="footer-text" >

                                                                                                    <div class="col-md-2 col-xs-2 footer-drop" style="top:-13px;">
                                                                                                        <p> <a href="<?php echo $site_url ?>info" target="_self"><?php echo elgg_echo('rel_label_link_information'); ?></a></p>
                                                                                                    </div>
                                                                                                    <div class="col-md-8 col-xs-8 language_selector footer-drop-center"style="top:-8px;">
                                                                                                        <a href='javascript:setLanguage("en");' title='<?php echo elgg_echo('rel_label_translation_en'); ?>'>
                                                                                                            <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/en.gif' alt='<?php echo elgg_echo('rel_label_translation_en'); ?>' title='<?php echo elgg_echo('rel_label_translation_en'); ?>'>
                                                                                                        </a>
                                                                                                        <a href='javascript:setLanguage("de");' title='<?php echo elgg_echo('rel_label_translation_de'); ?>'>
                                                                                                            <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/de.gif' alt='<?php echo elgg_echo('rel_label_translation_de'); ?>' title='<?php echo elgg_echo('rel_label_translation_de'); ?>'>
                                                                                                            <a>
                                                                                                                <a href='javascript:setLanguage("fr");' title='<?php echo elgg_echo('rel_label_translation_fr'); ?>'>
                                                                                                                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/fr.gif' alt='<?php echo elgg_echo('rel_label_translation_fr'); ?>' title='<?php echo elgg_echo('rel_label_translation_fr'); ?>'>
                                                                                                                </a>  
                                                                                                                <a href='javascript:setLanguage("es");' title='<?php echo elgg_echo('rel_label_translation_es'); ?>'>
                                                                                                                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/es.gif' alt='<?php echo elgg_echo('rel_label_translation_es'); ?>' title='<?php echo elgg_echo('rel_label_translation_es'); ?>'>
                                                                                                                </a>  
                                                                                                                <a href='javascript:setLanguage("it");' title='<?php echo elgg_echo('rel_label_translation_it'); ?>'>
                                                                                                                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/it.gif' alt='<?php echo elgg_echo('rel_label_translation_it'); ?>' title='<?php echo elgg_echo('rel_label_translation_it'); ?>'>
                                                                                                                </a>                    
                                                                                                                <a href='javascript:setLanguage("nl");' title='<?php echo elgg_echo('rel_label_translation_nl'); ?>'>
                                                                                                                    <img   style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/nl.gif' alt='<?php echo elgg_echo('rel_label_translation_nl'); ?>' title='<?php echo elgg_echo('rel_label_translation_nl'); ?>'>
                                                                                                                </a>  
                                                                                                                </div>
                                                                                                                <div class="col-md-2 col-xs-2 footer-drop" style="top:-13px;">
                                                                                                                    <p class="float-right"><a href="<?php echo $site_url ?>impressum" target="_self"><?php echo elgg_echo('rel_label_link_impressum'); ?></a></p>
                                                                                                                </div>
                                                                                                                </div>
                                                                                                                </footer>

                                                                                                                </div>
    </div>                                 
</div>

<!--body-->
<!--Beginn Snapshot-->
<div id="img-in" style='display:none; background:white;width:310px; padding:5px'  >
    <!--Picture Clipp for Ducumentation-->
    <div class="col-md-12"><img  style="height:120px; width:auto; padding:5px; margin-bottom:10px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/CLIPP-FOR-DOCU-<?php echo get_language() ?>.jpg"  ></div>
    <!--Picture Clipp for Ducumentation-->
    <div class="col-md-12 center"></div>

            
            <div class="con-des">
                <div class="relTable  "  >
                    <div class="relTableBody">

                        <div class="relTableRow">
                            <?php
                            if ($audit_candidate != '') {
                                    ?>

                                    <div class="relTableCell" style="font-weight: bold;  border-bottom-width: 0px;"><?php echo $audit_candidate ?></div>
                            <?php } ?>
                        </div></div></div>  
<div class="con-des" style="background:white;padding:0px;margin: 0px;border-width: 0px;margin-top: 0px">
                <div class="relTable" style="margin-top:0px" >
                    <div class="relTableBody">

                        <div class="relTableRow">
                            <div class="relTableCell" style="border-right-width: 0px; border-bottom-width: 0px;" ><?php echo elgg_echo('rel_sustainability_sub') ?></div>
                            <div class="relTableCell" style="border-right-width: 0px; border-bottom-width: 0px;" ><span class="total_percentage" style="color: black;font-weight: normal">0.0%</span></div>
                            <div class="relTableCell" style="border-right-width: 0px; border-bottom-width: 0px;" ><?php echo elgg_echo('rel_rating'); ?></div>
                            <div class="relTableCell" style=" border-bottom-width: 0px;" ><span class="txt_code" style="margin-left:-1px;"></span></div>

                        </div></div></div> 

                <div class="relTable"  >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class="relTableCell" style="border-bottom-width: 0px;" ><span style="font-size:12px;" class="txt_bonitaet"></span></div>
                        </div></div></div>   
                <div class="relTable"  >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class="text" style="text-align:justify; color:black; height:auto;border: 1px solid #999999;
		padding: 3px 6px;
            font-family: sans-serif;
    line-height: normal;
            padding-right: 0px;
            border-bottom-width: 0px; 
            padding-right:4px
   ">
                                <?php if ($audit_text != '') { ?>

                                <span style="font-size:12px;"><?php echo $audit_text ?></span>
                                <?php } else {
                                        ?>
                                        <span style="font-size:12px; 	" class="txt_rated_excerpt" ></span>
                                      <?php } ?>

                            </div>
                        </div></div></div>  

                <!--rating-->

                <!--reuleaux-diagramm-->
                <div class="relTable"  >

                    <div class="relTableBody">
                        <div class="relTableRow" >

                            <div class="relTableCell" style="width:136px; height: 128px; border-bottom-width: 0px; "><div  style="width:118px;  margin-left:4px; padding: 0;z-index: 7  " id="derp2">
                                    <div style=" margin-top:0px; margin-left:1px;">

                                        <div class="a_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -90px;margin-left: 47px;width: 19px;text-align: center; z-index: 700000;">A</div>

                                        <div class="b_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top:30px;margin-left: 77px;width: 19px;text-align: left;">C</div>

                                        <div class="c_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -11px;margin-left: 30px;width: 19px;text-align: left;">B</div> 
                                    </div>
                                </div></div>

                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:32px; padding-top:6px; padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px; margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div class="gauge2-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:31px; padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_survivable") ?>'><div class="gauge3-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:32px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_fair") ?>'><div class="gauge4-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:33px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_sustainability") ?>'><div class="gauge1-text" style=" font-size: 11px;display: inline;" ></div></div>

                        </div></div></div>
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/human.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_human") ?></span></div>
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/economy.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_economy") ?></span></div>                       
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/environment.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_environment") ?></span></div>
                        </div></div></div>
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <?php if (!$was == 'btn_percent') { ?>
                            <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">A (<?php echo round($menschPercent, 1) ?>%)</span></div>
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">B (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>                       
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">C (<?php echo round($umweltPercent, 1) ?>%)</span></div>
                        <?php }
                        else {?>
                         <div class="relTableCell" style="width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">A (<?php echo round($menschPercent, 1) ?>%)</span></div>
                            <div class="relTableCell" style="border-left-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">B (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>                       
                            <div class="relTableCell" style="border-left-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">C (<?php echo round($umweltPercent, 1) ?>%)</span></div>
                        <?php }?>    
                        </div></div></div>

                <!--reuleaux-diagramm-->


                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <?php if ($was == 'btn_percent') { ?>
<!--                                    <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>
                                    <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($wirtschaftPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>                       
                                    <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($umweltPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>-->
                            <?php } ?>


                        </div></div></div>
                <div class="relTable" style=" " >
                    <div class="relTableBody">
                        <div class="relTableRow">  
                            <?php if ($was == 'btn_points') {
                                    ?>
                                    <div class="relTableCell" style=" border-top-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                                    <div class="relTableCell" style="border-left-width: 0px; border-top-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($wirtschaftpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>                       
                                    <div class="relTableCell" style="border-left-width: 0px; border-top-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($umweltpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                            <?php } ?>
                        </div></div></div> 

                <!--atachment-->
<!--                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <?php
                        if ($originalfilename != '') {
                                ?>
                                <div class="relTableRow">
                                    <div class="relTableCell" style="border-top-width: 0px;"><span style="font-size: 11px;"><?php echo elgg_echo('rel_Anlage') ?><a href='<?php echo elgg_get_inline_url(get_entity($file_guid)) ?>'><?php echo (strlen($originalfilename) > 25 ? substr($originalfilename, 0, 25) . '. . . ' : substr($originalfilename, 0, 25)) ?></span></div>
                                </div>
                        <?php } ?>
                    </div></div>   -->


           </div>  </div> 





       









   
    <!--Clipp 2--> 
    <!--result-->

    

    <!--atachment-->


    <!--No attachments!! Attachments links the Clipp with the attachment-->


    <!--attachment-->

    <!--result-->  

    <!--Clipp 2--> 
    <!--result-->

    <!--Picture Public Domainn-->
    <div class="col-md-12 center"><img  style="height:60px; width:auto; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/public_domain.png"  ></div>
    <!--Picture Public Domainn--> 

           <div class="con-des" style="color:black;">

<div class="con-des" style="color:black; background:white;padding:0px;margin: 0px;border-width: 0px;margin-top: 0px">

                <div class="relTable"  >

                    <div class="relTableBody">
                        <div class="relTableRow" >

                            <div class="relTableCell" style="width:136px; height: 128px; border-bottom-width: 0px; "><div  style="width:118px;  margin-left:4px; padding: 0;z-index: 7  " id="derp3">
                                    <div style=" margin-top:0px; margin-left:1px;">

                                        <div class="a_circle" style="font-weight: normal;font-size: 10px;margin-top: -90px;margin-left: 47px;width: 19px;text-align: center; z-index: 700000;">A</div>

                                        <div class="b_circle" style="font-weight: normal;font-size: 10px;margin-top:30px;margin-left: 77px;width: 19px;text-align: left;">C</div>

                                        <div class="c_circle" style="font-weight: normal;font-size: 10px;margin-top: -11px;margin-left: 30px;width: 19px;text-align: left;">B</div> 
                                    </div>
                                </div></div>

                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:32px; padding-top:6px; padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px; margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div class="gauge2-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:31px; padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_survivable") ?>'><div class="gauge3-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:32px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_fair") ?>'><div class="gauge4-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:33px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_sustainability") ?>'><div class="gauge1-text" style=" font-size: 11px;display: inline;" ></div></div>

                        </div></div></div>
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/human.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_human") ?></span></div>
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/economy.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_economy") ?></span></div>                       
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/environment.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_environment") ?></span></div>
                        </div></div></div>
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <?php if (!$was == 'btn_percent') { ?>
                            <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">A (<?php echo round($menschPercent, 1) ?>%)</span></div>
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">B (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>                       
                            <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">C (<?php echo round($umweltPercent, 1) ?>%)</span></div>
                        <?php }
                        else {?>
                         <div class="relTableCell" style="width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">A (<?php echo round($menschPercent, 1) ?>%)</span></div>
                            <div class="relTableCell" style="border-left-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">B (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>                       
                            <div class="relTableCell" style="border-left-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">C (<?php echo round($umweltPercent, 1) ?>%)</span></div>
                        <?php }?>    
                        </div></div></div>

                <!--reuleaux-diagramm-->


                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <?php if ($was == 'btn_percent') { ?>
<!--                                    <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>
                                    <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($wirtschaftPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>                       
                                    <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($umweltPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>-->
                            <?php } ?>


                        </div></div></div>
                <div class="relTable" style=" " >
                    <div class="relTableBody">
                        <div class="relTableRow">  
                            <?php if ($was == 'btn_points') {
                                    ?>
                                    <div class="relTableCell" style=" border-top-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                                    <div class="relTableCell" style="border-left-width: 0px; border-top-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($wirtschaftpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>                       
                                    <div class="relTableCell" style="border-left-width: 0px; border-top-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($umweltpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                            <?php } ?>
                        </div></div></div> 

                <!--atachment-->
<!--                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <?php
                        if ($originalfilename != '') {
                                ?>
                                <div class="relTableRow">
                                    <div class="relTableCell" style="border-top-width: 0px;"><span style="font-size: 11px;"><?php echo elgg_echo('rel_Anlage') ?><a href='<?php echo elgg_get_inline_url(get_entity($file_guid)) ?>'><?php echo (strlen($originalfilename) > 25 ? substr($originalfilename, 0, 25) . '. . . ' : substr($originalfilename, 0, 25)) ?></span></div>
                                </div>
                        <?php } ?>
                    </div></div>   -->


           </div>  </div> 


    <div class="col-md-12 center"></div>
    <div class="row center"><img center style="height:60px; width:auto; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/public_domain.png"  ></div>
<div class="col-md-12 center"></div>

               <div class="relframe" style="border:1px solid; 
         border-radius:10px;
         padding:15px;
         border-color: darkgray;">
                <div class="relTable  "  >
                    <div class="relTableBody">

                        <div class="relTableRow">
                            <?php
                            if ($audit_candidate != '') {
                                    ?>

                                    <div class="relTableCell" style="font-weight: bold;  border-width: 0px;"><?php echo $audit_candidate ?></div>
                            <?php } ?>
                        </div></div></div>  
<div class="relframe" style="background:white;padding:0px;margin: 0px;border-width: 0px;margin-top: 0px">
                <div class="relTable" style="margin-top:0px" >
                    <div class="relTableBody">

                        <div class="relTableRow">
                            <div class="relTableCell" style="border-width: 0px; border-bottom-width: 0px;" ><?php echo elgg_echo('rel_sustainability_sub') ?>:</div>
                            <div class="relTableCell" style="border-width: 0px; border-bottom-width: 0px;" ><span class="total_percentage" style="color: black;font-weight: normal">0.0%</span></div>
                            <div class="relTableCell" style="border-width: 0px; border-bottom-width: 0px;" ><?php echo elgg_echo('rel_rating'); ?>:</div>
                            <div class="relTableCell" style=" border-width: 0px;" ><span class="txt_code" style="margin-left:-1px;"></span></div>

                        </div></div></div> 

           

                <!--rating-->

                <!--reuleaux-diagramm-->
                <div class="relTable"  >

                    <div class="relTableBody">
                        <div class="relTableRow" >

                            <div class="relTableCell" style="width:136px; height: 128px; border-width: 0px; "><div  style="width:118px;  margin-left:4px; padding: 0;z-index: 7  " id="derp4">
                                    <div style=" margin-top:0px; margin-left:1px;">

                                        <div class="a_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -90px;margin-left: 47px;width: 19px;text-align: center; z-index: 700000;">A</div>

                                        <div class="b_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top:30px;margin-left: 77px;width: 19px;text-align: left;">C</div>

                                        <div class="c_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -11px;margin-left: 30px;width: 19px;text-align: left;">B</div> 
                                    </div>
                                </div></div>

                            <div class="relTableCell " style="margin-left: -4px; border-width: 0px; float:left;width:201px; height:32px; padding-top:6px; padding-right:0px"><img  style='width:7px; height:7px ; margin-left: -4px; margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div class="gauge2-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="margin-left: -4px;border-width: 0px; float:left;width:201px; height:31px; padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: -4px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_survivable") ?>'><div class="gauge3-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="margin-left: -4px;border-width: 0px; float:left;width:201px; height:32px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: -4px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_fair") ?>'><div class="gauge4-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="margin-left: -4px;border-width: 0px; float:left;width:201px; height:33px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: -4px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_sustainability") ?>'><div class="gauge1-text" style=" font-size: 11px;display: inline;" ></div></div>

                        </div></div></div>
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class="relTableCell" style="border-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/human.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_human") ?></span></div>
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/economy.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_economy") ?></span></div>                       
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/environment.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_environment") ?></span></div>
                        </div></div></div>
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <?php if (!$was == 'btn_percent') { ?>
                            <div class="relTableCell" style="border-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">A (<?php echo round($menschPercent, 1) ?>%)</span></div>
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">B (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>                       
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">C (<?php echo round($umweltPercent, 1) ?>%)</span></div>
                        <?php }
                        else {?>
                         <div class="relTableCell" style="border-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">A (<?php echo round($menschPercent, 1) ?>%)</span></div>
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">B (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>                       
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">C (<?php echo round($umweltPercent, 1) ?>%)</span></div>
                        <?php }?>    
                        </div></div></div>

                <!--reuleaux-diagramm-->


                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <?php if ($was == 'btn_percent') { ?>
<!--                                    <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>
                                    <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($wirtschaftPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>                       
                                    <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($umweltPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>-->
                            <?php } ?>


                        </div></div></div>
                <div class="relTable" style=" " >
                    <div class="relTableBody">
                        <div class="relTableRow">  
                            <?php if ($was == 'btn_points') {
                                    ?>
                                    <div class="relTableCell" style=" border-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                                    <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($wirtschaftpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>                       
                                    <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($umweltpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                            <?php } ?>
                        </div></div></div> 
      <div class="relTable"  >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class="relTableCell" style="border-width: 0px;" ><span style="font-size:12px;" class="txt_bonitaet"></span></div>
                        </div></div></div>   
                <div class="relTable"  >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class="text" style="height:auto; text-align:justify; color:black; border: 0px solid #999999;
		padding: 3px 6px;
            font-family: sans-serif;
    line-height: normal;
            padding-right: 0px;
            border-bottom-width: 0px; 
            padding-right:10px
   ">
                                <?php if ($audit_text != '') { ?>

                                <span style="font-size:12px;"><?php echo $audit_text ?></span>
                                <?php } else {
                                        ?>
                                        <span style="font-size:12px; 	" class="txt_rated_excerpt" ></span>
                                      <?php } ?>

                            </div>
                        </div></div></div> 
<!--                atachment
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <?php
                        if ($originalfilename != '') {
                                ?>
                                <div class="relTableRow">
                                    <div class="relTableCell" style="border-width: 0px;font-size: 11px;"><span style="font-size: 11px;"><?php echo elgg_echo('rel_Anlage') ?><a href='<?php echo elgg_get_inline_url(get_entity($file_guid)) ?>'><?php echo (strlen($originalfilename) > 25 ? substr($originalfilename, 0, 25) . '. . . ' : substr($originalfilename, 0, 25)) ?></span></div>
                                </div>
                        <?php } ?>
                    </div></div>   -->


           </div>  </div> 

    <!--Anfang Clip-->

    <div class="col-md-12 center"></div>
    <div class="row center"><img center style="height:60px; width:auto; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/public_domain.png"  ></div>
<div class="col-md-12 center"></div>
    
      <div class="relframe" style="border:1px solid; 
         border-radius:10px;
         padding:15px;
         border-color: darkgray;">
                <div class="relTable  "  >
                    <div class="relTableBody">

                        <div class="relTableRow">
                            <?php
                            if ($audit_candidate != '') {
                                    ?>

                                    <div class="relTableCell" style="font-weight: bold;  border-width: 0px;"><?php echo $audit_candidate ?></div>
                            <?php } ?>
                        </div></div></div>  
<div class="relframe" style="background:white;padding:0px;margin: 0px;border-width: 0px;margin-top: 0px">
                <div class="relTable" style="margin-top:0px" >
                    <div class="relTableBody">

                        <div class="relTableRow">
                            <div class="relTableCell" style="border-width: 0px; border-bottom-width: 0px;" ><?php echo elgg_echo('rel_sustainability_sub') ?>:</div>
                            <div class="relTableCell" style="border-width: 0px; border-bottom-width: 0px;" ><span class="total_percentage" style="color: black;font-weight: normal">0.0%</span></div>
                            <div class="relTableCell" style="border-width: 0px; border-bottom-width: 0px;" ><?php echo elgg_echo('rel_rating'); ?>:</div>
                            <div class="relTableCell" style=" border-width: 0px;" ><span class="txt_code" style="margin-left:-1px;"></span></div>

                        </div></div></div> 

           

                <!--rating-->

                <!--reuleaux-diagramm-->
                <div class="relTable"  >

                    <div class="relTableBody">
                        <div class="relTableRow" >

                            <div class="relTableCell" style="width:136px; height: 128px; border-width: 0px; "><div  style="width:118px;  margin-left:4px; padding: 0;z-index: 7  " id="derp5">
                                    <div style=" margin-top:0px; margin-left:1px;">

                                        <div class="a_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -90px;margin-left: 47px;width: 19px;text-align: center; z-index: 700000;">A</div>

                                        <div class="b_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top:30px;margin-left: 77px;width: 19px;text-align: left;">C</div>

                                        <div class="c_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -11px;margin-left: 30px;width: 19px;text-align: left;">B</div> 
                                    </div>
                                </div></div>

                            <div class="relTableCell " style="margin-left: -4px; border-width: 0px; float:left;width:201px; height:32px; padding-top:6px; padding-right:0px"><img  style='width:7px; height:7px ; margin-left: -4px; margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div class="gauge2-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="margin-left: -4px;border-width: 0px; float:left;width:201px; height:31px; padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: -4px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_survivable") ?>'><div class="gauge3-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="margin-left: -4px;border-width: 0px; float:left;width:201px; height:32px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: -4px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_fair") ?>'><div class="gauge4-text" style="font-size: 11px;display: inline;" ></div></div>
                            <div class="relTableCell " style="margin-left: -4px;border-width: 0px; float:left;width:201px; height:33px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: -4px;margin-right: 8px;   border:1px solid darkgray' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_sustainability") ?>'><div class="gauge1-text" style=" font-size: 11px;display: inline;" ></div></div>

                        </div></div></div>
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <div class="relTableCell" style="border-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/human.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_human") ?></span></div>
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/economy.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_economy") ?></span></div>                       
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/environment.jpg' title='<?php elgg_echo("rel_human") ?>'><?php echo elgg_echo("rel_environment") ?></span></div>
                        </div></div></div>
                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <?php if (!$was == 'btn_percent') { ?>
                            <div class="relTableCell" style="border-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">A (<?php echo round($menschPercent, 1) ?>%)</span></div>
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">B (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>                       
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">C (<?php echo round($umweltPercent, 1) ?>%)</span></div>
                        <?php }
                        else {?>
                         <div class="relTableCell" style="border-width: 0px;width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">A (<?php echo round($menschPercent, 1) ?>%)</span></div>
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">B (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>                       
                            <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 2px"><span  style="font-size: 11px;display: inline;">C (<?php echo round($umweltPercent, 1) ?>%)</span></div>
                        <?php }?>    
                        </div></div></div>

                <!--reuleaux-diagramm-->


                <div class="relTable" style="" >
                    <div class="relTableBody">
                        <div class="relTableRow">
                            <?php if ($was == 'btn_percent') { ?>
<!--                                    <div class="relTableCell" style="border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>
                                    <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($wirtschaftPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>                       
                                    <div class="relTableCell" style="border-left-width: 0px; border-bottom-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($umweltPercent, 1) ?> <?php echo elgg_echo('rel_btn_percent') ?></span></div>-->
                            <?php } ?>


                        </div></div></div>
                <div class="relTable" style=" " >
                    <div class="relTableBody">
                        <div class="relTableRow">  
                            <?php if ($was == 'btn_points') {
                                    ?>
                                    <div class="relTableCell" style=" border-width: 0px;width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                                    <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($wirtschaftpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>                       
                                    <div class="relTableCell" style="border-width: 0px; width:30%; padding-left:6px; padding-right: 0px"><span  style="font-size: 11px;display: inline;"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($umweltpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                            <?php } ?>
                        </div></div></div> 
      

           </div>  </div> 
    
    
    
    <!--Ende Clip-->
    
    
    
     <div class="col-md-12 center"></div>
    <div class="row center"><img center style="height:60px; width:auto; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/public_domain.png"  ></div>
<div class="col-md-12 center"></div>

    <div class="row center"><img center style="width:310px; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/three-pillars-model-of-sustainability_<?php echo get_language() ?>.jpg"  alt="three-pillars-model-of-sustainability" class="info"  ></div> 
     <div class="col-md-12 center"></div>
    <div class="row center"><img center style="height:60px; width:auto; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/public_domain.png"  ></div>
<div class="col-md-12 center"></div>   
    
       <div class="row center"><img center style="width:310px; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/sustainability-priority-model_<?php echo get_language() ?>.jpg"  alt="sustainability-priority-model" class="info"  ></div> 
    <div class="col-md-12 center"></div>
    <div class="row center"><img center style="height:60px; width:auto; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/public_domain.png"  ></div>
<div class="col-md-12 center"></div>

    <div class="row center"><img center style="width:310px; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagram_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagram" class="info"  ></div> 
     <div class="col-md-12 center"></div>
    <div class="row center"><img center style="height:60px; width:auto; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/public_domain.png"  ></div>
<div class="col-md-12 center"></div>   
    
       <div class="row center"><img center style="width:310px; padding:15px" src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux/reuleaux-diagram-of-sustainability_<?php echo get_language() ?>.jpg"  alt="reuleaux-diagram-of-sustainability" class="info"  ></div> 
    <!--over all img's wrap-->
</div>
<div class="con-des" style=' width:330px;' >
    <div class="row" >
        <div class=" col-md-12" >
            <button type="button" id="go-back" class="btn btn-block button-step-3" style="    top: -10px; display:none"><?php echo elgg_echo('rel_btn_back') ?></button>
        </div>

    </div>       </div>   


<!-- end of snapshot img bis elgg-body -->

<!--output from snapshot-->
<div id="img-out" style='display:none; background-color: white; width:330px; padding:5px'  >
</div> 
<!--output from snapshot-->

<!--extend form-->
<?php
if ($called < 3) {
elgg_view('input/securitytoken');
$url = elgg_add_action_tokens_to_url($site_url . "action/extend");
?>

<form class="form-vertical " action="<?php echo $url ?>" enctype="multipart/form-data" style="display:none;" method="post">
    <input type="hidden" name="tokenID" id="tokenID" value="<?php echo $tokenID ?>">
    <fieldset>
        <div class="con-des" style='width:310px' >
            <div class="row" >
                <div class=" col-md-12" >
                    <?php echo elgg_echo('') ?>
                    <legend style='padding-left: 10px; padding-right:10px'><?php echo elgg_echo('rel_extend_head') ?></legend>

                    <div class="form-group">
                        <label class="col-md-12 control-label" for="textinput"><?php echo elgg_echo('rel_extend_candidate') ?></label>  
                        <div class="col-md-12">
                            <input id="textinput" name="textinput" type="text" placeholder="<?php echo elgg_echo('rel_extend_nestle') ?>" class="form-control input-md">
                            <div class="col-md-12 error"></div>
                            <span class="help-block" style='font-size:10px'><?php echo elgg_echo('rel_extend_hint1') ?></span>  
                        </div>
                    </div>


                    <!--Textarea--> 
                    <div class="form-group" ID =textarea_de style="display:none">
                        <label class="col-md-12 control-label" for="textarea"><?php echo elgg_echo('rel_extend_note') ?></label>
                        <div class="col-md-12">                     
                            <textarea class="form-control input-md" type="text" name="inputtextarea_de" id="inputtextarea_de" placeholder="<?php echo elgg_echo('rel_extend_hint2') ?>"></textarea>
                            <div class="col-md-12 error"></div>
                            <span class="help-block" style='font-size:10px'><?php echo elgg_echo('rel_extend_hint3') ?></span>
                        </div>
                    </div>
                   <div class="form-group" ID =textarea_es style="display:none">
                        <label class="col-md-12 control-label" for="textarea"><?php echo elgg_echo('rel_extend_note') ?></label>
                        <div class="col-md-12">                     
                            <textarea class="form-control input-md" type="text" name="inputtextarea_es" id="inputtextarea_es" placeholder="<?php echo elgg_echo('rel_extend_hint2') ?>"></textarea>
                            <div class="col-md-12 error"></div>
                            <span class="help-block" style='font-size:10px'><?php echo elgg_echo('rel_extend_hint3') ?></span>
                        </div>
                    </div>
                   <div class="form-group" ID =textarea_en style="display:none">
                        <label class="col-md-12 control-label" for="textarea"><?php echo elgg_echo('rel_extend_note') ?></label>
                        <div class="col-md-12">                     
                            <textarea class="form-control input-md" type="text" name="inputtextarea_en" id="inputtextarea_en" placeholder="<?php echo elgg_echo('rel_extend_hint2') ?>"></textarea>
                            <div class="col-md-12 error"></div>
                            <span class="help-block" style='font-size:10px'><?php echo elgg_echo('rel_extend_hint3') ?></span>
                        </div>
                    </div>    
                                       <div class="form-group" ID =textarea_nl style="display:none">
                        <label class="col-md-12 control-label" for="textarea"><?php echo elgg_echo('rel_extend_note') ?></label>
                        <div class="col-md-12">                     
                            <textarea class="form-control input-md" type="text" name="inputtextarea_nl" id="inputtextarea_nl" placeholder="<?php echo elgg_echo('rel_extend_hint2') ?>"></textarea>
                            <div class="col-md-12 error"></div>
                            <span class="help-block" style='font-size:10px'><?php echo elgg_echo('rel_extend_hint3') ?></span>
                        </div>
                    </div>
                    
<!--                                                           <div class="form-group" ID =textarea_tr style="display:none">
                        <label class="col-md-12 control-label" for="textarea"><?php echo elgg_echo('rel_extend_note') ?></label>
                        <div class="col-md-12">                     
                            <textarea class="form-control input-md" type="text" name="inputtextarea_es" id="inputtextarea_tr" placeholder="<?php echo elgg_echo('rel_extend_hint2') ?>"></textarea>
                            <div class="col-md-12 error"></div>
                            <span class="help-block" style='font-size:10px'><?php echo elgg_echo('rel_extend_hint3') ?></span>
                        </div>
                    </div>-->
                    
                    
                    
                    
                                       <div class="form-group" ID =textarea_fr style="display:none">
                        <label class="col-md-12 control-label" for="textarea"><?php echo elgg_echo('rel_extend_note') ?></label>
                        <div class="col-md-12">                     
                            <textarea class="form-control input-md" type="text" name="inputtextarea_fr" id="inputtextarea_fr" placeholder="<?php echo elgg_echo('rel_extend_hint2') ?>"></textarea>
                            <div class="col-md-12 error"></div>
                            <span class="help-block" style='font-size:10px'><?php echo elgg_echo('rel_extend_hint3') ?></span>
                        </div>
                    </div>
                                       <div class="form-group" ID =textarea_it style="display:none">
                        <label class="col-md-12 control-label" for="textarea"><?php echo elgg_echo('rel_extend_note') ?></label>
                        <div class="col-md-12">                     
                            <textarea class="form-control input-md" type="text" name="inputtextarea_it" id="inputtextarea_it" placeholder="<?php echo elgg_echo('rel_extend_hint2') ?>"></textarea>
                            <div class="col-md-12 error"></div>
                            <span class="help-block" style='font-size:10px'><?php echo elgg_echo('rel_extend_hint3') ?></span>
                        </div>
                    </div>
                              <div class="col-md-12 language_selector footer-drop-center" style="margin-top: -5px; margin-bottom:20px ">
                                  <?php      if (!$no_flags){ ?>
                <a >
                    <img id = "flag_en" style="margin-right: 20px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/en.gif' alt='Englisch' title='Englisch' >
                    <img id = "check_en" style="display: none; height:20px; width:auto; margin-left:-20px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/check_green.png"  >
                </a>
                <a>
                    <img id = "flag_de" style="margin-right: 20px;"  src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/de.gif' alt='Deutsch' title='Deutsch' >
                    <img id = "check_de" style="display: none; height:20px; width:auto; margin-left:-20px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/check_green.png"  >
                </a>
                <a>
                    <img id = "flag_fr" style="margin-right: 20px;"  src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/fr.gif' alt='Spanisch' title='Spanisch'>
                    <img id = "check_fr" style="display: none; height:20px; width:auto; margin-left:-20px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/check_green.png"  >
                </a>   
                <a>
                    <img id = "flag_es" style="margin-right: 20px;"   src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/es.gif' alt='Spanisch' title='Spanisch'>
                    <img id = "check_es" style="display: none; height:20px; width:auto; margin-left:-20px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/check_green.png"  >
                </a>                    
                <a>
                    <img id = "flag_it" style="margin-right: 20px;"  src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/it.gif' alt='Spanisch' title='Spanisch'>
                    <img id = "check_it" style="display: none; height:20px; width:auto; margin-left:-20px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/check_green.png"  >
                </a>   
                <a>
                    <img id = "flag_nl" style="margin-right: 20px;"  src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/nl.gif' alt='Spanisch' title='Spanisch'>
                    <img id = "check_nl" style="display: none; height:20px; width:auto; margin-left:-20px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/check_green.png"  >
                </a> 
                                  <?php } ?>
<!--                                                  <a>
                    <img id = "flag_tr" style="margin-right: 20px;"  src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/tr.gif' alt='Spanisch' title='Spanisch'>
                    <img id = "check_tr" style="display: none; height:20px; width:auto; margin-left:-20px" src="<?php echo $site_url ?>mod/reuleaux/images/icons/check_green.png"  >
                </a>  -->
            </div>
                    


                    <div class="form-group" style='margin-top:10px' >
                        <label class="col-md-12 control-label"  for="upload">   <?php echo elgg_echo('rel_extend_attacment') ?></label>
                        <div class="col-md-12">
                            <?php
                            echo elgg_view('input/file', [
                                'name' => 'upload',
                                'label' => elgg_echo('rel_extend_select'),
                                'help' => elgg_echo('rel_extend_pdf'),
                            ]);
                            ?>
                            <span class="help-block text-left" style='font-size:10px'><?php echo elgg_echo('rel_extend_protect') ?></span>  
                        </div>


                    </div>      

                    
<!--                                        <div class="form-group" style='margin-top:10px' >
                        <label class="col-md-12 control-label"  for="upload2">   <?php echo elgg_echo('rel_extend_image') ?></label>
                        <div class="col-md-12">
                            <?php
                            echo elgg_view('input/file', [
                                'name' => 'upload2',
                                'label' => elgg_echo('rel_extend_select_image'),
                                'help' => elgg_echo('rel_extend_image_only'),
                            ]);
                            ?>
                            <span class="help-block text-left" style='font-size:10px'><?php echo elgg_echo('rel_extend_protect_image') ?></span>  
                        </div>


                    </div> 
                                    <div class="form-group">
                        <label class="col-md-12 control-label" for="textinput2"><?php echo elgg_echo('rel_extend_link') ?></label>  
                        <div class="col-md-12">
                            <input id="textinput" name="textinput2" type="text" placeholder="<?php echo elgg_echo('rel_extend_link_placeholder') ?>" class="form-control input-md">
                            <div class="col-md-12 error"></div>
                            <span class="help-block" style='font-size:10px'><?php echo elgg_echo('rel_extend_hint_link') ?></span>  
                        </div>
                    </div>    -->
                    
                    <div class="form-group">
                        <label class="col-md-12 control-label" for="singlebutton"></label>
                        <div class="col-md-12 center">

                            <button type="submit" id="singlebutton" name="goforit" value= '<?php echo $tokenID ?>' class="btn btn-primary"><?php echo elgg_echo('rel_extend_extend') ?></button>
                        </div>

                    </div>




                
                    </div>
                    </div>
                    </div>   
        
</form>
<?php
}
                   
?> 