<?php
$js_url = 'mod/reuleaux/vendors/analytics.js';
elgg_register_js('analytics', $js_url, 'head', 500);
$OK = elgg_load_js('analytics');

$css_url = 'mod/reuleaux/vendors/bootstrap.min.css';
elgg_register_css('bootstrap', $css_url, 500);
elgg_load_css('bootstrap');

$css_url = 'mod/reuleaux/vendors/style_blank_page.css';
elgg_register_css('style_blank_page', $css_url, 500);
elgg_load_css('style_blank_page');

$css_url = 'mod/reuleaux/vendors/bootstrap.min.css';
elgg_register_css('bootstrap', $css_url, 500);
elgg_load_css('bootstrap');


$js_url = 'mod/reuleaux/vendors/raphael-min.js';
elgg_register_js('raphael', $js_url, 'head', 500);
elgg_load_js('raphael');

$js_url = 'mod/reuleaux/vendors/bootstrap.min.js';
elgg_register_js('bootstrap', $js_url, 'head', 500);
elgg_load_js('bootstrap');

$site_url = elgg_get_site_url();
$select_language = $vars['select_language'];
$tokenID = $vars['tokenID'];
$mensch_percent = $vars['mensch'];
$umwelt_percent = $vars['umwelt'];
$wirtschaft_percent = $vars['wirtschaft'];
$menschpunkte = $vars['menschpunkte'];
$umweltpunkte = $vars['umweltpunkte'];
$wirtschaftpunkte = $vars['wirtschaftpunkte'];
$menschmaxpunkte = $vars['menschmaxpunkte'];
$umweltmaxpunkte = $vars['umweltmaxpunkte'];
$wirtschaftmaxpunkte = $vars['wirtschaftmaxpunkte'];
$menschPercent = $vars['mensch'];
$umweltPercent = $vars['umwelt'];
$wirtschaftPercent = $vars['wirtschaft'];
$r_standard = (int)$vars['r_standard'];
$r_human = (int)$vars['r_human'];
$r_environment = (int)$vars['r_environment'];
$r_economic = (int)$vars['r_economic'];
$a_max = $vars['a_max'];
$is_survivable_p_t = $vars['is_survivable_p_t'];
$is_fair_p_t = $vars['is_fair_p_t'];
$is_acceptable_p_t = $vars['is_acceptable_p_t'];
$s_max = $vars['s_max'];
$is_sustainable = $vars['is_sustainable'];
$is_sustainable_p_t = $vars['is_sustainable_p_t'];
$rating_ext = $vars['rating_ext'];
$was = $vars['was'];
$ampel_background = $vars['ampel_background'];
$ampel_fontcolor = $vars['ampel_fontcolor'];
$ampel_img_panel = $vars['ampel_img_panel'];
$audit_candidate = $vars['audit_candidate'];
                        $audit_text = $vars['audit_text'];

$tokenID = $vars['tokenID'];
$file_guid = $vars['file_guid'];
$image_guid = $vars['image_guid'];
$originalfilename = $vars['originalfilename'];
?>
<link href="https://fonts.googleapis.com/css?family=Londrina+Outline|Londrina+Shadow|Londrina+Sketch|Londrina+Solid|Open+Sans" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>

<script>
        $(".total_percentage").text(<?php echo $is_sustainable_p_t ?> + '%');
function makeResizable(element){
	if (element && $(element).length){
		var $el = $(element);
		var elHeight = $el.outerHeight();
		var elWidth = $el.outerWidth();

		var $wrapper = $el.parent();

		var starterData = {
			size: {
				width: $wrapper.width(),
				height: $wrapper.height()
			}
		}
		var scale = Math.min(
			starterData.size.width / $el.outerWidth(),
			starterData.size.height / $el.outerHeight()
		);
		if (scale > 1){
			scale = 1;
		}
		var elMarginBottom = (scale * elHeight) - starterData.size.height;
		$el.css({
			transform: "translate3d(-50%, 0, 0) " + "scale(" + scale + ")",
			'margin-bottom': elMarginBottom
		});
	}
}
function ratingcode_content(code) {
                switch (code) {
                    case '22':
                        txtrated = "<?php echo elgg_echo('rel_rated_22'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_22'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_22'); ?>";

                        break;
                    case '21':
                        txtrated = "<?php echo elgg_echo('rel_rated_21'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_21'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_21'); ?>";

                        break;
                    case '20':
                        txtrated = "<?php echo elgg_echo('rel_rated_20'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_20'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_20'); ?>";

                        break;
                    case '19':
                        txtrated = "<?php echo elgg_echo('rel_rated_19'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_19'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_19'); ?>";

                        break;
                    case '18':
                        txtrated = "<?php echo elgg_echo('rel_rated_18'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_18'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_18'); ?>";

                        break;
                    case '17':
                          
                        txtrated = "<?php echo elgg_echo('rel_rated_17'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_17'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_17'); ?>";

                        break;
                    case '16':
                        txtrated = "<?php echo elgg_echo('rel_rated_16'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_16'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_16'); ?>";

                        break;
                    case '15':
                        txtrated = "<?php echo elgg_echo('rel_rated_15'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_15'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_15'); ?>";

                        break;
                    case '14':
                        txtrated = "<?php echo elgg_echo('rel_rated_14'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_14'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_14'); ?>";

                        break;
                    case '13':
                        txtrated = "<?php echo elgg_echo('rel_rated_13'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_13'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_13'); ?>";

                        break;
                    case '12':
                        txtrated = "<?php echo elgg_echo('rel_rated_12'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_12'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_12'); ?>";
 
                        break;
                    case '11':
                        txtrated = "<?php echo elgg_echo('rel_rated_11'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_11'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_11'); ?>";

                        break;
                    case '10':
                        txtrated = "<?php echo elgg_echo('rel_rated_10'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_10'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_10'); ?>";

                        break;
                    case '9':
                        txtrated = "<?php echo elgg_echo('rel_rated_9'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_9'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_9'); ?>";

                        break;
                    case '8':
                        txtrated = "<?php echo elgg_echo('rel_rated_8'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_8'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_8'); ?>";

                        break;
                    case '7':
                        txtrated = "<?php echo elgg_echo('rel_rated_7'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_7'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_7'); ?>";

                        break;
                    case '6':
                        txtrated = "<?php echo elgg_echo('rel_rated_6'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_6'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_6'); ?>";

                        break;
                    case '5':
                        txtrated = "<?php echo elgg_echo('rel_rated_5'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_5'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_5'); ?>";
 
                        break;
                    case '4':
                        txtrated = "<?php echo elgg_echo('rel_rated_4'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_4'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_4'); ?>";

                        break;
                    case '3':
                        txtrated = "<?php echo elgg_echo('rel_rated_3'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_3'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_3'); ?>";

                        break;
                    case '2':
                        txtrated = "<?php echo elgg_echo('rel_rated_2'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_2'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_2'); ?>";
          
                        break;
                    case '1':
                        txtrated = "<?php echo elgg_echo('rel_rated_1'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_1'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_1'); ?>";
                
                        break;
                    case '0':
                        txtrated = "<?php echo elgg_echo('rel_rated_1'); ?>";
                        txtbonität = "<?php echo elgg_echo('rel_bonitaet_1'); ?>";
                        txtcode = "<?php echo elgg_echo('rel_code_1'); ?>";
                  
                        break;
                }}
$(window).load(function() {
//	makeResizable('#very-specific-design');
});
$(window).resize(function() {
	makeResizable('#very-specific-design');
});
$(document).ready(function() {
        onetime = false;
        requestedlanguage = "<?php echo $select_language ?>";

        if (requestedlanguage.length) {
                if (!onetime) {
        setLanguage(requestedlanguage) ;  
        onetime = true;
                }
        }

	makeResizable('#very-specific-design');
            var rating_ext = <?php echo $rating_ext ?>;
            rating_ext = rating_ext.toFixed(0);
            rating_ext = rating_ext.toString();
  
            ratingcode_content(rating_ext);
        
        // standard text
               //     $('#rating_text').text(txtrated);
        // user text
$('#rating_text').text("<?php echo $audit_text ?>");
        
selecedlanguage = "<?php echo get_language() ?>";
$("#textarea_" + selecedlanguage).show();

            $(".error").hide();
            $("#singlebutton").attr("disabled", true);
            $(".form-control").on("keyup", function () {
                $(".error").hide();

                if ($.isNumeric($(this).val())) {
                    $(this).parent().find(".error").html("<?php echo elgg_echo('rel_msg_error_entry'); ?>").show();
                    $(this).val('');
                    return;
                }

                var check = $(".form-control").filter(function () {
                    return $.trim($(this).val()) === '';

                });

                if (!check.length) {

                    $("#singlebutton").attr("disabled", false);
//                    if (step2 === true) {
////                        $("#check-input").text("<?php echo elgg_echo('rel_btn_calculate_step1'); ?>");
//                    }
                } else {
                    $("#singlebutton").attr("disabled", true);
//                    if (step2 === true) {
////                        $("#check-input").text("<?php echo elgg_echo('rel_btn_calculate_step2'); ?>");
//                    }
                }

            });
            is_paper_canvas = false;
            sustainable_correct = 0;
            mensch_percent = <?php echo $mensch_percent ?>;
            umwelt_percent = <?php echo $umwelt_percent ?>;
            economy_percent = <?php echo $wirtschaft_percent ?>;
            r_standard = <?php echo $r_standard ?>;
            r_human = <?php echo $r_human ?>;
            r_environment = <?php echo $r_environment ?>;
            r_economic = <?php echo $r_economic ?>;
//                                                                                      // alert(p_standard);
//                                                                                      // alert(f_standard);
            // e. g. 50% Fläche = 21125.919999999995 entsprechen 82.02438661763951 Radius
            $(".txt_human").text($(".txt_human").text() + ' (' + mensch_percent + '%)');

            $(".txt_environment").text($(".txt_environment").text() + ' (' + umwelt_percent + '%)');

            $(".txt_economy").text($(".txt_economy").text() + ' (' + economy_percent + '%)');

            if (is_paper_canvas === false) {

                paper = Raphael("derp", r_standard + 5, r_standard + 5); // for testing delete  5
//                paper2 = Raphael("derp2", r_standard + 5, r_standard + 5); // for testing delete  5
//                paper3 = Raphael("derp3", r_standard + 5, r_standard + 5); // for testing delete  5
//                paper4 = Raphael("derp4", r_standard + 5, r_standard + 5); // for testing delete  5
                is_paper_canvas = true;
            }
            //      paper.clear();
            // Zeichne Kreis mit X-Radius an Postion Gleichseitiges Dreieck 
            var circle = paper.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
            var circle2 = paper.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
            var circle3 = paper.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2
//            var circlex = paper2.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
//            var circlex2 = paper2.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
//            var circlex3 = paper2.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2
//            var circle3x = paper3.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
//            var circle3x2 = paper3.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
//            var circle3x3 = paper3.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2
//            var circle4x1 = paper4.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
//            var circle4x2 = paper4.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
//            var circle4x3 = paper4.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2

            r_116 = 116;                                                                        // 
            // Schnittflächen 100%
            a_max = <?php echo $a_max ?>;


            is_survivable_p_t = <?php echo $is_survivable_p_t ?>;
            $(".gauge3-text").text($(".gauge3-text").text() + ' (' + is_survivable_p_t + '%)');


            is_fair_p_t = <?php echo $is_fair_p_t ?>;
            $(".gauge4-text").text($(".gauge4-text").text() + ' (' + is_fair_p_t + '%)');

            is_acceptable_p_t = <?php echo $is_acceptable_p_t ?>;
            $(".gauge2-text").text($(".gauge2-text").text() + ' (' + is_acceptable_p_t + '%)');

            s_max = <?php echo $s_max ?>;
            is_sustainable = <?php echo $is_sustainable ?>;

            $(".total_percentage").text(<?php echo $is_sustainable_p_t ?> + '%');
            $(".gauge1-text").text($(".gauge1-text").text() + ' (' + <?php echo $is_sustainable_p_t ?> + '%)');

            var rating_ext = <?php echo $rating_ext ?>;
//            // alert(rating_ext);
            rating_ext = rating_ext.toFixed(0);
//            // alert(rating_ext);
            rating_ext = rating_ext.toString();
       //     ratingcode_content2(rating_ext);
            $(".ratingcode_img").attr('src', "<?php echo $site_url ?>" + 'mod/reuleaux/images/codes/' + rating_ext + '.jpg')
            //           $(".ratingcode_img_arrow").attr('src', "<?php echo $site_url ?>' + 'mod/reuleaux/images/codes/' + rating_ext + '.jpg')
            circle.attr("fill", "#FF3A3A");
            circle.attr("stroke", "whitesmoke");
            circle.animate({"fill-opacity": .8}, 600);

            circle3.attr("fill", "#FFCE8C");
            circle3.animate({"fill-opacity": .5}, 600);
            circle3.attr("stroke", "#ffffff");

            // Sets the fill attribute of the circle to red (#f00)
            circle2.attr("fill", "#68C2FF");
            circle2.animate({"fill-opacity": .6}, 600);
            //Sets the stroke attribute of the circle to white
            circle2.attr("stroke", "#ffffff");
            is_paper_canvas = true;

//            circle.attr("fill", "#FF3A3A");
//            circle.attr("stroke", "darkgray");
//            circle.animate({"fill-opacity": .8}, 600);
//                       // Sets the fill attribute of the circle to red (#f00)
//            circle2.attr("fill", "#68C2FF");
//            circle2.animate({"fill-opacity": .6}, 600);
//            //Sets the stroke attribute of the circle to white
//            circle2.attr("stroke", "darkgray");
//
//            circle3.attr("fill", "#FFCE8C");
//            circle3.animate({"fill-opacity": .5}, 600);
//            circle3.attr("stroke", "darkgray");
//
// 
//
//
//            circlex.attr("fill", "#FF3A3A");
//            circlex.attr("stroke", "#999999");
//            circlex.animate({"fill-opacity": .8}, 600);
//
//            circlex3.attr("fill", "#FFCE8C");
//            circlex3.animate({"fill-opacity": .5}, 600);
//            circlex3.attr("stroke", "#999999");
//
//            // Sets the fill attribute of the circle to red (#f00)
//            circlex2.attr("fill", "#68C2FF");
//            circlex2.animate({"fill-opacity": .6}, 600);
//            //Sets the stroke attribute of the circle to white
//            circlex2.attr("stroke", "#999999");
//
//            circle3x.attr("fill", "#FF3A3A");
//            circle3x.attr("stroke", "#999999");
//            circle3x.animate({"fill-opacity": .8}, 600);
//
//            circle3x3.attr("fill", "#FFCE8C");
//            circle3x3.animate({"fill-opacity": .5}, 600);
//            circle3x3.attr("stroke", "#999999");
//
//            // Sets the fill attribute of the circle to red (#f00)
//            circle3x2.attr("fill", "#68C2FF");
//            circle3x2.animate({"fill-opacity": .6}, 600);
//            //Sets the stroke attribute of the circle to white
//            circle3x2.attr("stroke", "#999999");
//
//
//            circle4x1.attr("fill", "#FF3A3A");
//            circle4x1.attr("stroke", "#999999");
//            circle4x1.animate({"fill-opacity": .8}, 600);
//
//            circle4x3.attr("fill", "#FFCE8C");
//            circle4x3.animate({"fill-opacity": .5}, 600);
//            circle4x3.attr("stroke", "#999999");
//
//            // Sets the fill attribute of the circle to red (#f00)
//            circle4x2.attr("fill", "#68C2FF");
//            circle4x2.animate({"fill-opacity": .6}, 600);
//            //Sets the stroke attribute of the circle to white
//            circle4x2.attr("stroke", "#999999");
            function ratingcode_content2(code) {
                switch (code) {
                    case '22':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_22'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_22'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_22'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_22'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '21':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_21'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_21'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_21'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_21'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '20':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_20'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_20'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_20'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_20'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '19':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_19'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_19'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_19'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_19'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '18':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_18'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_18'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_18'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_18'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '17':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_17'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_17'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_17'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_17'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '16':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_16'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_16'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_16'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_16'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '15':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_15'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_15'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_15'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_15'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '14':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_14'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_14'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_14'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_14'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '13':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_13'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_13'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_13'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_13'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '12':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_12'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_12'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_12'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_12'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '11':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_11'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_11'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_11'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_11'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '10':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_10'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_10'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_10'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_10'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '9':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_9'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_9'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_9'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_9'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '8':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_8'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_8'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_8'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_8'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '7':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_7'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_7'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_7'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_7'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '6':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_6'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_6'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_6'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_6'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '5':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_5'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_5'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_5'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_5'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '4':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_4'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_4'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_4'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_4'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '3':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_3'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_3'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_3'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_3'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '2':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_2'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_2'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_2'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_2'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '1':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_1'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_1'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_1'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_1'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                    case '0':
                        $(".txt_rated").text("<?php echo elgg_echo('rel_rated_1'); ?>");
                        $(".txt_bonitaet").text("<?php echo elgg_echo('rel_bonitaet_1'); ?>");
                        $(".txt_code").text("<?php echo elgg_echo('rel_code_1'); ?>");
                        dummy = "<?php echo elgg_echo('rel_rated_1'); ?>";
                        $(".txt_rated_excerpt").text(dummy);
                        break;
                }
            }
            function showDialog() {
                var currentFolder = $("#fileexplorer").wijfileexplorer("option", "currentFolder");
                //debugger;
                var action = "./upload.ashx?folder=" + currentFolder;
                $("#upload").wijupload("option", "action", action);
                $('#dialog').wijdialog({title: "Upload to: " + currentFolder}).wijdialog("open");
            }
            $("#flag_de").dblclick(function () {
                   stextarea('de'); 
                  }
        ); 
                   $("#flag_es").dblclick(function () {
                   stextarea('es'); 
                  }
        );   
                   $("#flag_en").dblclick(function () {
                   stextarea('en'); 
                  }
        ); 
                    $("#flag_fr").dblclick(function () {
                   stextarea('fr'); 
                  }
        ); 
                   $("#flag_it").dblclick(function () {
                   stextarea('it'); 
                  }
        );   
                   $("#flag_nl").dblclick(function () {
                   stextarea('nl'); 
                  }
        ); 
            $("#flag_de").click(function () {
                   sstextarea('de'); 
                  }
        ); 
                   $("#flag_es").click(function () {
                   sstextarea('es'); 
                  }
        );   
                   $("#flag_en").click(function () {
                   sstextarea('en'); 
                  }
        ); 
                    $("#flag_fr").click(function () {
                   sstextarea('fr'); 
                  }
        ); 
                   $("#flag_it").click(function () {
                   sstextarea('it'); 
                  }
        );   
                   $("#flag_nl").click(function () {
                   sstextarea('nl'); 
                  }
        ); 
                    $(".form-control").on("keyup", function () {
//                $(".error").hide();


//                var check = $(".form-control").filter(function () {
//                    return $.trim($(this).val()) === '';
//
//                });   inputtextarea_de
                 var value = $('#inputtextarea_en').val();
    if ( value.length > 0 && value !== $('#inputtextarea_en').attr('placeholder')) { 
                        $("#check_en").show();
                }
                else {
                     $("#check_en").hide();  
        }
        
                           var value = $('#inputtextarea_de').val();
    if ( value.length > 0 && value !== $('#inputtextarea_de').attr('placeholder')) { 
                        $("#check_de").show();
                }
                else {
                     $("#check_de").hide();  
        }
         
                           var value = $('#inputtextarea_fr').val();
    if ( value.length > 0 && value !== $('#inputtextarea_fr').attr('placeholder')) { 
                        $("#check_fr").show();
                }
                else {
                     $("#check_fr").hide();  
        }
        
                           var value = $('#inputtextarea_es').val();
    if ( value.length > 0 && value !== $('#inputtextarea_es').attr('placeholder')) { 
                        $("#check_es").show();
                }
                else {
                     $("#check_es").hide();  
        }
                                   var value = $('#inputtextarea_it').val();
    if ( value.length > 0 && value !== $('#inputtextarea_it').attr('placeholder')) { 
                        $("#check_it").show();
                }
                else {
                     $("#check_it").hide();  
        }
          
                           var value = $('#inputtextarea_nl').val();
    if ( value.length > 0 && value !== $('#inputtextarea_nl').attr('placeholder')) { 
                        $("#check_nl").show();
                }
                else {
                     $("#check_nl").hide();  
        }
                    });
function sstextarea(lang) {
                //    if (!check.length) {
//                alert($("#textarea_de").is(':visible')) ;
//                alert($("#textarea_de").val()) ;
//                alert($("#inputtextarea_de").val().length) ;
        if ( $("#textarea_en").is(':visible') ){
        langselected = "en";
}
        if ( $("#textarea_de").is(':visible') ){
        langselected = "de";
}
        if ( $("#textarea_fr").is(':visible') ){
        langselected = "fr";
}
        if ( $("#textarea_es").is(':visible') ){
        langselected = "es";
}
        if ( $("#textarea_it").is(':visible') ){
        langselected = "it";
}
        if ( $("#textarea_nl").is(':visible') ){
        langselected = "nl";
}
//alert(langselected);
//alert($("#inputtextarea_" + langselected).val().length) ;
 $("#textarea_de").hide();
 $("#textarea_es").hide();
 $("#textarea_en").hide();
  $("#textarea_fr").hide();
 $("#textarea_it").hide();
 $("#textarea_nl").hide();
$("#textarea_" + lang).show(); 
}
            function setLanguage(lang_id) {
                setCookie("client_language", lang_id, 30);
                document.location.href = document.location.href;
            }
            // Cookie to remember language
            function setCookie(c_name, value, expiredays) {
                var exdate = new Date();
                exdate.setDate(exdate.getDate() + expiredays);
                document.cookie = c_name + "=" + escape(value) + ";Path=/" + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
            }
function stextarea(lang) {
                //    if (!check.length) {
//                alert($("#textarea_de").is(':visible')) ;
//                alert($("#textarea_de").val()) ;
//                alert($("#inputtextarea_de").val().length) ;
        if ( $("#textarea_en").is(':visible') ){
        langselected = "en";
}
        if ( $("#textarea_de").is(':visible') ){
        langselected = "de";
}
        if ( $("#textarea_fr").is(':visible') ){
        langselected = "fr";
}
        if ( $("#textarea_es").is(':visible') ){
        langselected = "es";
}
        if ( $("#textarea_it").is(':visible') ){
        langselected = "it";
}
        if ( $("#textarea_nl").is(':visible') ){
        langselected = "nl";
}
//alert(langselected);
//alert($("#inputtextarea_" + langselected).val().length) ;
 $("#textarea_de").hide();
 $("#textarea_es").hide();
 $("#textarea_en").hide();
  $("#textarea_fr").hide();
 $("#textarea_it").hide();
 $("#textarea_nl").hide();
$("#textarea_" + lang).show(); 
//alert(encodeURI($("#inputtextarea_" + langselected).val()));
if ( $("#inputtextarea_" + langselected).val().length > 1){
        var url = "https://translate.google.com/#" + langselected + "/en/"  + encodeURI($("#inputtextarea_" + langselected).val());
        var url2 = "https://translate.google.com/#" + langselected + "/de/"  + encodeURI($("#inputtextarea_" + langselected).val());
        var url3 = "https://translate.google.com/#" + langselected + "/fr/"  + encodeURI($("#inputtextarea_" + langselected).val());
        var url4 = "https://translate.google.com/#" + langselected + "/es/"  + encodeURI($("#inputtextarea_" + langselected).val());
        var url5 = "https://translate.google.com/#" + langselected + "/it/"  + encodeURI($("#inputtextarea_" + langselected).val());
        var url6 = "https://translate.google.com/#" + langselected + "/nl/"  + encodeURI($("#inputtextarea_" + langselected).val());
var win = window.open(url, '_blank');
var win = window.open(url2, '_blank');
var win = window.open(url3, '_blank');
var win = window.open(url4, '_blank');
var win = window.open(url5, '_blank');
var win = window.open(url6, '_blank');
if (win) {
    //Browser has allowed it to be opened
    win.focus();
} else {
    //Browser has blocked it
    alert('Please allow popups for this website');
}
}
}


            function setLanguage(lang_id) {
                setCookie("client_language", lang_id, 30);
                document.location.href = document.location.href;
            }
            // Cookie to remember language
            function setCookie(c_name, value, expiredays) {
                var exdate = new Date();
                exdate.setDate(exdate.getDate() + expiredays);
                document.cookie = c_name + "=" + escape(value) + ";Path=/" + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
            }
        });

        $(function () {
            $("#check-input").click(function () {
                $("#Calc").hide();
                $("#img-in").show();
                html2canvas($("#img-in"), {
                    onrendered: function (canvas) {
                        theCanvas = canvas;
                        //    document.body.appendChild(canvas);

                        // Convert and download as image 
//                windows.Canvas2Image.saveAsPNG(canvas); 
                        $('canvas').remove();
                        $("#img-out").append(canvas);
                        $("#img-in").hide();

                        $("#img-out").show();
                        $(".form-vertical").show();
                        $('body').css('background-image', 'url(./images/white.png)');

                        $("#go-back").show();
                        // Clean up 
                        //document.body.removeChild(canvas);
                    }
                });
            });


        });
        $(function () {
            $("#go-back").click(function () {



                $("#img-out").hide();
                $(".form-vertical").hide();
                $("#Calc").show();
                $('body').css('background-image', "url(" + "<?php echo $site_url ?>" + "mod/reuleaux/images/phone.png)");
                $("#go-back").hide();
            });


        });

</script>
<?php 
$site_url = elgg_get_site_url();
if (getimagesize(elgg_get_inline_url(get_entity($image_guid)))) {
$backgroundurl = elgg_get_inline_url(get_entity($image_guid));      
}
else {
        $backgroundurl = $site_url . 'mod/reuleaux/images/statement-transparent.png';  
        
}

?>

    <div class="very-specific-design" id="very-specific-design"     >
 <img src="<?php echo $backgroundurl ?>" style="opacity:0.5; width:90%; background-color: <?php echo $ampel_background ?>" alt="" />

<!--NACHHALTIGKEIT-->
      <div style="color:white; font-weight:bold; text-align:right; width:100%;position:absolute; top:50px; font-size: 45px;padding-left: 150px;padding-right: 100px">
<p class="LondrinaSolid"><?php echo elgg_echo('rel_sustainability_sub') ?></p>
</div>
<!--RATING-->
<div style="color:white; font-weight:bold; text-align:left; width:100%;position:absolute; top:61px; font-size: 30px;padding-left: 60px;padding-right: 100px">
<p class="LondrinaSolid"><?php echo elgg_echo('rel_rating') ?>:&nbsp;<img id="ratingcode_img" src="<?php echo $site_url ?>mod/reuleaux/images/codes/<?php echo $rating_ext?>.jpg" style="height: 30px;" ></p>
</div>
<!--PERCENT-->
      <div style="color:white;  font-weight:bold; text-align:right; width:100%;position:absolute; top:90px; font-size: 100px;padding-left: 150px;padding-right: 100px">
<p class="LondrinaSolid"><?php echo $is_sustainable_p_t ?>%</p>
</div>
<!--TEXT-->
      <div  style="text-align:center; width:100%;position:absolute; top:290px; font-weight: bold; color: black; font-size: 22px;padding-left: 60px;padding-right: 100px">
<p id="rating_text" class="OpenSans" style="font-weight: regular;"></p>
</div>
<!--RECT-->
      <div style="position:absolute; top:544px; margin-left: 60px; margin-right: 130px; background-color: whitesmoke; height: 50px; width: 538px;opacity:0.6;">
</div>
<!--TEXT-->
      <div style="font-size: 40px; position:absolute; top:541px; margin-left: 60px; margin-right: 130px; background-color: none; height: 50px; width: 538px">
<p id="audit_candidate" class="LondrinaSketch" style="color:<?php echo $ampel_background ?>;font-weight: bold;"><?php echo $audit_candidate?></p>
      </div>
<!--TEXT-->



                    <div class="relTableBody" style=" position:absolute; top:127px; width: 288px; margin-left: 63px; ">
                        <div class="relTableRow" >

                            <div class="relTableCell" style="width:138px; height: 110px; border-bottom-width: 1px;  border-color: whitesmoke;"><div  style="position:absolute; width:118px;  opacity: 0.6; margin-left:4px; top:7px; padding: 0;z-index: 7  " id="derp">
                                    
                                    <div style=" margin-top:4px; margin-left:1.3px;     z-index: 1;">

                                        <div id ="a_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -95px;margin-left: 47px;width: 19px;text-align: center; z-index: 700000;">A</div>

                                        <div id ="b_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top:30px;margin-left: 77px;width: 19px;text-align: left;">C</div>

                                        <div id ="c_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -11px;margin-left: 28px;width: 19px;text-align: left;">B</div> 
                                    </div>
                                </div></div>

                            <div class="relTableCell " style="text-align:left; border-color: whitesmoke;border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:33px; padding-top:6px; padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px; margin-right: 8px;   border:1px solid whitesmoke' src="<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg" title="<?php elgg_echo("rel_acceptable") ?>"><div class="gauge2-text" style="color:whitesmoke; font-size: 11px;display: inline;" ><?php echo elgg_echo("rel_acceptable") ?></div></div>
                            <div class="relTableCell " style="text-align:left;border-color: whitesmoke;border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:33px; padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid whitesmoke' src="<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg" title="<?php elgg_echo("rel_survivable") ?>"><div class="gauge3-text" style="color:whitesmoke; font-size: 11px;display: inline;" ><?php echo elgg_echo("rel_survivable") ?></div></div>
                            <div class="relTableCell " style="text-align:left;border-color: whitesmoke;border-left-width: 0px; border-bottom-width: 0px;float:left;width:100%; height:33px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid whitesmoke' src="<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg" title="<?php elgg_echo("rel_fair") ?>"><div class="gauge4-text" style="color:whitesmoke; font-size: 11px;display: inline;" ><?php echo elgg_echo("rel_fair") ?></div></div>
                            <div class="relTableCell " style="text-align:left;border-color: whitesmoke;border-left-width: 0px; border-bottom-width: 1px;float:left;width:100%; height:33px;  padding-top:6px;padding-right:0px"><img  style='width:7px; height:7px ; margin-left: 2px;margin-right: 8px;   border:1px solid whitesmoke' src="<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg" title="<?php elgg_echo("rel_sustainability") ?>"><div class="gauge1-text" style="color:whitesmoke;  font-size: 11px;display: inline;" ><?php echo elgg_echo("rel_sustainability") ?></div></div>

                        </div></div>


<!--NACHHALTIGKEIT-->
      <div style=" color: <?php echo $ampel_background ?>; font-weight:bold; text-align:right; width:100%;position:absolute;top:50px; font-size: 45px;margin-left: -100px;">
<p class="LondrinaSketch"><?php echo elgg_echo('rel_sustainability_sub') ?></p>
</div>
<!--RATING-->
<div style="color:<?php echo $ampel_background ?>; text-align:left; font-weight:bold; width:100%;position:absolute; top:61px; font-size: 30px;margin-left:60px">
<p class="LondrinaSketch"><?php echo elgg_echo('rel_rating') ?>:</p>
</div>
<!--PERCENT-->
      <div style="color: <?php echo $ampel_background ?>;   font-weight:bold; text-align:right; width:100%;position:absolute; top:90px; font-size: 100px;margin-left:-99px">
<p class="LondrinaSketch"><?php echo $is_sustainable_p_t ?>%</p>
</div>
 

<div class="OpenSans center" style="width:100%;     padding-left: 38px; font-size: 40px; position:absolute; top:618px; text-align: center; padding-right:75px">Wie nachhaltig bist <span class="underline">Du</span>?
      
     
      <p class="bigred LondrinaSketch"> ✖ ✖ ✖ </p> </div>
      <!--<p style=" font-size: 36px;">Nachhaltigkeit ist nicht nur, dass Bäume nachgepflanzt werden, wenn sie gefällt wurden. Nachhaltig wird das Aufforsten erst, wenn der Forstarbeiter fair bezahlt wird und der Eigentümer der Bäume seine Steuern zahlt und die Umwelt in akzeptablem Umfang beeinträchtigt wurde. </p>-->
</div>
