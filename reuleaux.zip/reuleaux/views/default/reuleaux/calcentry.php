<?php
/*
 * reuleaux-diagram calculator 
 * elgg-plugin
 * @purpose transform soziocultur, economy and ecology to sustainability
 * with sustainability metrics that are used in the quality-management system
 * @autor manfred salomon 
 * revision 27.07.2017
 * @link http://reuleaux-calculator.eu
 * 
 * page content
 */

$site_url = elgg_get_site_url();

$css_url = 'mod/reuleaux/vendors/bootstrap.min.css';
elgg_register_css('bootstrap', $css_url, 500);
elgg_load_css('bootstrap');

$css_url = 'mod/reuleaux/vendors/style.css';
elgg_register_css('reuleaux_style', $css_url, 500);
elgg_load_css('reuleaux_style');

//$js_url = 'mod/reuleaux/vendors/analytics.js';
//elgg_register_js('analytics', $js_url, 'head', 500);
//$OK = elgg_load_js('analytics');
Global $CONFIG;
if (strstr($_SERVER['REDIRECT_URL'],'/en/') || strstr($_SERVER['REDIRECT_URL'],'/de/') || strstr($_SERVER['REDIRECT_URL'],'/fr/') || strstr($_SERVER['REDIRECT_URL'],'/es/') || strstr($_SERVER['REDIRECT_URL'],'/it/') || strstr($_SERVER['REDIRECT_URL'],'/nl/')) {
        $no_flags = True;
        			$CONFIG->language = 'de';

				reload_all_translations();
}
 else {
    $no_flags = False;     
}
?>
<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script type="text/javascript">
        $(document).ready(function () {
            $(".error").hide();
            $("#btn_percent").addClass('active'); 
            $("#check-input").attr("disabled", true);
            step2 = false;
            $(".form-input-set").val('');
            $(".form-input-set-2").val('');
            $(".form-input-set").on("keyup", function () {
                $(".error").hide();

                if (!$.isNumeric($(this).val())) {
                    $(this).parent().find(".error").html("<?php echo elgg_echo('rel_msg_error_entry'); ?>").show();
                    $(this).val('');
                    return;
                }

                var check = $(".form-input-set").filter(function () {
                    return $.trim($(this).val()) === '';

                });

                if (!check.length) {
                    $("#check-input").attr("disabled", false);
                    if (step2 === true) {
                        $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>');
                    }
                } else {
                    $("#check-input").attr("disabled", true);
                    if (step2 === true) {
                        $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
                    }
                }

            });

            $(".form-input-set-2").on("keyup", function () {
                $(".error").hide();
                if (!$.isNumeric($(this).val())) {
                    $(this).parent().find(".error").html("<?php echo elgg_echo('rel_msg_error_entry'); ?>").show();
                    $(this).val('');
                    return;
                }

                // hidden points fields
                var checkh = $(".form-input-set-2").filter(function () {
                    return $.trim($(this).val()) === '';

                });
                if (!checkh.length) {
                    $("#check-input").attr("disabled", false);
                    if (step2 === true) {
       //                      $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
                    }
                } else {
                    $("#check-input").attr("disabled", true);
                    if (step2 === true) {
                        //       $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
                       
                    }
                }

            });


            $('.btn-primary').click(function () {
                $('.btn-primary').not(this).removeClass('active'); // remove buttonactive from the others
                $(this).addClass('active'); // toggle current clicked element
                $("#was").attr("value", $(this).attr('id'));
                if ($(this).attr('id') === 'btn_percent') {
                    $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_percent'); ?>');
                    $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_percent'); ?>');
                    step2 = false;
                    $(".form-input-set").attr('type', 'number');
                    $(".form-input-set").attr('max', '100');
                    $(".form-input-set").attr('min', '0.1');
                    $(".form-input-set").attr('step', '0.1');
                    $(".form-input-set-2").attr('type', 'hidden');
                  }
                if ($(this).attr('id') === 'btn_points') {
                    $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_points'); ?>');
                    $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>');
                    $(".form-input-set").attr('type', 'number');
                    $(".form-input-set").attr('max', '100000');
                    $(".form-input-set").attr('min', '1');
                    $(".form-input-set").attr('step', '1');
                    $(".form-input-set-2").attr('type', 'hidden');
                    step2 = true;


                        //checkpoints();



                }
            });

        });
        function isValidForm() {
            if ('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>' === $("#check-input").text()) {
                $(".form-input-set-2").attr('type', 'number');
                $(".form-input-set").attr('type', 'hidden');
                $("#menschh").attr('min', $("#mensch").val());
                $("#umwelth").attr('min', $("#umwelt").val());
                $("#wirtschafth").attr('min', $("#wirtschaft").val());
                $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
                $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_step2'); ?>');
                return false;
            }
            return true;
        }

        function checkpoints() {
            var check = $(".form-input-set").filter(function () {
                return $.trim($(this).val()) === '';

            });
            if (!check.length) {
                $("#check-input").attr("disabled", false);
                if (step2 === true) {
                    $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>');
                    $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_points'); ?>');
                }
            } else {
                $("#check-input").attr("disabled", true);
                if (step2 === true) {
                    $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
                    $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_step2'); ?>');
                }
            }
                        var check2 = $(".form-input-set-2").filter(function () {
                return $.trim($(this).val()) === '';

            });
            if (!check2.length) {
                $("#check-input").attr("disabled", false);
                if (step2 === true) {
                    $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>');
                    $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_points'); ?>');
                }
            } else {
                $("#check-input").attr("disabled", true);
                if (step2 === true) {
                    $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
                    $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_step2'); ?>');
                }
            }
        }
	
			function setLanguage(lang_id) {
				setCookie("client_language", lang_id, 30);
				document.location.href = document.location.href;			
			}
			function setCookie(c_name,value,expiredays) {
				var exdate = new Date();
				exdate.setDate(exdate.getDate() + expiredays);
				document.cookie = c_name + "=" + escape(value) + ";Path=/" + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
			}
	
</script>

<!--<div class="elgg-page-body">
    <div class="elgg-inner">
        <div class="elgg-layout elgg-layout-one-column clearfix">
            <div class="elgg-body elgg-main">-->

<body>
    <meta name="google-site-verification" content="mPKEYFZFsFUh5C-Wbfsw_PiJO3G9NwyXdf3WB-2MD54" />
    <div class="container con-des ">

        <header>

            <div class="clearfix top-space">
                <div class="row">
                    <div class="col-md-7 col-sm-5 col-xs-8" style="padding-right:0px; color:blue;">
                        <div class="header-text">
                            <span class="clsfontsmall"><?php echo elgg_echo('rel_main_label') ?></span><br/>
                            <span class="bold clsfontsmalltext"><?php echo elgg_echo('rel_main_label_sub') ?></span>
                        </div>
                    </div>
                    <div class="col-md-5 col-sm-7 col-xs-4">
                        <img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux-diagram-logo.png" alt="calculate sustainability" class="img-responsive logo">
                    </div>	
                </div>
            </div>
        </header>            
                <div class="cf-padding">
            <div class="row well well-sm bgbutton panel-padding msg-space" style="margin-right:-6px  ;">
            <div class="relframe" style="background:transparent  ;padding:0px;margin: 0px;border-width: 0px;margin-top: 0px">
                <div class="relTable text-right" style="background:transparent  ;margin-top:0px" >
                    <div class="relTableBody text-right" style="background:transparent  ;">

                        <div class="relTableRow text-right" style="background:transparent  ;">
                            <div class="relTableCell " style="background:transparent  ;border-right-width: 0px; border-width: 0px;" ></div>
                            <div class="relTableCell text-right" style="text-align: right; background:transparent  ;border-right-width: 0px; border-width: 0px;" ><span class="total_percentage" style="text-align: right; color: black;font-weight: normal"></span></div>
                            <div class="relTableCell text-right" style="background:transparent  ;border-right-width: 0px; border-width: 0px;" ><button type="button" id="btn_percent" class="btn btn-primary btn-prozent" ><?php echo elgg_echo('rel_btn_percent') ?></button></div>
                            <div class="relTableCell" style=" width: 86px; background:transparent  ;border-width: 0px;" ><button id="btn_points" type="button" class="btn btn-primary btn-punkte" ><?php echo elgg_echo('rel_btn_points') ?></div>

                        </div></div></div> </div> </div> </div>
            
            
            
<!--            <div class="row well well-sm bgbutton panel-padding msg-space">

                <div class="col-md-5 col-xs-7 col-sm-6 col-md-offset-3 text-center" style="margin-right: 5px;">	<button type="button" id="btn_percent" class="btn btn-primary btn-prozent" ><?php echo elgg_echo('rel_btn_percent') ?></button></div>
                <div class="col-md-2 col-xs-5 col-sm-6 btn-padding"><button id="btn_points" type="button" class="btn btn-primary btn-punkte" ><?php echo elgg_echo('rel_btn_points') ?></button>
                </div>

            </div>-->
            <?php
            if (isset($_SESSION['message']) && $_SESSION['message'] != "") {
                    ?>
                    <div class="">
                        <div class="span12">
                            <div class="alert alert-danger"><?php echo $_SESSION['message']; ?></div>
        <?php
        $_SESSION['message'] = '';
}
elgg_view('input/securitytoken');
$url = elgg_add_action_tokens_to_url($site_url . "/action/compute");
?>
                    <form id="calculator" style="margin-left: -2px;margin-top:26px" name="calculator" action="<?php echo $url ?>" enctype="multipart/form-data"  onsubmit="return isValidForm()" method="post" >
                        <div class="panel panel-default form-box col-md-12">

                            <div class="panel-body">
                                <div class="row" >
                                    <div class="col-xs-7 wps-padding-top" style="padding-right:0px">
                                        <span class="form-icon"><i class="fa fa-smile-o" aria-hidden="true"></i></span> <span class="wps-form-right-txt bold box-text"><?php echo elgg_echo('rel_human_short'); ?></span>
                                    </div>
                                    <div class="col-xs-5"><input type="number" step="0.1" min="0.1" max="100" name="mensch" id="mensch" class="form-control form-input-set">
                                        <input type="hidden" name="menschh" id="menschh" step="1"  min="11" max="100000" class="form-control form-input-set-2">
                                    <div class="error"></div>
                                    </div>
                                </div>
                            </div>
                                                        <div class="panel-body">	
                                <div class="row">
                                    <div class="col-xs-7 wps-padding-top" style="padding-right:0px"> <span class="form-icon wps-icon"><i class="fa fa-usd" aria-hidden="true"></i></span> <span class="wps-form-right-txt bold box-text form-right-txt"><?php echo elgg_echo('rel_economy_short'); ?></span> 
                                    </div>  
                                    <div class="col-xs-5"><input type="number" step="0.1"  min="0.1" max="100" name="wirtschaft" id="wirtschaft" class="form-control form-input-set">
                                        <input type="hidden" name="wirtschafth" step="1"  min="1" max="100000" id="wirtschafth" class="form-control form-input-set-2">
                                    <div class="error"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-xs-7 wps-padding-top" style="padding-right:0px">	
                                        <span class="form-icon"><i class="fa fa-globe" aria-hidden="true"></i></span> <span class="wps-form-right-txt bold box-text"><?php echo elgg_echo('rel_environment_short'); ?></span> </div>  
                                    <div class="col-xs-5"> <input type="number" name="umwelt" id="umwelt" step="0.1"  min="0.1" max="100" class="form-control form-input-set">
                                        <input type="hidden" name="umwelth" id="umwelth" step="1"  min="1" max="100000" class="form-control form-input-set-2">
                                    <div class="error"></div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class=" col-md-12">
                                <input type="hidden" name="was" id="was" value="btn_percent">
                                <button type="submit" id="check-input"  class="btn btn-block button"><?php echo elgg_echo('rel_btn_calculate_percent'); ?></button>
                            </div>

                        </div>	</form>
                    <div class="row text" id="label_hint" style="margin-top: 15px">
                        <h5><?php echo elgg_echo('rel_label_hint_percent'); ?></h5>
                    </div>
                    <footer>
                        <div class="footer-text" >

                            <div class="col-md-2 col-xs-2 footer-drop">
                                <p> <a href="<?php echo $site_url ?>info" target="_self"><?php echo elgg_echo('rel_main_label_information'); ?></a></p>
                            </div>
                            <div class="col-md-8 col-xs-8 language_selector footer-drop-center">
                                <?php      if (!$no_flags){ ?>
                <a href='javascript:setLanguage("en");' title='<?php echo elgg_echo('rel_label_translation_en'); ?>'>
                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/en.gif' alt='<?php echo elgg_echo('rel_label_translation_en'); ?>' title='<?php echo elgg_echo('rel_label_translation_en'); ?>'>
                </a>
                <a href='javascript:setLanguage("de");' title='<?php echo elgg_echo('rel_label_translation_de'); ?>'>
                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/de.gif' alt='<?php echo elgg_echo('rel_label_translation_de'); ?>' title='<?php echo elgg_echo('rel_label_translation_de'); ?>'>
                <a>
                    <a href='javascript:setLanguage("fr");' title='<?php echo elgg_echo('rel_label_translation_fr'); ?>'>
                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/fr.gif' alt='<?php echo elgg_echo('rel_label_translation_fr'); ?>' title='<?php echo elgg_echo('rel_label_translation_fr'); ?>'>
                </a>  
                            <a href='javascript:setLanguage("es");' title='<?php echo elgg_echo('rel_label_translation_es'); ?>'>
                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/es.gif' alt='<?php echo elgg_echo('rel_label_translation_es'); ?>' title='<?php echo elgg_echo('rel_label_translation_es'); ?>'>
                </a>  
                <a href='javascript:setLanguage("it");' title='<?php echo elgg_echo('rel_label_translation_it'); ?>'>
                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/it.gif' alt='<?php echo elgg_echo('rel_label_translation_it'); ?>' title='<?php echo elgg_echo('rel_label_translation_it'); ?>'>
                </a>                    
                <a href='javascript:setLanguage("nl");' title='<?php echo elgg_echo('rel_label_translation_nl'); ?>'>
                    <img   style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/nl.gif' alt='<?php echo elgg_echo('rel_label_translation_nl'); ?>' title='<?php echo elgg_echo('rel_label_translation_nl'); ?>'>
                </a>  
                    <?php } ?>
                            </div>
                            <div class="col-md-2 col-xs-2 footer-drop">
                                <p class="float-right"><a href="<?php echo $site_url ?>impressum" target="_self"><?php echo elgg_echo('rel_label_link_impressum'); ?></a></p>
                            </div>
                        </div>
                    </footer>
                </div>
            </div> </div></div>
            </body>











            <!--                
                        </div>
                    </div>
                </div>
            </div>-->