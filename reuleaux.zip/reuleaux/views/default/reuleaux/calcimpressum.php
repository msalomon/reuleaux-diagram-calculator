<?php
/*
 * reuleaux-diagram calculator 
 * elgg-plugin
 * @purpose transform soziocultur, economy and ecology to sustainability
 * with sustainability metrics that are used in the quality-management system
 * @autor manfred salomon 
 * revision 27.07.2017
 * @link http://reuleaux-calculator.eu
 * 
 * page content
 */
$dummy = get_language() ;
$js_url = 'mod/reuleaux/vendors/analyticstracking.js';
elgg_register_js('analyticstracking', $js_url, 'head', 500);
elgg_load_js('analyticstracking');
$site_url = elgg_get_site_url();

$css_url = 'mod/reuleaux/vendors/bootstrap.min.css';
elgg_register_css('bootstrap', $css_url, 500);
elgg_load_css('bootstrap');

$css_url = 'mod/reuleaux/vendors/style.css';
elgg_register_css('reuleaux_style', $css_url, 500);
elgg_load_css('reuleaux_style');

Global $CONFIG;
if (strstr($_SERVER['REDIRECT_URL'],'/en/') || strstr($_SERVER['REDIRECT_URL'],'/de/') || strstr($_SERVER['REDIRECT_URL'],'/fr/') || strstr($_SERVER['REDIRECT_URL'],'/es/') || strstr($_SERVER['REDIRECT_URL'],'/it/') || strstr($_SERVER['REDIRECT_URL'],'/nl/')) {
        $no_flags = True;
}
 else {
    $no_flags = False;     
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script type="text/javascript">
			function setLanguage(lang_id) {
				setCookie("client_language", lang_id, 30);
				document.location.href = document.location.href;			
			}
			function setCookie(c_name,value,expiredays) {
				var exdate = new Date();
				exdate.setDate(exdate.getDate() + expiredays);
				document.cookie = c_name + "=" + escape(value) + ";Path=/" + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
                        }


</script>

<!--<div class="elgg-page-body">
    <div class="elgg-inner">
        <div class="elgg-layout elgg-layout-one-column clearfix">
            <div class="elgg-body elgg-main">-->

<body>
    <div class="container con-des">

        <header>

            <div class="clearfix top-space">
                <div class="row">
                    <div class="col-md-7 col-sm-5 col-xs-8" style="padding-right:0px; color:blue;">
                        <div class="header-text">
                            <span class="clsfontsmall"><?php echo elgg_echo('rel_main_label',$dummy) ?></span><br/>
                            <span class="bold clsfontsmalltext"><?php echo elgg_echo('rel_main_label_sub',$dummy) ?></span>
                        </div>
                    </div>
                    <div class="col-md-5 col-sm-7 col-xs-4">
                        <img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux-diagram-logo.png" alt="calculate sustainability" class="img-responsive logo">
                    </div>	
                </div>
            </div>
        </header>            
        <div class="cf-padding">
            <div class="row well well-sm bgbutton panel-padding msg-space">
                <div class="col-xs-7"      style="margin-top: 7px;padding-left:0px"> 
                    <span class="clsfontsmall" style="color: #6168AE;"><strong><?php echo elgg_echo('rel_main_label_impressum',$dummy) ?></strong></span>
                    <!--<button type="button" class="btn btn-primary active btn-prozent">Prozent</button>-->
                </div>  
                <div class="col-md-1 col-xs-5 col-sm-6 btn-padding"><a id="btn_zurück" type="button" href="<?php echo $site_url ?>rate" target="_self" class="btn btn-primary btn-punkte"><?php echo elgg_echo('rel_btn_back',$dummy) ?></a>
                </div>

            </div></div>
        <div class="cf-padding">
            <div class="col-md-12 text text-scroll " style="padding-right:5px; font-size: 13px;">
                <?php
                switch (get_language()) {
                        case 'de':
                                ?>


                                IMPRESSUM<br><br>
                                KONTAKTADRESSE<br><br>
                                Manfred Salomon<br>
                                Mühlengraben 1<br>
                                50169 Kerpen<br>
                                Deutschland<br>
                                Mail: contact@sustainability-calculator.eu<br>
                                <br><br>
                                HAFTUNGSAUSSCHLUSS<br>
                                Der Autor übernimmt keinerlei Gewähr hinsichtlich der inhaltlichen Richtigkeit, Genauigkeit, Aktualität, Zuverlässigkeit und Vollständigkeit der Informationen.
                                Haftungsansprüche gegen den Autor wegen Schäden materieller oder immaterieller Art, welche aus dem Zugriff oder der Nutzung bzw. Nichtnutzung der veröffentlichten Informationen, durch Missbrauch der Verbindung oder durch technische Störungen entstanden sind, werden ausgeschlossen.
                                Alle Angebote sind unverbindlich. Der Autor behält es sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.
                                <br><br>
                                HAFTUNG FÜR LINKS<br>
                                Verweise und Links auf Webseiten Dritter liegen ausserhalb unseres Verantwortungsbereichs Es wird jegliche Verantwortung für solche Webseiten abgelehnt. Der Zugriff und die Nutzung solcher Webseiten erfolgen auf eigene Gefahr des Nutzers oder der Nutzerin.
                                <br><br>
                                URHEBERRECHTE<br>
                                Die Urheber- und alle anderen Rechte an Inhalten, Bildern, Fotos oder anderen Dateien auf der Website (nicht die Dateien, die von anonymen Benutzern hochgeladen werden) gehören ausschliesslich Manfred Salomon oder den speziell genannten Rechtsinhabern. <br>
                                Für die Reproduktion der Bilder, deren Urheber Manfred Salomon ist (Stichwort: <Docu-Clipps-Button und <a href="<?php echo $site_url ?>info" target="_blank">Information</a>), gibt es keine Beschränkung. 
                                    <br><br>
                                    WICHTIGER HINWEIS<br>
                                    Mit den "Docu-Clipps" hast du die Möglichkeit deine Nachhaltigkeitsberechnung zu personalisieren:
                                    Du hast dort die Möglichkeit, dein eigenes Statement zu deiner Bewertung zu formulieren und außerdem kannst du eine PDF-Datei und ein Bild hinzufügen.
                                    Dein Statement wird dann statt des Standard-Statements zum erzielten Rating angezeigt und die PDF-Datei steht dem Aufrufer deines Ratings/Bewertung zum Download zur Verfügung.
                                    Die Anlagen kannst du nur einmal, sofort(!) nach der Erstellung deines Ratings hinzufügen, weil die Benutzung des Reuleaux-Diagramm Rechners anonym geschieht und deshalb eine spätere Zuordnung nicht möglich ist.
                                    Aus diesem Grund musst du auch die Schlüssel-ID <br>(z. B. 7Cu5LSpEP4xHZaSYFZehZg) mit copy und paste sichern. Nur so kannst du dein Rating dann auch wieder aufrufen mit:<br>
                                    http://reuleaux-calculator.eu/result/[Schlüssel-ID]
                                    <br>
                                    Wenn du an den Link das Länderzeichen de, en, fr, es, it, nl anhängst wird dein Rating entsprechend übersetzt. Beispiel:<br> 
                                    http://reuleaux-calculator.eu/result/[Schlüssel-ID]/en
                                    <br>
                                    Es wird verschiedene Sonderseiten geben, die aufgerufen werden können, indem vor der Schlüssel-ID ein bestimmtes Wort (z. B. "my) eingegeben wird. Beispiel:<br>
                                    http://reuleaux-calculator.eu/my/[Schlüssel-ID]/en
                                    <br>
                                    Probier es aus.
                                    <br>
                                    Über Anregungen und Wünsche freue ich mich.
                                    <br><br>
                                    Viel Spaß und gutes Gelingen!
                                    <br><br>
                                    Manfred Salomon
                                    <br><br><br>
                                    P.S. Die Übersetzungen aus dem Deutschen, wurden überwiegend mit "Google Translate" gemacht und dürften fehlerhaft sein. Aber mit irgend etwas muss man ja anfangen, oder? Über Korrekturhinweise freue ich mich.
                                    <br><br>
                                    <div style="font-size: 11px ">ÜBERSETZER/IN GESUCHT<br>                                
                                        Wer möchte eine Sprache der Seite betreuen?
                                        <br><br>
                                        LEKTOR/IN GESUCHT<br>                                
                                        Der Autor der Seite ist Legastheniker.
                                        Wer möchte den deutschen Text der Seite betreuen? </div>







                                    <?php
                                    break;
                            case 'en':
                                    ?>
                                    CONTACT<br>
                                    Manfred Salomon <br>
                                    Mühlengraben 1<br>
                                    50169 Kerpen<br>
                                    Germany<br>
                                    Mail: contact@sustainability-calculator.eu<br>
                                    <br>
                                    DISCLAIMER <br>
                                    The author reserves the right not to be responsible for the topicality, correctness, completeness or quality of the information provided.
                                    Liability claims against the author due to damages of a material or immaterial nature resulting from the access or use or non-use of the published information, misuse of the connection or technical disturbances are excluded.
                                    All offers are without obligation. The author expressly reserves the right to change, amend, or delete parts of the pages or the entire offer without prior notice, or to temporarily or permanently terminate the publication.
                                    <br>
                                    LIABILITY FOR LINKS <br>
                                    References and links to third-party websites are beyond our responsibility. Any responsibility for such websites is rejected. The access and use of such websites is at the user's own risk.
                                    <br>
                                    COPYRIGHT <br>
                                    The copyright and all other rights to content, images, photos or other files on the website (not the files uploaded by anonymous users) are exclusively owned by Manfred Salomon or the specifically named rightholders. <br>
                                    For the reproduction of the images created by Manfred Salomon (keyword: Docu-Clipps-Button and Information) There is no restriction. <br>
                                    IMPORTANT NOTE <br>
                                    Among the Docu-Clipps you have the possibility to personalize your sustainability calculation:
                                    You have the possibility to formulate your own statement about your evaluation and you can also add a PDF file and a picture.
                                    Your statement is then displayed instead of the standard statement on the rating achieved, and the PDF file is available to the caller of your rating / rating for download.
                                    You can only add the attachments once, immediately (!) After the creation of your rating because the use of the Reuleaux diagram calculator is anonymous and therefore a later allocation is not possible.
                                    For this reason, you must also back up the key ID (for example, 7Cu5LSpEP4xHZaSYFZehZg) with copy and paste. This is the only way to get your rating back with: <br>
                                    http://reuleaux-calculator.eu/result/[key ID]
                                        <br>
                                        If you attach the country code de, en, fr, es, it, nl, your rating will be translated accordingly. Example: <br>
                                        http://reuleaux-calculator.eu/result/[key ID]/en
                                        <br>
                                        There will be different special pages that can be called by typing a specific word (for example, "my") before the key ID. <br>
                                        http://reuleaux-calculator.eu/my/[key ID]/en
                                        <br>
                                        Try it.
                                        <br>
                                        I am happy about suggestions and wishes.
                                        <br><br>
                                        Have fun and good luck!
                                        <br><br>
                                        Manfred Salomon
                                        <br><br><br>
                                        P.S. The translations from the German, were made mostly with "Google Translate" and should be faulty. But something has to be done, right? I am looking forward to corrections.
                                        <br>
                                        <?php
                                        break;
                                case 'fr':
                                        ?>
                                        CONTACT <br>
                                        Manfred Salomon <br>
                                        Mühlengraben 1 <br>
                                        50169 Kerpen <br>
                                        Allemagne <br>
                                        Mail: contact@sustainability-calculator.eu<br>
                                        <br>
                                        AVERTISSEMENT <br>
                                        L'auteur se réserve le droit de ne pas être responsable de l'actualité, de l'exactitude, de l'intégralité ou de la qualité des informations fournies. <br>
                                        Les réclamations de responsabilité contre l'auteur en raison de dommages matériels ou immatériels résultant de l'accès ou de l'utilisation ou de la non-utilisation de l'information publiée, une mauvaise utilisation de la connexion ou des perturbations techniques sont exclus. <br>
                                        Toutes les offres sont sans engagement. L'auteur se réserve expressément le droit de modifier, de modifier ou de supprimer des parties des pages ou de l'offre complète sans préavis, ou de résilier temporairement ou définitivement la publication.
                                        <br>
                                        RESPONSABILITÉ POUR LES LIENS
                                        Les références et les liens vers des sites Web tiers sont hors de notre responsabilité. Toute responsabilité pour ces sites Web est rejetée. L'accès et l'utilisation de ces sites Web sont à la charge de l'utilisateur.
                                        <br>
                                        DROIT D'AUTEUR <br>
                                        Le droit d'auteur et tous les autres droits sur le contenu, les images, les photos ou d'autres fichiers sur le site (et non les fichiers téléchargés par des utilisateurs anonymes) appartiennent exclusivement à Manfred Salomon ou aux titulaires de droits spécifiquement nommés. <br>
                                        Pour la reproduction des images crées par Manfred Salomon (mot-clé: “Docu-Clipps” et Information) Il n'y a aucune restriction.-->
                                        <br>
                                        NOTE IMPORTANTE
                                        Parmi les Docu-Clipps, vous avez la possibilité de personnaliser votre calcul de durabilité:
                                        Vous avez la possibilité de formuler votre propre déclaration sur votre évaluation et vous pouvez également ajouter un fichier PDF et une image. <br>
                                        Votre déclaration est ensuite affichée à la place de la déclaration standard sur la note obtenue, et le fichier PDF est disponible pour l'appelant de votre notation / évaluation pour téléchargement. <br>
                                        Vous pouvez uniquement ajouter les pièces jointes une fois, immédiatement (!) Après la création de votre évaluation, car l'utilisation du calculateur de diagramme de Reuleaux est anonyme et, par conséquent, une allocation ultérieure n'est pas possible. <br>
                                        Pour cette raison, vous devez également sauvegarder l'ID de la clé (par exemple, 7Cu5LSpEP4xHZaSYFZehZg) avec copier et coller. C'est le seul moyen de récupérer votre note:
                                        http://reuleaux-calculator.eu/result/[ID de clé]<br>
                                            Si vous joignez le code de pays de, en, fr, es, nl, votre classement sera traduit en conséquence. exemple: <br>

                                            http://reuleaux-calculator.eu/result/[ID de clé]/en
                                            <br>
                                            Il y aura différentes pages spéciales qui peuvent être appelées en tapant un mot spécifique (par exemple, "mon") avant l'identifiant de la clé. <br>

                                            http://reuleaux-calculator.eu/my/[ID de clé]/en<br>

                                            <br>
                                            Essayez-le.
                                            <br><br>
                                            Je suis heureux de suggestions et de souhaits.
                                            <br><br>
                                            Amusez-vous bien et bonne chance!
                                            <br><br>
                                            Manfred Salomon
                                            <br><br><br>
                                            Post-scriptum. Les traductions de l'allemand ont été faites principalement avec "Google Translate" et devraient être défectueux. Mais il faut faire quelque chose, n'est-ce pas? J'attends avec impatience des corrections.
                                            <br>

                                            <?php
                                            break;
                                    case 'es':
                                            ?>
Contacto <br>
Manfred Salomon <br>
Mühlengraben 1<br>
50169 Kerpen<br> 
Alemania<br>
Mail: contact@sustainability-calculator.eu<br>
                                                <br>
El autor se reserva el derecho de no ser responsable de la actualidad, exactitud, integridad o calidad de la información proporcionada. <br>
Quedan excluidas las reclamaciones de responsabilidad contra el autor por daños de naturaleza material o inmaterial resultantes del acceso o uso o no uso de la información publicada, mal uso de la conexión o perturbaciones técnicas. <br>
Todas las ofertas son sin compromiso. El autor se reserva expresamente el derecho de cambiar partes o toda la oferta sin previo aviso, añadir, eliminar o interrumpir la publicación temporal o permanente. <br>
                                                <br><br>
RESPONSABILIDAD POR ENLACES<br>
Las referencias y los enlaces a sitios web de terceros están fuera de nuestra responsabilidad y cualquier responsabilidad por dichos sitios web es rechazada. El acceso y uso de dichos sitios web es por cuenta y riesgo del usuario.
                                                <br><br>
COPYRIGHT <br>
Los derechos de autor y todos los demás derechos relativos a los textos, ilustraciones, fotografías u otros archivos en el sitio web (no los archivos que se cargan por usuarios anónimos) pertenecen exclusivamente o mencionadas propietarios Manfred Salomon. <br>
Para la reproducción de imágenes cuyos derechos de autor Manfred Salomon (palabra clave: <botón Docu-hemoclips y  Código de la Información) es No hay restricción. <br>
                                                                                                                                     <br><br>
NOTA IMPORTANTE<br>
Entre los Docu-Clipps tiene la posibilidad de personalizar su cálculo de sostenibilidad: <br>
Usted tiene la posibilidad de formular su propia declaración sobre su evaluación y también puede agregar un archivo PDF y una imagen. <br>
Su estado se mostrará en lugar de los estados estándar en la puntuación alcanzada y el archivo PDF está disponible para la persona que llama de sus notas / comentarios disponibles para su descarga. <br>
Las plantas se puede sólo una vez, inmediatamente (!) Añadir después de crear sus calificaciones, porque el uso de la computadora carta anónima suceso Reuleaux y por lo tanto una cesión subsiguiente no es posible. <br>
Por esta razón, también tiene el ID de la llave (z. B. 7Cu5LSpEP4xHZaSYFZehZg) con copiar y pegar seguro. Esta es la única manera de obtener su calificación con: <br>
http://reuleaux-calculator.eu/result/[identificador]
                                                                <br>
Si agrega el código de país de, en, fr, es, it, nl, su calificación se traducirá en consecuencia. ejemplo: <br>
http://reuleaux-calculator.eu/result/[identificador]/en
                                                                    <br>
Habrá diferentes páginas especiales que se pueden llamar escribiendo una palabra específica (por ejemplo, "mi") antes del identificador de clave. <br>
http://reuleaux-calculator.eu/my/[identificador]/en
                                                                        <br>
Pruébalo.
                                                                        <br><br>
Estoy contento con las sugerencias y deseos.
                                                                        <br><br>
¡Diviértete y buena suerte!
                                                                        <br><br>
Manfred Salomon
                                                                        <br><br><br>
PD Las traducciones del alemán, se hicieron principalmente con "Google Translate" y deben ser defectuosos. Pero algo tiene que ser hecho, ¿verdad? Estoy mirando adelante a las correcciones.
                                                                        <br>

                                                    <?php
                                                    break;
                                            case 'it':
                                                    ?>
                                                    CONTATTO <br>
Manfred Salomon <br>
Mühlengraben 1<br>
50169 Kerpen <br>
Germania <br>
Mail: contact@sustainability-calculator.eu<br>
<br>
NEGAZIONE <br>
L'autore si riserva il diritto di non essere responsabile per l'attualità, la correttezza, la completezza o la qualità delle informazioni fornite. <br>
Sono esclusi i reclami di responsabilità nei confronti dell'autore a causa di danni di natura materiale o immateriale derivanti dall'accesso, dall'utilizzo o dal non uso delle informazioni pubblicate, dall'uso improprio della connessione o dai disturbi tecnici. <br>
Tutte le offerte sono senza obbligo. L'autore si riserva espressamente il diritto di modificare, modificare o cancellare parti delle pagine o dell'intera offerta senza preavviso o di interrompere temporaneamente o definitivamente la pubblicazione.
                                                                                    <br>
RESPONSABILITÀ PER LINK<br>
I riferimenti ei link a siti di terze parti sono al di fuori della nostra responsabilità. Ogni responsabilità per tali siti web viene rifiutata. L'accesso e l'uso di tali siti sono a rischio dell'utente.
                                                                                    <br>
COPYRIGHT <br>
Il diritto d'autore e tutti gli altri diritti relativi ai testi, illustrazioni, foto o altri file sul sito web (non i file che sono stati caricati dagli utenti anonimi) appartengono esclusivamente o menzionati proprietari Manfred Salomon. <br>
Per la riproduzione di immagini il cui copyright Manfred Salomon (parola chiave: pulsante Docu-hemoclips e  codice di informazione) è Non esiste alcuna restrizione.
                                                                                        <br>
NOTA IMPORTANTE<br>
Tra i Docu-Clipp puoi avere la possibilità di personalizzare il tuo calcolo della sostenibilità: <br>
Hai la possibilità di formulare la propria dichiarazione sulla tua valutazione e puoi anche aggiungere un file PDF e un'immagine. <br>
La tua dichiarazione viene visualizzata invece dell'istruzione standard relativa al voto raggiunto e il file PDF è disponibile al chiamante del tuo rating / rating per il download. <br>
È possibile aggiungere solo gli allegati una volta, immediatamente (!) Dopo la creazione del tuo rating perché l'utilizzo del calcolatore del diagramma di Reuleaux è anonimo e pertanto non è possibile un'allocazione successiva. <br>
Per questo motivo, è necessario eseguire il backup anche dell'ID chiave (ad esempio, 7Cu5LSpEP4xHZaSYFZehZg) con copia e incolla. Questo è l'unico modo per ottenere la tua valutazione: <br>
http://reuleaux-calculator.eu/result/[key ID]<br>
                                                                                                <br>
Se si inserisce il codice di paese de, en, fr, es, it, nl, la tua valutazione verrà tradotta di conseguenza. esempio:
http://reuleaux-calculator.eu/result/[key ID]/en<br>
                                                                                                    <br>
Ci saranno diverse pagine speciali che possono essere richiamate digitando una parola specifica (ad esempio "mio") prima dell'ID di chiave, ad esempio:
http://reuleaux-calculator.eu/my/[key ID]/en<br>
                                                                                                        <br>
Prova.
                                                                                                        <br><br>
Sono felice di suggerimenti e desideri.
                                                                                                        <br><br>
Divertiti e buona fortuna!
                                                                                                        <br><br>
Manfred Salomon
                                                                                                        <br><br><br>
Post scriptum. Le traduzioni dal tedesco, sono state fatte principalmente con "Google Translate" e dovrebbero essere difettose. Ma bisogna fare qualcosa, giusto? Non vedo l'ora per le correzioni.
                                                                                                        <br>



                                                        <?php
                                                        break;
                                                case 'nl':
                                                        ?>
CONTACT <br>
Manfred Salomon <br>
Mühlengraben 1<br>
50169 Kerpen <br>
Duitsland<br>
Mail: contact@sustainability-calculator.eu<br>
                                                                                        <br>
DISCLAIMER <br>
De auteur behoudt zich het recht voor om niet verantwoordelijk te zijn voor de actualiteit, juistheid, volledigheid of kwaliteit van de verstrekte informatie. <br>
Aansprakelijkheid claims tegen de auteur voor materiële of immateriële aard, zijn als gevolg van de toegang tot, het gebruik of het niet-gebruik van de gepubliceerde door verkeerd gebruik van de verbinding of technische storingen informatie zijn uitgesloten. <br>
Alle aanbiedingen zijn vrijblijvend. De auteur behoudt zich uitdrukkelijk het recht voor om onderdelen of het gehele aanbod zonder voorafgaande kennisgeving, aan te vullen, te verwijderen of te staken publicatie tijdelijk of permanent.
                                                                                        <br>
AANSPRAKELIJKHEID VOOR LINKS<br>
Verwijzingen en links naar websites van derden zijn buiten onze verantwoordelijkheid. Elke verantwoordelijkheid voor dergelijke websites wordt afgewezen. De toegang en het gebruik van dergelijke websites is op eigen risico van de gebruiker.
                                                                                        <br>
COPYRIGHT <br>
Het auteursrecht en alle andere rechten met betrekking tot de teksten, illustraties, foto's of andere bestanden op de website (niet de bestanden die worden geüpload door anonieme gebruikers) komen uitsluitend of genoemde eigenaren Manfred Salomon. <br>
Voor de weergave van foto's waarvan het auteursrecht Manfred Salomon (trefwoord: Docu-hemoclips knop en  Informatie code) is Er is geen beperking.
                                                                                            <br>
BELANGRIJKE NOTA<br>
Onder de Docu-Clipps heeft u de mogelijkheid om uw duurzaamheidsberekening te personaliseren: <br>
U heeft de mogelijkheid om uw eigen verklaring over uw evaluatie te formuleren en u kunt ook een PDF-bestand en een foto toevoegen. <br>
Uw verklaring wordt dan weergegeven in plaats van de standaardverklaring op de bereikte beoordeling, en het PDF-bestand is beschikbaar voor de beller van uw rating / rating voor download. <br>
De planten kun je maar één keer, onmiddellijk (!) Na het maken van uw ratings, omdat het gebruik van de Reuleaux grafiek computer anoniem gebeuren en dus een volgende opdracht is niet mogelijk. <br>
Om deze reden, heb je ook de sleutel ID (z. B. 7Cu5LSpEP4xHZaSYFZehZg) met kopiëren en plakken veilig. Dit is de enige manier om uw rating terug te krijgen met: <br>
http://reuleaux-calculator.eu/result/[sleutel-ID]<br>
                                                                                                    <br>
Als u de landcode hecht de, en, fr, es, it, nl, wordt uw beoordeling dienovereenkomstig vertaald. bijvoorbeeld: <br>
http://reuleaux-calculator.eu/result/[sleutel-ID]/en<br>
                                                                                                        <br>
Er zullen verschillende speciale pagina's zijn die kunnen worden genoemd door een specifiek woord te typen (bijvoorbeeld 'mijn') voor het sleutel-ID. <br>
http://reuleaux-calculator.eu/my/[sleutel-ID]/en
                                                                                                            <br>
Probeer het uit.
                                                                                                            <br><br>
Ik ben blij met suggesties en wensen.
                                                                                                            <br><br>
Veel plezier en succes!
                                                                                                            <br><br>
Manfred Salomon<br>
                                                                                                            <br><br><br>
Postscriptum. De vertalingen uit het Duits werden meestal gemaakt met "Google Translate" en moeten defect zijn. Maar er moet iets gebeuren, toch? Ik kijk uit naar correcties.
                                           

                                                                                     

                                                            <?php
                                                            break;
                                            }
                                            ?>

                                            </div>

                                            </div>
                                            <footer>
                                                <div class="footer-text" >

                                                    <div class="col-md-2 col-xs-2 footer-drop" style="top:15px;">
                                                        <p> <a href="<?php echo $site_url ?>info" target="_self"><?php echo elgg_echo('rel_label_link_information',$dummy); ?></a></p>
                                                    </div>
                                                    
                                                    
                                                    <div class="col-md-8 col-xs-8 language_selector footer-drop-center"style="top:20px;">
                                                       <?php      if (!$no_flags){ ?>
                                                        <a href='javascript:setLanguage("en");' title='<?php echo elgg_echo('rel_label_translation_en'); ?>'>
                                                            <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/en.gif' alt='<?php echo elgg_echo('rel_label_translation_en'); ?>' title='<?php echo elgg_echo('rel_label_translation_en'); ?>'>
                                                        </a>
                                                        <a href='javascript:setLanguage("de");' title='<?php echo elgg_echo('rel_label_translation_de'); ?>'>
                                                            <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/de.gif' alt='<?php echo elgg_echo('rel_label_translation_de'); ?>' title='<?php echo elgg_echo('rel_label_translation_de'); ?>'>
                                                            <a>
                                                                <a href='javascript:setLanguage("fr");' title='<?php echo elgg_echo('rel_label_translation_fr'); ?>'>
                                                                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/fr.gif' alt='<?php echo elgg_echo('rel_label_translation_fr'); ?>' title='<?php echo elgg_echo('rel_label_translation_fr'); ?>'>
                                                                </a>  
                                                                <a href='javascript:setLanguage("es");' title='<?php echo elgg_echo('rel_label_translation_es'); ?>'>
                                                                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/es.gif' alt='<?php echo elgg_echo('rel_label_translation_es'); ?>' title='<?php echo elgg_echo('rel_label_translation_es'); ?>'>
                                                                </a>  
                                                                <a href='javascript:setLanguage("it);' title='<?php echo elgg_echo('rel_label_translation_it'); ?>'>
                                                                    <img  style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/it.gif' alt='<?php echo elgg_echo('rel_label_translation_it'); ?>' title='<?php echo elgg_echo('rel_label_translation_it'); ?>'>
                                                                </a>                    
                                                                <a href='javascript:setLanguage("nl");' title='<?php echo elgg_echo('rel_label_translation_nl'); ?>'>
                                                                    <img   style="margin-right: 5px;" src='<?php echo $site_url ?>mod/language_selector/_graphics/flags/nl.gif' alt='<?php echo elgg_echo('rel_label_translation_nl'); ?>' title='<?php echo elgg_echo('rel_label_translation_nl'); ?>'>
                                                                </a>  
                                                                 <?php } ?>
                                                                </div>
                                                   
                                                                <div class="col-md-2 col-xs-2 footer-drop" style="top:15px;">
                                                                    <p class="float-right"><a href="<?php echo $site_url ?>impressum" target="_self"><?php echo elgg_echo('rel_label_link_impressum',$dummy); ?></a></p>
                                                                </div>
                                                                </div>
                                                                </footer>

                                                                </div>