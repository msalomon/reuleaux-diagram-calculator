<?php

// Ensure that only logged-in users can see this page
//elgg_gatekeeper();

// Set context and title

elgg_set_context('result');
elgg_set_page_owner_guid(elgg_get_logged_in_user_guid());
$title = elgg_echo('rel_site_result');

// wrap intro message in a div
$intro_message = elgg_view('reuleaux/calcresult',$vars);

//$params = array(
//	'content' => $intro_message,
//	'num_columns' => 3,
//	'show_access' => false,
//);
//$widgets = elgg_view_layout('widgets', $params);
//
//$body = elgg_view_layout('one_column', array(
//	'title' => false,
//	'content' => $widgets
//));
$params = array(
	'content' => $intro_message,
	'show_access' => false,
        'title' => false
);
$body = elgg_view_layout('', $params);

echo elgg_view_page($title, $body);