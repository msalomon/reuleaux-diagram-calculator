<?php

/*
 * reuleaux-diagram calculator 
 * elgg-plugin
 * @purpose transform soziocultur, economy and ecology to sustainability
 * with sustainability metrics that are used in the quality-management system
 * @autor manfred salomon 
 * revision 27.07.2017
 * @link http://reuleaux-calculator.eu
 * 
 *  prepare page
 */

// Set context and title
elgg_set_context('entry');

$title = elgg_echo('rel_site_title_entry');

// wrap content in a div
$calc_content = elgg_view('reuleaux/calcentry');

$params = array(
	'content' => $calc_content,
	'show_access' => false,
        'title' => false,
    'meta name' => "<meta name='google-site-verification' content='mPKEYFZFsFUh5C-Wbfsw_PiJO3G9NwyXdf3WB-2MD54' />",
);
$body = elgg_view_layout('', $params);

echo elgg_view_page($title, $body);