-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 10. Okt 2017 um 09:00
-- Server-Version: 5.7.14
-- PHP-Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `reuleaux`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rel_query`
--

CREATE TABLE `rel_query` (
  `MenschProzent` float DEFAULT NULL,
  `UmweltProzent` float DEFAULT NULL,
  `WirtschaftProzent` float DEFAULT NULL,
  `MenschPunkte` int(11) DEFAULT NULL,
  `UmweltPunkte` int(11) DEFAULT NULL,
  `WirtschaftPunkte` int(11) DEFAULT NULL,
  `MenschMaxPunkte` int(11) NOT NULL,
  `UmweltMaxPunkte` int(11) NOT NULL,
  `WirtschaftMaxPunkte` int(11) NOT NULL,
  `CalcWhat` varchar(50) NOT NULL,
  `tokenID` varchar(100) NOT NULL,
  `ts` int(11) NOT NULL,
  `r_standard` float NOT NULL,
  `r_human` float NOT NULL,
  `r_environment` float NOT NULL,
  `r_economic` float NOT NULL,
  `a_max` float NOT NULL,
  `is_survivable_p_t` float NOT NULL,
  `is_fair_p_t` float NOT NULL,
  `is_acceptable_p_t` float NOT NULL,
  `s_max` float NOT NULL,
  `is_sustainable` float NOT NULL,
  `is_sustainable_p_t` float NOT NULL,
  `rating_ext` int(11) NOT NULL,
  `ID` bigint(20) UNSIGNED NOT NULL,
  `called` int(11) DEFAULT NULL,
  `audit_candidate` varchar(180) DEFAULT NULL,
  `audit_text_de` text,
  `audit_text_en` text,
  `audit_text_tr` text,
  `audit_text_fr` text,
  `audit_text_it` text,
  `audit_text_nl` text,
  `audit_text_es` text,
  `change_date` datetime DEFAULT NULL,
  `last_call_date` datetime DEFAULT NULL,
  `file_guid` varchar(255) DEFAULT NULL,
  `image_guid` varchar(255) DEFAULT NULL,
  `audit_link` varchar(800) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `rel_query`
--
ALTER TABLE `rel_query`
  ADD UNIQUE KEY `ID` (`ID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `rel_query`
--
ALTER TABLE `rel_query`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
