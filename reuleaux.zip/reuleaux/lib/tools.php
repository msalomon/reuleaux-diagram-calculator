<?php

/**
 * 	reuleaux plugin
 * 	
 * 	@author Manfred Salomon @lisha
 * 	@copyright Manfred Salomon 

 * */ 
//  function prozent($erreicht=0, $gefordert=0) 
//        { 
//        if (($erreicht != 0) && ($gefordert != 0) )         # Wenn $zahl nicht 0 ist, dann ... 
//            { 
//            $ergebnis = ($erreicht * 100) / $gefordert; 
//            return $ergebnis; 
//            } 
//        } 

function rel_language_selector_set_logged_out_user_language($new_lang) {
	global $CONFIG;
	
//	if (elgg_is_logged_in()) {
//		return;
//	}

//	if (!empty($_COOKIE['client_language'])) {
//		// switched with language selector
//		$new_lang = $_COOKIE['client_language'];
//	} else {
//
//		$browserlang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
//
//		if (!empty($browserlang)) {
//			// autodetect language
//
//			if (elgg_get_plugin_setting("autodetect", "language_selector") == "yes") {
//				$new_lang = $browserlang;
//			}
//		}
//	}

	if (!empty($new_lang) && ($new_lang !== $CONFIG->language)) {
		$allowed = rel_language_selector_get_allowed_translations();
		if (in_array($new_lang, $allowed)) {
			// set new language
			$CONFIG->language = $new_lang;

			// language has been change; reload language keys
			if (elgg_is_active_plugin("translation_editor")) {
				translation_editor_load_translations();
			} else {
                                                                $new_lang = $_COOKIE['select_language'];
                                $CONFIG->language = $select_language;
                                
				reload_all_translations();
			}
		}
	}
}
function rel_language_selector_get_allowed_translations() {
	
	$configured_allowed = elgg_get_plugin_setting("allowed_languages", "language_selector");
	
	if (empty($configured_allowed)) {
		$allowed = array("en");
		
		$installed_languages = get_installed_translations();
	
		$min_completeness = (int) elgg_get_plugin_setting("min_completeness", "language_selector");
		
		if ($min_completeness > 0) {
			if (elgg_is_active_plugin("translation_editor")) {
				$completeness_function = "translation_editor_get_language_completeness";
			} else {
				$completeness_function = "get_language_completeness";
			}
			
			foreach ($installed_languages as $lang_id => $lang_description) {
	
				if ($lang_id != "en") {
					if (($completeness = $completeness_function($lang_id)) >= $min_completeness) {
						$allowed[] = $lang_id;
					}
				}
			}
		}
		
		elgg_set_plugin_setting("allowed_languages", implode(",", $allowed), "language_selector");
		
	} else {
		$allowed = string_to_tag_array($configured_allowed);
	}

	return $allowed;
}
 function rel_areaOfIntersection($x0, $y0, $r0, $x1, $y1, $r1)
        {
            $rr0 = $r0 * $r0;
            $rr1 = $r1 * $r1;
            $d = sqrt(($x1 - $x0) * ($x1 - $x0) + ($y1 - $y0) * ($y1 - $y0));

            // Circles $do not overlap
            if ($d > $r1 + $r0)
            {
                return 0;
            }

            // Circle1 is completely insi$de circle0
            else if ($d <= abs($r0 - $r1) && $r0 >= $r1)
            {
                // Return area of circle1
                return pi() * $rr1;
            }

            // Circle0 is completely insi$de circle1
            else if ($d <= abs($r0 - $r1) && $r0 < $r1)
            {
                // Return area of circle0
                return pi() * $rr0;
            }

            // Circles partially overlap
            else
                    
            {
                $phi = (acos(($rr0 + ($d * $d) - $rr1) / (2 * $r0 * $d))) * 2;
                $theta = (acos(($rr1 + ($d * $d) - $rr0) / (2 * $r1 * $d))) * 2;
                $area1 = 0.5 * $theta * $rr1 - 0.5 * $rr1 * sin($theta);
                $area2 = 0.5 * $phi * $rr0 - 0.5 * $rr0 * sin($phi);
 
                // Return area of intersection
                return $area1 + $area2;
            }
         
        }

        function rel_intersectionArea($r, $r1, $r2, $r3) {
            $area;
            $triangleArea;
            $segmentArea;
            $c1; $c2; $c3;
            $x12; $x23; $x13; $y12; $y23; $y13;
            $a13; $a23; $b13; $b23;

            $x12 = (($r1 * $r1) - ($r2 * $r2) + ($r * $r)) / (2 * $r);
            $y12 = (sqrt((2 * $r * $r) * (($r1 * $r1) + ($r2 * $r2)) - ((($r1 * $r1) - ($r2 * $r2)) * (($r1 * $r1) - ($r2 * $r2))) - ($r * $r * $r * $r))) / (2 * $r);

            $a13 = (($r1 * $r1) - ($r3 * $r3) + ($r * $r)) / (2 * $r);
            $b13 = (-1) * (sqrt((2 * $r * $r) * (($r1 * $r1) + ($r3 * $r3)) - ((($r1 * $r1) - ($r3 * $r3)) * (($r1 * $r1) - ($r3 * $r3))) - ($r * $r * $r * $r))) / (2 * $r);

            $a23 = (($r2 * $r2) - ($r3 * $r3) + ($r * $r)) / (2 * $r);
            $b23 = (sqrt((2 * $r * $r) * (($r2 * $r2) + ($r3 * $r3)) - ((($r2 * $r2) - ($r3 * $r3)) * (($r2 * $r2) - ($r3 * $r3))) - ($r * $r * $r * $r))) / (2 * $r);

            $x13 = ($a13 / 2) - ((sqrt(3) / 2) * $b13);
            $y13 = ((sqrt(3) / 2) * $a13) + ($b13 / 2);

            $x23 = $r - (($a23 / 2) + ((sqrt(3) / 2) * $b23));
            $y23 = ((sqrt(3) / 2) * $a23) - ($b23 / 2);

            $c1 = sqrt((($x12 - $x13) * ($x12 - $x13)) + (($y12 - $y13) * ($y12 - $y13)));
            $c2 = sqrt((($x12 - $x23) * ($x12 - $x23)) + (($y12 - $y23) * ($y12 - $y23)));
            $c3 = sqrt((($x23 - $x13) * ($x23 - $x13)) + (($y23 - $y13) * ($y23 - $y13)));

            $triangleArea = (sqrt(($c1 + $c2 + $c3) * ($c2 + $c3 - $c1) * ($c1 - $c2 + $c3) * ($c1 + $c2 - $c3))) / 4;
            $segmentArea = ($r1 * $r1 * asin($c1 / (2 * $r1))) - (($c1 / 4) * sqrt((4 * $r1 * $r1) - ($c1 * $c1))) + ($r2 * $r2 * asin($c2 / (2 * $r2))) - (($c2 / 4) * sqrt((4 * $r2 * $r2) - ($c2 * $c2))) + ($r3 * $r3 * asin($c3 / (2 * $r3))) - (($c3 / 4) * sqrt((4 * $r3 * $r3) - ($c3 * $c3)));
            if ($r < ($r1 + $r2) && $r < ($r2 + $r3) && $r < ($r1 + $r3)) {
                $area = ($triangleArea + $segmentArea); // / 3;
                // Division $durch 3 von mir hinzugefügt
                // wieder entfernt, weil s_max ebenfalls von der Funktion ermittelt wird

            } else {
                // alert("One or more circles are not intersecting");
                $area = 0;
            }

            return $area;

        }
       