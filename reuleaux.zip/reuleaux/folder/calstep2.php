<?php
/**
 * Elgg dashboard blurb
 *
 */
?>

<!--<div class="elgg-col elgg-col-2of3">
<?php
//	echo elgg_view('output/longtext', array(
//		'id' => 'dashboard-info',
//		'class' => 'elgg-inner pam mhs mtn',
//		'value' => elgg_echo("dashboard:nowidgets"),
//	));
?>
</div>-->


<?php
// require_once(dirname(dirname(dirname(__FILE__))) . "/mod/audit/vendors/external/tcpdf/tcpdf.php");



$css_url = 'mod/reuleaux/vendors/bootstrap.min.css';
elgg_register_css('bootstrap', $css_url, 500);
elgg_load_css('bootstrap');

$css_url = 'mod/reuleaux/vendors/reuleaux_style.css';
elgg_register_css('reuleaux_style', $css_url, 500);
elgg_load_css('reuleaux_style');

//$css_url = 'mod/reuleaux/vendors/style_IE.css';
//elgg_register_css('style_IE', $css_url, 500);
//elgg_load_css('style_IE');

$css_url = 'mod/reuleaux/vendors/flags.css';
elgg_register_css('flags', $css_url, 500);
elgg_load_css('flags');

$js_url = 'mod/reuleaux/vendors/calculatorstep2.js';
elgg_register_js('calculator', $js_url, 'head', 500);
elgg_load_js('calculator');

$js_url = 'mod/reuleaux/vendors/bootstrap.min.js';
elgg_register_js('bootstrap', $js_url, 'head', 500);
elgg_load_js('bootstrap');

?>
<div class="elgg-page-body">
                <div class="elgg-inner">
                    <div class="elgg-layout elgg-layout-one-column clearfix">
                        <div class="elgg-body elgg-main">
                            <div class="container con-des">
                                <header>
                        <div class="container con-des clearfix">
                            <div class="row">
                                <div class="col-xs-7 header-text" style="color:blue;     margin-right: 0px;   padding-right: 0px;   margin-left: 15px;">
                                    <span class="clsfontsmall"><?php echo elgg_echo('rel_main_label')?></span>
                                    <br>
                                    <span class="bold clsfontsmalltext"><?php echo elgg_echo('rel_main_label_sub')?></span>
                                </div>
                                <div class="col-xs-4">
                                    <img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux-logo.png" alt="logo" class="img-responsive logo groesser">
                                </div>                                             
                            </div>
                        </div>
                                    <!--        $(“#Opt2”).attr(“checked”, true);
$(“#Opt2”).wijradio(“refresh”);-->
                                </header>
                                <div class="container-fluid cf-padding">
                                    <div class="row well well-sm bgbutton panel-padding" data-toggle="buttons">
                                        <div class="col-xs-8 text-right"> 
                                            <button type="button" id="percent" class="btn btn-primary active btn-prozent">Prozent</button>
                                        </div>
                                        <div class="col-xs-4  btn-padding">
                                            <button type="button" id="points" class="btn btn-primary btn-punkte">Punkte</button>
                                        </div>
                                    </div>
                                    <?php
                                    elgg_view('input/securitytoken');
$url = elgg_add_action_tokens_to_url("http://reuleauxcalculator/action/compute");
                                    ?>
                                    <form id="calculator" name="calculator" action="<?php echo $url ?>" enctype="multipart/form-data" method="post" >
                                        <div class="panel panel-default form-box col-md-12">
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-xs-7 wps-padding-top">
                                                        <span class="form-icon"><i class="fa fa-smile-o" aria-hidden="true"></i></span> 
                                                        <span class="wps-form-right-txt bold box-text"> Mensch </span> 
                                                    </div>
                                                    <div class="col-xs-5">
                                                        <input type="text" name="mensch" class="form-control form-input-set">
                                                        <div class="error"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-xs-7 wps-padding-top"> 
                                                        <span class="form-icon"><i class="fa fa-globe" aria-hidden="true"></i></span>
                                                        <span class="wps-form-right-txt bold box-text"> Umwelt</span> 
                                                    </div>                                                     
                                                    <div class="col-xs-5"> 
                                                        <input type="text" name="umwelt" class="form-control form-input-set">
                                                        <div class="error"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel-body"> 
                                                <div class="row">
                                                    <div class="col-xs-7 wps-padding-top"> 
                                                        <span class="form-icon wps-icon"><i class="fa fa-usd" aria-hidden="true"></i></span> 
                                                        <span class="wps-form-right-txt bold box-text form-right-txt"> Wirtschaft</span> 
                                                    </div>                                                     
                                                    <div class="col-xs-5">
                                                        <input type="text" name="wirtschaft" class="form-control form-input-set">
                                                        <div class="error"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class=" col-md-12">
                                                <!--btn btn-block button-->
                                                <input type="hidden" name="was" id="was" value="percent">
                                                <button type="submit" id="check-input"  class="btn btn-block button">BereChnen</button>
                                            </div>
                                        </div>                                         
                                    </form>
                                    <div class="row text">
                                        <h5>Bitte Die erreicten Prozentzahlen eingeben</h5>
                                    </div>
                                    <footer>
                                        <div class="container-fluid  footer-text">
                                            <div class="col-md-4 col-xs-4 footer-drop">
                                                <p> <a style="font-size: 12px;" href="http://reuleaux-calculator.eu/reul/rating-codes.php">Rating-codes</a></p>
                                            </div>
                                            <div class="col-md-4 col-xs-4 footer-drop-center">
                                                <!--<div id="options"  data-input-name="country2" data-selected-country="GB" class="flagstrap">
                                        <select id="flagstrap-7V8EghLo" name="country2" style="display: none;"><option value="">Please select country</option><option value="AU">Australia</option><option value="GB" selected="selected">United Kingdom</option><option value="US">United States</option></select><button type="button" style="margin-left: -14px;" data-toggle="dropdown" id="flagstrap-drop-down-7V8EghLo" class="btn btn-info btn-sm dropdown-toggle" aria-expanded="false"><span class="flagstrap-selected-7V8EghLo"><i class="flagstrap-icon flagstrap-gb" style="margin-right: 10px;"></i>United Kingdom</span><span class="caret" style="margin-left: 10px;"></span></button><ul id="flagstrap-drop-down-7V8EghLo-list" aria-labelled-by="flagstrap-drop-down-7V8EghLo" class="dropdown-menu"><li><a data-val="">Please select country</a></li><li><a data-val="AU"><i class="flagstrap-icon flagstrap-au" style="margin-right: 10px;"></i>Australia</a></li><li><a data-val="GB"><i class="flagstrap-icon flagstrap-gb" style="margin-right: 10px;"></i>United Kingdom</a></li><li><a data-val="US"><i class="flagstrap-icon flagstrap-us" style="margin-right: 10px;"></i>United States</a></li></ul></div>
                    -->
                                                <script type="text/javascript">
			function setLanguage(lang_id) {
				setCookie("client_language", lang_id, 30);
				document.location.href = document.location.href;			
			}
			function setCookie(c_name,value,expiredays) {
				var exdate = new Date();
				exdate.setDate(exdate.getDate() + expiredays);
				document.cookie = c_name + "=" + escape(value) + ";Path=/" + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
			}
		</script>
                                                <div class='language_selector'>
                                                    <a href='javascript:setLanguage("en");' title='Englisch'>
                                                        <img src='http://reuleauxcalculator/mod/language_selector/_graphics/flags/en.gif' alt='Englisch' title='Englisch'>
                                                    </a>                                                                                                                                                             | 
                                                    <img src='http://reuleauxcalculator/mod/language_selector/_graphics/flags/de.gif' alt='Deutsch' title='Deutsch'> | 
                                                    <a href='javascript:setLanguage("es");' title='Spanisch'>
                                                        <img src='http://reuleauxcalculator/mod/language_selector/_graphics/flags/es.gif' alt='Spanisch' title='Spanisch'>
                                                    </a>
                                                </div>                                                 
                                            </div>
                                            <div class="col-md-4 col-xs-4 footer-drop">
                                                <p class="float-right"><a style="font-size: 12px;" href="http://reuleaux-calculator.eu/reul/impressum.php">Impressum</a></p>
                                            </div>
                                        </div>
                                    </footer>
                                </div>                                 
                            </div>
                            <!--<div class="elgg-col elgg-col-2of3">
</div>-->
                        </div>
                    </div>
                </div>
                <div class="elgg-page-footer">
                    <div class="elgg-inner">
                        <ul class="elgg-menu elgg-menu-footer elgg-menu-hz elgg-menu-footer-meta">
                            <li class="elgg-menu-item-powered">
                                <a href="http://elgg.org" title="Elgg 2.3.2" class="elgg-menu-content">Community-Seite erstellt mit Elgg</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>