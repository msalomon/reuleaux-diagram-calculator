$(document).ready(function(){ 
$(".error").hide();
  $(".form-input-set").val('');
	$(".form-input-set").on("keyup", function() {
		var check = $(".form-input-set").filter(function() {
		  return $.trim($(this).val())==='';
		});
		
		if(!check.length) {
		  $("#check-input").attr("disabled", false);
         
		}else {
			$("#check-input").attr("disabled", true);
                         
		}
		
	});
  });
  
  $(document).ready(function(){ 
     
  $(".form-input-set").val('');
	$(".form-input-set").on("keyup", function() { 
	$(".error").hide();
	
	if(!$.isNumeric($(this).val())) {
	   $(this).parent().find(".error").html("only numbers allowed").show();
	   $(this).val('');
	   return;
	}

		var check = $(".form-input-set").filter(function() {
		  return $.trim($(this).val())==='';
		  
		});
		
		if(!check.length) {
		  $("#check-input").attr("disabled", false);
    
		}else {
			$("#check-input").attr("disabled", true);
                        
		}
		
	});
       

  });
  
//  $(document).ready(function () {
//    $('#select_country').attr('data-selected-country','CN');
//    $('#select_country').flagStrap();
//});
//var buttons = $('#buttons button').on('click', function (e) {
//
//    var $this = $(this),
//        el = buttons.not(this),
//        isYes = $this.is('#yes')
//        ;
//
//    $this.removeClass('disabled');
//    $this.addClass('selected');
//    el.addClass('disabled');
//
//});
$('.btn-primary').click(function() {  
    $('.btn-primary').not(this).removeClass('active'); // remove buttonactive from the others
    $(this).toggleClass('active'); // toggle current clicked element
    $("#was").attr("value", $(this).attr('id'));
    alert($(this).attr('id'))
});
