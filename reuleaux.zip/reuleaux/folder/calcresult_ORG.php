<?php

/*
 * reuleaux-diagram calculator 
 * elgg-plugin
 * @purpose transform soziocultur, economy and ecology to sustainability
 * with sustainability metrics that are used in the quality-management system
 * @autor manfred salomon 
 * revision 27.07.2017
 * @link http://reuleaux-calculator.eu
 * 
 */

$site_url = elgg_get_site_url();

$mensch_percent = $vars['mensch'];
$umwelt_percent = $vars['umwelt'];
$wirtschaft_percent = $vars['wirtschaft'];
$menschpunkte = $vars['menschpunkte'];
$umweltpunkte = $vars['umweltpunkte'];
$wirtschaftpunkte = $vars['wirtschaftpunkte'];
$menschmaxpunkte = $vars['menschmaxpunkte'];
$umweltmaxpunkte = $vars['umweltmaxpunkte'];
$wirtschaftmaxpunkte = $vars['wirtschaftmaxpunkte'];
$menschPercent = $vars['mensch'];
$umweltPercent = $vars['umwelt'];
$wirtschaftPercent = $vars['wirtschaft'];
$r_standard = $vars['r_standard'];
$r_human = $vars['r_human'];
$r_environment = $vars['r_environment'];
$r_economic = $vars['r_economic'];
$a_max = $vars['a_max'];
$is_survivable_p_t = $vars['is_survivable_p_t'];
$is_fair_p_t = $vars['is_fair_p_t'];
$is_acceptable_p_t = $vars['is_acceptable_p_t'];
$s_max = $vars['s_max'];
$is_sustainable = $vars['is_sustainable'];
$is_sustainable_p_t = $vars['is_sustainable_p_t'];
$rating_ext = $vars['rating_ext'];


$css_url = 'mod/reuleaux/vendors/bootstrap.min.css';
elgg_register_css('bootstrap', $css_url, 500);
elgg_load_css('bootstrap');

$css_url = 'mod/reuleaux/vendors/reuleaux_style.css';
elgg_register_css('reuleaux_style', $css_url, 500);
elgg_load_css('reuleaux_style');

$css_url = 'mod/reuleaux/vendors/flags.css';
elgg_register_css('flags', $css_url, 500);
elgg_load_css('flags');

$js_url = 'mod/reuleaux/vendors/calculatorresult.js';
elgg_register_js('calculator', $js_url, 'head', 500);
elgg_load_js('calculator');

$js_url = 'mod/reuleaux/vendors/bootstrap.min.js';
elgg_register_js('bootstrap', $js_url, 'head', 500);
elgg_load_js('bootstrap');
$js_url = 'mod/reuleaux/vendors/html2canvas.js';
elgg_register_js('html2canvas', $js_url, 'head', 500);
elgg_load_js('html2canvas');
$js_url = 'mod/reuleaux/vendors/html2canvas.svg.js';
elgg_register_js('html2canvassvg', $js_url, 'head', 500);
elgg_load_js('html2canvassvg');
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<style>


    .dataset {
        float: left;
        vertical-align: top;


    }

    .widget {
        display: inline-block;
        background-color: white;
        font-size: 14px !important;
        line-height: 20px !important;

        margin: 5px;
        vertical-align: top;
        color: #333;

        border-radius: 5px;
        margin: 10px;
        padding-bottom: 20px;
        border: 1px solid lightgray;


        border-radius:5px;
        -webkit-border-radius: 5px;


        display: inline-block;
        page-break-after: always;

    }

    .widget .header p {
        padding: 10px;
        border-bottom: 1px solid lightgrey;
        max-width: 360px;
    }

    .widget .header .title {
        font-weight: bold;
        vertical-align: middle;
        min-height: 36px;
        padding: 5px 10px 5px 10px;

    }

    .widget .header:hover {
        background-color: #f4f4f4;
    }

    .widget .header  .title.selected {
        border-color: cornflowerblue;
        background-color: #EEF;

    }

    .widget .content {
        padding: 5px;
        overflow-y: auto;
        max-height: 400px;
    }

    .autolayout {
        display: inline-block;
    }

    .element {
        width: 360px;
    }

    .compact .content {
        display: table;
        width: 100%;
    }

    .compact .row {
        display: table-row;
        width: 100%;
    }

    .compact .cell {
        display: table-cell;
    }

    .compact .row.selected {
        background-color: #eee;
    }



    .toolbar {
        display: block;
        vertical-align: top;
        margin: 10px;
    }

    .toolbar .basis {
        min-width: 100px;
    }

    .btn {
        /*min-width: 60px;*/
    }


    .cell.value {
        overflow: hidden;
        text-wrap: none;
        white-space: nowrap;
        text-overflow: ellipsis;
        text-align: right;
        padding-right: 10px;
    }

    .cell.freq {
        width: 60px;
    }

    .cell.glyph {
        vertical-align: middle;
        width: 100px;
    }


    .element {

    }
    .element table {
        table-layout: fixed;
        width: 100%;
    }

    .element td {
        padding: 0px;

    }

    .element .selectable:hover {
        background-color: #f4f4f4;
    }


    .element .stat {
        text-align: right;
        padding-right: 20px;
        font-weigth: bold;
        color: darkgray;
    }



    .element .bar {
        height: 18px;
        display: inline-block;
        float: left;
    }
    .bar-both {
        background-color: #0a67a3 !important;

    }

    .bar-fg {
        background-color: #3e97d1 !important;
    }

    .bar-bg {
        background-color: #ddd !important;
    }

    .selected .bar-fg {
        background-color: #FC0;
    }

    .selected .bar-both  {
        background-color:#FA0;
    }

    tr.selected {
        background-color: #eee;
    }

    .crosstab .selectable:hover {
        background-color: #f4f4f4;
    }

    .crosstab tr.selected {
        background-color: #eee;
    }

    .crosstab .header p {
        max-width: 600px;
    }


    .crosstab td {
        padding: 0 5px 0 5px;
        text-align: right;
    }

    .crosstab td.value {
        min-width: 60px;
        max-width: 240px;
        text-align: left;
    }

    .crosstab .cell {
        vertical-align: top;
    }



    .crosstab th.cell {
        max-width: 120px;
        overflow: hidden;
        white-space: normal;
        text-overflow: ellipsis;
        text-align: right;
        padding-right: 10px;
        vertical-align: bottom;
    }

    .crosstab .n {
        color: darkgray;
    }
    .fieldlist {
    }

    .constraints {
        min-width:300px;
        padding: 10px;

        border-radius:5px;
        -webkit-border-radius: 5px;


    }
    .constraints table {
        width: 100%;

    }

    .sidenote {
        max-width:300px;
        padding: 0 10px 0px 10px;
        display: inline-block;
        vertical-align: top;
    }

    .headnote {
        max-width: 600px;
        padding: 10px;
        margin: 10px;
        display: inline-block;
    }

    .info-block {
        /*border: 1px solid lightgrey;*/
        background-color: #eee;
        vertical-align: top;
        margin: 10px;
        padding: 10px;
        display: block;

        /*box-shadow: 0 0 0 0px #9bc0cf, 0 0 0 3px #e0ebf0;*/
    }

    .menu-item {
    }

    .menu-item-value {
        text-align: right;
        float: right;
    }

    .gradient-blue {
        background: #b8e1fc; /* Old browsers */
        /* IE9 SVG, needs conditional override of 'filter' to 'none' */
        background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPGxpbmVhckdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIwJSIgeTI9IjEwMCUiPgogICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iI2I4ZTFmYyIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjEwJSIgc3RvcC1jb2xvcj0iI2E5ZDJmMyIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjI1JSIgc3RvcC1jb2xvcj0iIzkwYmFlNCIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjM3JSIgc3RvcC1jb2xvcj0iIzkwYmNlYSIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjUwJSIgc3RvcC1jb2xvcj0iIzkwYmZmMCIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjUxJSIgc3RvcC1jb2xvcj0iIzZiYThlNSIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjgzJSIgc3RvcC1jb2xvcj0iI2EyZGFmNSIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNiZGYzZmQiIHN0b3Atb3BhY2l0eT0iMSIvPgogIDwvbGluZWFyR3JhZGllbnQ+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
        background: -moz-linear-gradient(top, #b8e1fc 0%, #a9d2f3 10%, #90bae4 25%, #90bcea 37%, #90bff0 50%, #6ba8e5 51%, #a2daf5 83%, #bdf3fd 100%); /* FF3.6+ */
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #b8e1fc), color-stop(10%, #a9d2f3), color-stop(25%, #90bae4), color-stop(37%, #90bcea), color-stop(50%, #90bff0), color-stop(51%, #6ba8e5), color-stop(83%, #a2daf5), color-stop(100%, #bdf3fd)); /* Chrome,Safari4+ */
        background: -webkit-linear-gradient(top, #b8e1fc 0%, #a9d2f3 10%, #90bae4 25%, #90bcea 37%, #90bff0 50%, #6ba8e5 51%, #a2daf5 83%, #bdf3fd 100%); /* Chrome10+,Safari5.1+ */
        background: -o-linear-gradient(top, #b8e1fc 0%, #a9d2f3 10%, #90bae4 25%, #90bcea 37%, #90bff0 50%, #6ba8e5 51%, #a2daf5 83%, #bdf3fd 100%); /* Opera 11.10+ */
        background: -ms-linear-gradient(top, #b8e1fc 0%, #a9d2f3 10%, #90bae4 25%, #90bcea 37%, #90bff0 50%, #6ba8e5 51%, #a2daf5 83%, #bdf3fd 100%); /* IE10+ */
        background: linear-gradient(to bottom, #b8e1fc 0%, #a9d2f3 10%, #90bae4 25%, #90bcea 37%, #90bff0 50%, #6ba8e5 51%, #a2daf5 83%, #bdf3fd 100%); /* W3C */
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#b8e1fc', endColorstr='#bdf3fd', GradientType=0); /* IE6-8 */
    }
</style>
<script id="scriptInit" type="text/javascript">

        $(document).ready(function () {

            is_paper_canvas = false;
            sustainable_correct = 0;
            mensch_percent = <?php echo $mensch_percent ?>;
            umwelt_percent = <?php echo $umwelt_percent ?>;
            economy_percent = <?php echo $wirtschaft_percent ?>;
            r_standard = <?php echo $r_standard ?>;
            r_human = <?php echo $r_human ?>;
            r_environment = <?php echo $r_environment ?>;
            r_economic = <?php echo $r_economic ?>;
//                                                                                      // alert(p_standard);
//                                                                                      // alert(f_standard);
            // e. g. 50% Fläche = 21125.919999999995 entsprechen 82.02438661763951 Radius
            $(".txt_human").text($(".txt_human").text() + ' (' + mensch_percent + '%)');

            $(".txt_environment").text($(".txt_environment").text() + ' (' + umwelt_percent + '%)');

            $(".txt_economy").text($(".txt_economy").text() + ' (' + economy_percent + '%)');

            if (is_paper_canvas === false) {

                paper = Raphael("derp", r_standard + 5, r_standard + 5); // for testing delete  5
                paper2 = Raphael("derp2", r_standard + 5, r_standard + 5); // for testing delete  5
                is_paper_canvas = true;
            }
            //      paper.clear();
            // Zeichne Kreis mit X-Radius an Postion Gleichseitiges Dreieck 
            var circle = paper.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
            var circle2 = paper.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
            var circle3 = paper.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2
            var circlex = paper2.circle((r_standard / 3), r_standard - r_standard / 3, r_economic / 3);     // rot        ^
            var circlex2 = paper2.circle(r_standard - (r_standard / 3), r_standard - (r_standard / 3), r_environment / 3);   // blau
            var circlex3 = paper2.circle((r_standard / 3) + (r_standard / 3) / 2, (((Math.sqrt(3) / 2) * r_standard)) - (r_standard / 2), r_human / 3); //gelb //(r_standard-/3))/2


            r_116 = 116;                                                                        // 
            // Schnittflächen 100%
            a_max = <?php echo $a_max ?>;


            is_survivable_p_t = <?php echo $is_survivable_p_t ?>;
            $(".gauge3-text").text($(".gauge3-text").text() + ' (' + is_survivable_p_t + '%)');


            is_fair_p_t = <?php echo $is_fair_p_t ?>;
            $(".gauge4-text").text($(".gauge4-text").text() + ' (' + is_fair_p_t + '%)');

            is_acceptable_p_t = <?php echo $is_acceptable_p_t ?>;
            $(".gauge2-text").text($(".gauge2-text").text() + ' (' + is_acceptable_p_t + '%)');

            s_max = <?php echo $s_max ?>;
            is_sustainable = <?php echo $is_sustainable ?>;

            $(".total_percentage").text(<?php echo $is_sustainable_p_t ?> + '%');
            $(".gauge1-text").text($(".gauge1-text").text() + ' (' + <?php echo $is_sustainable_p_t ?> + '%)');

            var rating_ext = <?php echo $rating_ext ?>;
//            // alert(rating_ext);
            rating_ext = rating_ext.toFixed(0);
//            // alert(rating_ext);
            rating_ext = rating_ext.toString();
            ratingcode_content(rating_ext);
            $(".ratingcode_img").attr('src', '<?php echo $site_url ?>' + 'mod/reuleaux/images/codes/' + rating_ext + '.jpg')
            circle.attr("fill", "#FF3A3A");
            circle.attr("stroke", "#ffffff");
            circle.animate({"fill-opacity": .8}, 600);

            circle3.attr("fill", "#FFCE8C");
            circle3.animate({"fill-opacity": .5}, 600);
            circle3.attr("stroke", "#ffffff");

            // Sets the fill attribute of the circle to red (#f00)
            circle2.attr("fill", "#68C2FF");
            circle2.animate({"fill-opacity": .6}, 600);
            //Sets the stroke attribute of the circle to white
            circle2.attr("stroke", "#ffffff");
            is_paper_canvas = true;

            circle.attr("fill", "#FF3A3A");
            circle.attr("stroke", "#ffffff");
            circle.animate({"fill-opacity": .8}, 600);

            circle3.attr("fill", "#FFCE8C");
            circle3.animate({"fill-opacity": .5}, 600);
            circle3.attr("stroke", "#ffffff");

            // Sets the fill attribute of the circle to red (#f00)
            circle2.attr("fill", "#68C2FF");
            circle2.animate({"fill-opacity": .6}, 600);
            //Sets the stroke attribute of the circle to white
            circle2.attr("stroke", "#ffffff");


            circlex.attr("fill", "#FF3A3A");
            circlex.attr("stroke", "#999999");
            circlex.animate({"fill-opacity": .8}, 600);

            circlex3.attr("fill", "#FFCE8C");
            circlex3.animate({"fill-opacity": .5}, 600);
            circlex3.attr("stroke", "#999999");

            // Sets the fill attribute of the circle to red (#f00)
            circlex2.attr("fill", "#68C2FF");
            circlex2.animate({"fill-opacity": .6}, 600);
            //Sets the stroke attribute of the circle to white
            circlex2.attr("stroke", "#999999");

            function ratingcode_content(code) {
                switch (code) {
                    case '22':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_22'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_22'); ?>');
                        break;
                    case '21':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_21'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_21'); ?>');
                        break;
                    case '20':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_20'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_20'); ?>');
                        break;
                    case '19':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_19'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_19'); ?>');
                        break;
                    case '18':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_18'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_18'); ?>');
                        break;
                    case '17':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_17'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_17'); ?>');
                        break;
                    case '16':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_16'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_16'); ?>');
                        break;
                    case '15':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_15'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_15'); ?>');
                        break;
                    case '14':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_14'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_14'); ?>');
                        break;
                    case '13':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_13'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_13'); ?>');
                        break;
                    case '12':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_12'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_12'); ?>');
                        break;
                    case '11':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_11'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_11'); ?>');
                        break;
                    case '10':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_10'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_10'); ?>');
                        break;
                    case '9':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_9'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_9'); ?>');
                        break;
                    case '8':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_8'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_8'); ?>');
                        break;
                    case '7':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_7'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_7'); ?>');
                        break;
                    case '6':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_6'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_6'); ?>');
                        break;
                    case '5':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_5'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_5'); ?>');
                        break;
                    case '4':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_4'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_4'); ?>');
                        break;
                    case '3':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_3'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_3'); ?>');
                        break;
                    case '2':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_2'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_2'); ?>');
                        break;
                    case '1':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_1'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_1'); ?>');
                        break;
                    case '0':
                        $(".txt_rated").text('<?php echo elgg_echo('rel_rated_1'); ?>');
                        $(".txt_bonitaet").text('<?php echo elgg_echo('rel_bonitaet_1'); ?>');
                        break;
                }
            }


            function setLanguage(lang_id) {
                setCookie("client_language", lang_id, 30);
                document.location.href = document.location.href;
            }
            // Cookie to remember language
            function setCookie(c_name, value, expiredays) {
                var exdate = new Date();
                exdate.setDate(exdate.getDate() + expiredays);
                document.cookie = c_name + "=" + escape(value) + ";Path=/" + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
            }
        });

        $(function () {
            $("#check-input").click(function () {
                    $("#img-in").show();
                html2canvas($("#img-in"), {
                    onrendered: function (canvas) {
                        theCanvas = canvas;
                        document.body.appendChild(canvas);

                        // Convert and download as image 
//                windows.Canvas2Image.saveAsPNG(canvas); 
                        $("#img-out").append(canvas);
                        $("#img-out").show();
                        $('body').css('background-image', 'url(../images/white.png)');
$("#img-in").hide();
$("#Calc").hide();
      $("#go-back").show();
                        // Clean up 
                        //document.body.removeChild(canvas);
                    }
                });
            });
                                  
                              
        });
                $(function () {
            $("#go-back").click(function () {
                   


                    $("#img-out").hide();
                    $("#Calc").show();
                    $('body').css('background-image', 'url(' + '<?php echo $site_url ?>' + 'mod/reuleaux/images/phone.png)');
      $("#go-back").hide();
            });
                                  
                              
        });
</script>



<div id="Calc" class="elgg-page-body">


    <div class="elgg-inner">
        <div class="elgg-layout elgg-layout-one-column clearfix">
            <div class="elgg-body elgg-main">
                <div class="container con-des">
                    <header>
                        <div class="container con-des clearfix">
                            <div class="row">
                                <div class="col-xs-7 header-text" style="color:blue;     margin-right: 0px;   padding-right: 0px;   margin-left: 15px;">
                                    <span class="clsfontsmall"><?php echo elgg_echo('rel_main_label') ?></span>
                                    <br>
                                    <span class="bold clsfontsmalltext"><?php echo elgg_echo('rel_main_label_sub') ?></span>
                                </div>
                                <div class="col-xs-4">
                                    <img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux-logo.png" alt="logo" class="img-responsive logo groesser">
                                </div>                                             
                            </div>
                        </div>
                        <!--        $(“#Opt2”).attr(“checked”, true);
$(“#Opt2”).wijradio(“refresh”);-->
                    </header>
                    <div class="container-fluid cf-padding">

                        <div class="row well well-sm bgbutton panel-padding" data-toggle="buttons">
                            <div class="col-xs-8 "> 
                                <span class="clsfontsmall" style="color: #6168AE;"><strong><?php echo elgg_echo('rel_main_label_result') ?></strong></span>
                                <!--<button type="button" class="btn btn-primary active btn-prozent">Prozent</button>-->
                            </div>                            

                            <div class="col-xs-4 btn-padding">
                                <button type="button" class="btn btn-primary btn-punkte"><?php echo elgg_echo('rel_btn_new') ?></button>
                            </div>
                        </div>
                     
                            <div class="panel panel-default  col-md-12">

                                <div class="panel-body panel-design ">
                                    <span class="text-s3-rating" style="color: #3a6cac;"><?php echo elgg_echo('rel_sustainability_sub') ?>:&nbsp;<span class="total_percentage" style="color: #3a6cac;font-weight: bold">0.0%</span></span>
                                    <span class="space-text-s3-rating" ><?php echo elgg_echo('rel_rating') ?>:&nbsp;<img id="ratingcode_img" src="<?php echo $site_url ?>mod/reuleaux/images/codes/2.jpg" class="img-size rating_image this_hide_cls ratingcode_img" ></span><br>


                                    <div class="row">
                                        <div class="col-sm-5 col-xs-5">

                                            <div  style=" margin-top:8px; margin-left:0px; padding: 0;   " id="derp"></div>

                                        </div>






                                        <div class='elgg-col elgg-col-3of5' style=' float: left;

                                             width: 54%;

                                             margin-top: 8px;

                                             margin-left: 0px;' >        

                                            <table

                                                style="margin-top:25px; margin-left: 19px; text-align: left; width: 100%;" border="1"

                                                cellpadding="2" cellspacing="2">

                                                <!--                    Linear gauge funktionierte einwandfrei, rausgenommen weil die prozentzahl wichtiger
                                                                        <tbody>
                                                
                                                
                                                
                                                                        <tr>
                                                
                                                                            <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge2' class='ui-corner-all'></div><div id="gauge2-text"   style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_acceptable") ?></div></td>
                                                
                                                                        </tr>
                                                
                                                                        <tr>
                                                
                                                                            <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge3' class='ui-corner-all'></div><div id="gauge3-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_survivable") ?></div></td>
                                                
                                                                        </tr>
                                                
                                                                        <tr>
                                                
                                                                            <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge4' class='ui-corner-all'></div><div id="gauge4-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_fair") ?></div></td>
                                                
                                                                        </tr>
                                                
                                                                                                <tr>
                                                
                                                                            <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge1' class='ui-corner-all'></div><div id="gauge1-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_sustainability") ?></div></td>
                                                
                                                                        </tr>
                                                
                                                                    </tbody>-->
                                                <tbody>
                                                    <!--Gauge ohne Balken z. B. gauge2_OB-->



                                                    <tr>

                                                        <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge2_OB_text' class='resultfont gauge2_OB_text'></div><div class="gauge2-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_acceptable") ?><div class="resultfont" class="is_acceptable"></div></div></td>

                                                    </tr>

                                                    <tr>

                                                        <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge3_OB_text' class='resultfont gauge3_OB_text'></div><div class="gauge3-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_survivable") ?><div class="resultfont" class="is_survivable"></div></div></td>

                                                    </tr>

                                                    <tr>

                                                        <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge4_OB_text' class='resultfont gauge4_OB_text'></div><div class="gauge4-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_fair") ?><div class="resultfont" class="is_fair"></div></td>

                                                    </tr>

                                                    <tr>

                                                        <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge1_OB_text' class='resultfont gauge4_OB_text'></div><div class="gauge1-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_sustainability") ?><div class="resultfont" class="is_sustainable"></div></div></td>

                                                    </tr>


                                                </tbody>
                                            </table>

                                        </div> 
                                        <div class='row' style="padding-left:15px">
                                            <div class="col-xs-12" style="margin-top: -6px" ></div>
                                            <div class="col-xs-4"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/human.jpg' title='<?php elgg_echo("rel_human") ?>'><span id="txt_human"><?php echo elgg_echo("rel_human") ?></span></div>
                                            <div class="col-xs-5" style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-left: -10px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/environment.jpg' title='<?php elgg_echo("rel_economy") ?>'><span id="txt_economy"><?php echo elgg_echo("rel_economy") ?></span></div>
                                            <div class="col-xs-4" style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-left: -30px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/economy.jpg' title='<?php elgg_echo("rel_environment") ?>'><span id="txt_environment"><?php echo elgg_echo("rel_environment") ?></span></div>
                                        </div>
                                        <div class="row" style="padding-left:15px; margin-top: -2px">
                                            <div class="col-xs-12"></div>
                                            <div class="col-xs-4" style="font-size:10px;     margin-left: -12px;     color: #6168AE; padding-right: 0px; margin-right: -2px;"><img  style='width:0px; height:0px ; margin-right: 4px;  margin-left: 7px; border:0px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_human") ?>'><span id="txt_human_p"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschpunkte, 1) ?> - <?php echo round($menschPercent, 1) ?>%</span></div>
                                            <div class="col-xs-5" style="font-size:10px;     color: #6168AE; padding-right: 0px; margin-left: -10px;"><img  style='width:0px; height:0px ; margin-right: 4px;  margin-left: 7px;  border:0px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_economy") ?>'><span id="txt_human_p"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($umweltpunkte, 1) ?> - <?php echo round($umweltPercent, 1) ?>%</span></div>
                                            <div class="col-xs-4"  style="font-size:10px;     color: #6168AE; padding-right: 0px; margin-left: -30px;"><img  style='width:0px; height:0px ; margin-right: 4px; margin-left: 7px;   border:0px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_environment") ?>'><span id="txt_human_p"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($wirtschaftpunkte, 1) ?> - <?php echo round($wirtschaftPercent, 1) ?>%</span></div>
                                        </div>   
                                        <div class='row' style="padding-left:15px; margin-top: 5px">
                                            <div class="col-xs-11" ></div>
                                            <div class="col-xs-11"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px; line-height: 11px;   margin-bottom: 2px;"><span class="txt_rated"><?php echo elgg_echo("rel_rated_2") ?></span></div>
                                            <div class="col-xs-11"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px; line-height: 11px;   margin-bottom: 6px;"><span class="txt_bonitaet"><?php echo elgg_echo("rel_bonitaet_2") ?></span></div>

                                        </div>                                                            

                                    </div>


                                </div></div>
                            <div class="row" >
                                <div class=" col-md-12" >
                                    <button type="button" id="check-input" class="btn btn-block button-step-3" style="    top: -10px;">Snapshot</button>
                                </div>
                            </div>                                         
                       
                        <!--                                    <div class="row text">
                                                                <h5>Benutze Snapshot für deine Dokumentation</h5>
                                                            </div>-->
                        <footer>
                            <div class="container-fluid  footer-text">
                                <div class="col-md-4 col-xs-4 footer-drop">
                                    <p> <a style="font-size: 12px;" href="http://reuleaux-calculator.eu/reul/rating-codes.php">Rating-codes</a></p>
                                </div>
                                <div class="col-md-4 col-xs-4 footer-drop-center">
                                    <!--<div id="options"  data-input-name="country2" data-selected-country="GB" class="flagstrap">
                            <select id="flagstrap-7V8EghLo" name="country2" style="display: none;"><option value="">Please select country</option><option value="AU">Australia</option><option value="GB" selected="selected">United Kingdom</option><option value="US">United States</option></select><button type="button" style="margin-left: -14px;" data-toggle="dropdown" id="flagstrap-drop-down-7V8EghLo" class="btn btn-info btn-sm dropdown-toggle" aria-expanded="false"><span class="flagstrap-selected-7V8EghLo"><i class="flagstrap-icon flagstrap-gb" style="margin-right: 10px;"></i>United Kingdom</span><span class="caret" style="margin-left: 10px;"></span></button><ul id="flagstrap-drop-down-7V8EghLo-list" aria-labelled-by="flagstrap-drop-down-7V8EghLo" class="dropdown-menu"><li><a data-val="">Please select country</a></li><li><a data-val="AU"><i class="flagstrap-icon flagstrap-au" style="margin-right: 10px;"></i>Australia</a></li><li><a data-val="GB"><i class="flagstrap-icon flagstrap-gb" style="margin-right: 10px;"></i>United Kingdom</a></li><li><a data-val="US"><i class="flagstrap-icon flagstrap-us" style="margin-right: 10px;"></i>United States</a></li></ul></div>
                                    -->
                                    <?php echo elgg_view('language_selector/default'); ?>
                                    <!--                                    <div class='language_selector'>
                                                                            <a href='javascript:setLanguage("en");' title='Englisch'>
                                                                                <img src='http://reuleauxcalculator/mod/language_selector/_graphics/flags/en.gif' alt='Englisch' title='Englisch'>
                                                                            </a>                                                                                                                                                             | 
                                                                            <img src='http://reuleauxcalculator/mod/language_selector/_graphics/flags/de.gif' alt='Deutsch' title='Deutsch'> | 
                                                                            <a href='javascript:setLanguage("es");' title='Spanisch'>
                                                                                <img src='http://reuleauxcalculator/mod/language_selector/_graphics/flags/es.gif' alt='Spanisch' title='Spanisch'>
                                                                            </a>
                                                                        </div>                                                 -->
                                </div>
                                <div class="col-md-4 col-xs-4 footer-drop">
                                    <p class="float-right"><a style="font-size: 12px;" href="http://reuleaux-calculator.eu/reul/impressum.php">Impressum</a></p>
                                </div>
                            </div>
                        </footer>
                    </div>                                 
                </div>

            </div>
        </div>
    </div>

</div>


<div id="img-in" style='display:none'  >
    <div id="widget1" class="elgg-page-body">
        <!--Anfang Clip-->
        <div class="elgg-inner">
            <div class="elgg-layout elgg-layout-one-column clearfix">
                <div class="elgg-body elgg-main">
                    
                                        <div class="container con-des" >

                        <div class="divTable" style="border: 1px solid #000;" >
                            <div class="divTableBody">
                                <div class="divTableRow">
                                    <div class="divTableCell" ><?php echo elgg_echo('rel_sustainability_sub') ?></div>
                                    <div class="divTableCell" ><span class="total_percentage" style="color: black;font-weight: normal">0.0%</span></div>
                                    <div class="divTableCell"><?php echo elgg_echo('rel_rating') ?></div>
                                    <div class="divTableCell"><img class="ratingcode_img" style="height:20px; width:30px" src="<?php echo $site_url ?>mod/reuleaux/images/codes/2.jpg" class="img-size rating_image this_hide_cls" ></div>
                                </div></div></div>  



                        <div class="divTable" style="border: 1px solid #000;margin-top:-2px" >
                            <div class="divTableBody">
                                <div class="divTableRow">
                                    <div class="divTableCell"><span class="txt_bonitaet"></span></div>
                                </div></div></div>   
                        <div class="divTable" style="border: 1px solid #000;margin-top:-2px" >
                            <div class="divTableBody">
                                <div class="divTableRow">
                                    <div class="divTableCell"><span style="font-size:11px" class="txt_rated"></span></div>
                                </div></div></div>  

                        <div class="divTable" style="border: 1px solid #000;margin-top:-2px" >
                            <div class="divTableBody">
                                <div class="divTableRow" >

                                    <div class="divTableCell" style="width:auto"><div  style=" width:118px; margin-top:0px; margin-left:-1px; padding: 0;z-index: 7  " id="derp2">
                                            <div style=" margin-top:0px; margin-left:1px;">

                                                <div id ="a_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -94px;margin-left: 47px;width: 19px;text-align: center; z-index: 700000;">A</div>

                                                <div id ="b_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top:27px;margin-left: 77px;width: 19px;text-align: left;">C</div>

                                                <div id ="c_circle" style="color: navy;font-weight: normal;font-size: 10px;margin-top: -14px;margin-left: 28px;width: 19px;text-align: left;">B</div> 



                                            </div>
                                        </div></div>











                                    <div class="divTableCell " style="float:left;width:100%; height:32px"><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div class="gauge2-text" style="font-size: 11px;display: inline;" ></div></div>
                                    <div class="divTableCell " style="float:left;width:100%; height:31px"><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_survivable") ?>'><div class="gauge3-text" style="font-size: 11px;display: inline;" ></div></div>
                                    <div class="divTableCell " style="float:left;width:100%; height:32px"><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_fair") ?>'><div class="gauge4-text" style="font-size: 11px;display: inline;" ></div></div>
                                    <div class="divTableCell " style="float:left;width:100%; height:31px"><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_sustainability") ?>'><div class="gauge1-text" style="font-size: 11px;display: inline;" ></div></div>



                                </div></div></div>

                        <div class="divTable" style="border: 1px solid #000;margin-top:-2px" >
                            <div class="divTableBody">
                                <div class="divTableRow">
                                    <div class="divTableCell" style="width:30%; padding-left:4px; padding-right: 2px"><span  style="font-size: 10px;display: inline;">A: <?php echo elgg_echo("rel_human") ?> (<?php echo round($menschPercent, 1) ?>%)</span></div>
                                    <div class="divTableCell" style="width:30%; padding-left:4px; padding-right: 2px"><span  style="font-size: 10px;display: inline;">B: <?php echo elgg_echo("rel_economy") ?> (<?php echo round($umweltPercent, 1) ?>%)</span></div>                       
                                    <div class="divTableCell" style="width:30%; padding-left:4px; padding-right: 2px"><span  style="font-size: 10px;display: inline;">C: <?php echo elgg_echo("rel_environment") ?> (<?php echo round($wirtschaftPercent, 1) ?>%)</span></div>
                                </div></div></div>
                        <div class="divTable" style="border: 1px solid #000;margin-top:-2px" >
                            <div class="divTableBody">
                                <div class="divTableRow">
                                    <div class="divTableCell" style="width:30%; padding-left:4px; padding-right: 2px"><span  style="font-size: 10px;display: inline;">A: <?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                                    <div class="divTableCell" style="width:30%; padding-left:4px; padding-right: 2px"><span  style="font-size: 10px;display: inline;">B: <?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($umweltpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>                       
                                    <div class="divTableCell" style="width:30%; padding-left:4px; padding-right: 2px"><span  style="font-size: 10px;display: inline;">C: <?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($wirtschaftpunkte, 1) ?> <?php echo elgg_echo('rel_btn_points') ?></span></div>
                                </div></div></div>
                    </div>                 
<!--Ende Clipp-->                                
                    <div class="col-md-12 text-center"><?php echo elgg_echo('rel_clipp'); ?></div>
                                        
                    <!--Anfang Clip-->
                    <div class="container con-des">

                        <div class="container-fluid cf-padding boder-padding">

                         
                                <div class="panel panel-default  col-md-12">
                                    <div class="panel-design-border">
                                        <div class="panel-body panel-design ">


                                            <div class="row">
                                                <div class="col-sm-5 col-xs-5">

                                                    <div  style=" margin-top:8px; margin-left:0px; padding: 0;   " id="derp"></div>

                                                </div>






                                                <div class='elgg-col elgg-col-3of5' style=' float: left;

                                                     width: 54%;

                                                     margin-top: 8px;

                                                     margin-left: 0px;' >        

                                                    <table

                                                        style="margin-top:25px; margin-left: 19px; text-align: left; width: 100%;" border="1"

                                                        cellpadding="2" cellspacing="2">

                                                        <!--                    Linear gauge funktionierte einwandfrei, rausgenommen weil die prozentzahl wichtiger
                                                                                <tbody>
                                                        
                                                        
                                                        
                                                                                <tr>
                                                        
                                                                                    <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge2' class='ui-corner-all'></div><div id="gauge2-text"   style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_acceptable") ?></div></td>
                                                        
                                                                                </tr>
                                                        
                                                                                <tr>
                                                        
                                                                                    <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge3' class='ui-corner-all'></div><div id="gauge3-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_survivable") ?></div></td>
                                                        
                                                                                </tr>
                                                        
                                                                                <tr>
                                                        
                                                                                    <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge4' class='ui-corner-all'></div><div id="gauge4-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_fair") ?></div></td>
                                                        
                                                                                </tr>
                                                        
                                                                                                        <tr>
                                                        
                                                                                    <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge1' class='ui-corner-all'></div><div id="gauge1-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_sustainability") ?></div></td>
                                                        
                                                                                </tr>
                                                        
                                                                            </tbody>-->
                                                        <tbody>
                                                            <!--Gauge ohne Balken z. B. gauge2_OB-->



                                                            <tr>

                                                                <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge2_OB_text' class='resultfont'></div><div id="gauge2-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_acceptable") ?><div class="resultfont" id="is_acceptable"></div></div></td>

                                                            </tr>

                                                            <tr>

                                                                <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge3_OB_text' class='resultfont'></div><div id="gauge3-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_survivable") ?><div class="resultfont" id="is_survivable"></div></div></td>

                                                            </tr>

                                                            <tr>

                                                                <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge4_OB_text' class='resultfont'></div><div id="gauge4-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_fair") ?><div class="resultfont" id="is_fair"></div></td>

                                                            </tr>

                                                            <tr>

                                                                <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge1_OB_text' class='resultfont'></div><div id="gauge1-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_sustainability") ?><div class="resultfont" id="is_sustainable"></div></td>

                                                            </tr>


                                                        </tbody>
                                                    </table>

                                                </div> 
                                                <div class='row' style="padding-left:15px">
                                                    <div class="col-xs-12" style="margin-top: -6px" ></div>
                                                    <div class="col-xs-4"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/human.jpg' title='<?php elgg_echo("rel_human") ?>'><span id="txt_human"><?php echo elgg_echo("rel_human") ?></span></div>
                                                    <div class="col-xs-5" style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-left: -10px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/environment.jpg' title='<?php elgg_echo("rel_economy") ?>'><span id="txt_economy"><?php echo elgg_echo("rel_economy") ?></span></div>
                                                    <div class="col-xs-4" style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-left: -30px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/economy.jpg' title='<?php elgg_echo("rel_environment") ?>'><span id="txt_environment"><?php echo elgg_echo("rel_environment") ?></span></div>
                                                </div>


                                            </div>

                                            <hr class="styleblue"></hr><div class="stylebluedisclaimer"><?php echo elgg_echo('rel_calculated_by') ?></div>
                                        </div>  </div>

                                </div>

                                <!--                                    <div class="row text">
                                                                        <h5>Benutze Snapshot für deine Dokumentation</h5>
                                                                    </div>-->

                        </div></div> 
<!--Clipp-->                                
                    <div class="col-md-12 text-center"><?php echo elgg_echo('rel_clipp1'); ?></div>






                    <div class="container con-des" >

                        <div class="container-fluid cf-padding boder-padding" >

                            <div class="panel panel-default  col-md-12" >
                                <div class="panel-design-white-border">
                                    <div class="panel-body panel-design " style="background-color: white;">


                                        <div class="row">
                                            <div class="col-sm-5 col-xs-5">

                                                <div  style=" margin-top:8px; margin-left:0px; padding: 0;   " id="derp"></div>

                                            </div>






                                            <div class='elgg-col elgg-col-3of5' style=' float: left;

                                                 width: 54%;

                                                 margin-top: 8px;

                                                 margin-left: 0px;' >        

                                                <table

                                                    style="margin-top:25px; margin-left: 19px; text-align: left; width: 100%;" border="1"

                                                    cellpadding="2" cellspacing="2">

                                                    <!--                    Linear gauge funktionierte einwandfrei, rausgenommen weil die prozentzahl wichtiger
                                                                            <tbody>
                                                    
                                                    
                                                    
                                                                            <tr>
                                                    
                                                                                <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge2' class='ui-corner-all'></div><div id="gauge2-text"   style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_acceptable") ?></div></td>
                                                    
                                                                            </tr>
                                                    
                                                                            <tr>
                                                    
                                                                                <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge3' class='ui-corner-all'></div><div id="gauge3-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_survivable") ?></div></td>
                                                    
                                                                            </tr>
                                                    
                                                                            <tr>
                                                    
                                                                                <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge4' class='ui-corner-all'></div><div id="gauge4-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_fair") ?></div></td>
                                                    
                                                                            </tr>
                                                    
                                                                                                    <tr>
                                                    
                                                                                <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge1' class='ui-corner-all'></div><div id="gauge1-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_sustainability") ?></div></td>
                                                    
                                                                            </tr>
                                                    
                                                                        </tbody>-->
                                                    <tbody>
                                                        <!--Gauge ohne Balken z. B. gauge2_OB-->



                                                        <tr>

                                                            <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge2_OB_text' class='resultfont'></div><div id="gauge2-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_acceptable") ?><div class="resultfont" id="is_acceptable"></div></div></td>

                                                        </tr>

                                                        <tr>

                                                            <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge3_OB_text' class='resultfont'></div><div id="gauge3-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_survivable") ?><div class="resultfont" id="is_survivable"></div></div></td>

                                                        </tr>

                                                        <tr>

                                                            <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge4_OB_text' class='resultfont'></div><div id="gauge4-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_fair") ?><div class="resultfont" id="is_fair"></div></td>

                                                        </tr>

                                                        <tr>

                                                            <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge1_OB_text' class='resultfont'></div><div id="gauge1-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_sustainability") ?><div class="resultfont" id="is_sustainable"></div></td>

                                                        </tr>


                                                    </tbody>
                                                </table>

                                            </div> 
                                            <div class='row' style="padding-left:15px">
                                                <div class="col-xs-12" style="margin-top: -6px" ></div>
                                                <div class="col-xs-4"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/human.jpg' title='<?php elgg_echo("rel_human") ?>'><span id="txt_human"><?php echo elgg_echo("rel_human") ?></span></div>
                                                <div class="col-xs-5" style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-left: -10px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/environment.jpg' title='<?php elgg_echo("rel_economy") ?>'><span id="txt_economy"><?php echo elgg_echo("rel_economy") ?></span></div>
                                                <div class="col-xs-4" style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-left: -30px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/economy.jpg' title='<?php elgg_echo("rel_environment") ?>'><span id="txt_environment"><?php echo elgg_echo("rel_environment") ?></span></div>
                                            </div>


                                        </div>

                                        <hr class="styleblue"></hr><div class="stylebluedisclaimer"><?php echo elgg_echo('rel_calculated_by') ?></div>
                                    </div>  </div>

                            </div>

                            <!--                                    <div class="row text">
                                                                    <h5>Benutze Snapshot für deine Dokumentation</h5>
                                                                </div>-->

                        </div></div> 
                    <!--Ende Clip-->
                    Ohne Rating

                    <!--Anfang Clip-->
                    <div class="container con-des">

                        <div class="container-fluid cf-padding boder-padding">

                           
                                <div class="panel panel-default  col-md-12">
                                    <div class="panel-design-border">
                                        <div class="panel-body panel-design ">
                                            <span class="text-s3-rating" style="color: #3a6cac;"><?php echo elgg_echo('rel_sustainability_sub') ?>:&nbsp;<span class="total_percentage" style="color: #3a6cac;font-weight: bold">0.0%</span></span>
                                            <span class="space-text-s3-rating" ><?php echo elgg_echo('rel_rating') ?>:&nbsp;<img id="ratingcode_img" src="<?php echo $site_url ?>mod/reuleaux/images/codes/2.jpg" class="img-size rating_image this_hide_cls" ></span><br>


                                            <div class="row">
                                                <div class="col-sm-5 col-xs-5">

                                                    <div  style=" margin-top:8px; margin-left:0px; padding: 0;   " id="derp"></div>

                                                </div>






                                                <div class='elgg-col elgg-col-3of5' style=' float: left;

                                                     width: 54%;

                                                     margin-top: 8px;

                                                     margin-left: 0px;' >        

                                                    <table

                                                        style="margin-top:25px; margin-left: 19px; text-align: left; width: 100%;" border="1"

                                                        cellpadding="2" cellspacing="2">

                                                        <!--                    Linear gauge funktionierte einwandfrei, rausgenommen weil die prozentzahl wichtiger
                                                                                <tbody>
                                                        
                                                        
                                                        
                                                                                <tr>
                                                        
                                                                                    <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge2' class='ui-corner-all'></div><div id="gauge2-text"   style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_acceptable") ?></div></td>
                                                        
                                                                                </tr>
                                                        
                                                                                <tr>
                                                        
                                                                                    <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge3' class='ui-corner-all'></div><div id="gauge3-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_survivable") ?></div></td>
                                                        
                                                                                </tr>
                                                        
                                                                                <tr>
                                                        
                                                                                    <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge4' class='ui-corner-all'></div><div id="gauge4-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_fair") ?></div></td>
                                                        
                                                                                </tr>
                                                        
                                                                                                        <tr>
                                                        
                                                                                    <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge1' class='ui-corner-all'></div><div id="gauge1-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_sustainability") ?></div></td>
                                                        
                                                                                </tr>
                                                        
                                                                            </tbody>-->
                                                        <tbody>
                                                            <!--Gauge ohne Balken z. B. gauge2_OB-->



                                                            <tr>

                                                                <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge2_OB_text' class='resultfont'></div><div id="gauge2-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_acceptable") ?><div class="resultfont" id="is_acceptable"></div></div></td>

                                                            </tr>

                                                            <tr>

                                                                <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge3_OB_text' class='resultfont'></div><div id="gauge3-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_survivable") ?><div class="resultfont" id="is_survivable"></div></div></td>

                                                            </tr>

                                                            <tr>

                                                                <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge4_OB_text' class='resultfont'></div><div id="gauge4-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_fair") ?><div class="resultfont" id="is_fair"></div></td>

                                                            </tr>

                                                            <tr>

                                                                <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge1_OB_text' class='resultfont'></div><div id="gauge1-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_sustainability") ?><div class="resultfont" id="is_sustainable"></div></td>

                                                            </tr>


                                                        </tbody>
                                                    </table>

                                                </div> 
                                                <div class='row' style="padding-left:15px">
                                                    <div class="col-xs-12" style="margin-top: -6px" ></div>
                                                    <div class="col-xs-4"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/human.jpg' title='<?php elgg_echo("rel_human") ?>'><span id="txt_human"><?php echo elgg_echo("rel_human") ?></span></div>
                                                    <div class="col-xs-5" style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-left: -10px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/environment.jpg' title='<?php elgg_echo("rel_economy") ?>'><span id="txt_economy"><?php echo elgg_echo("rel_economy") ?></span></div>
                                                    <div class="col-xs-4" style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-left: -30px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/economy.jpg' title='<?php elgg_echo("rel_environment") ?>'><span id="txt_environment"><?php echo elgg_echo("rel_environment") ?></span></div>
                                                </div>
                                                <div class="row" style="padding-left:15px; margin-top: -2px">
                                                    <div class="col-xs-12"></div>
                                                    <div class="col-xs-4" style="font-size:10px;     margin-left: -12px;     color: #6168AE; padding-right: 0px; margin-right: -2px;"><img  style='width:0px; height:0px ; margin-right: 4px;  margin-left: 7px; border:0px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_human") ?>'><span id="txt_human_p"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschpunkte, 1) ?> - <?php echo round($menschPercent, 1) ?>%</span></div>
                                                    <div class="col-xs-5" style="font-size:10px;     color: #6168AE; padding-right: 0px; margin-left: -10px;"><img  style='width:0px; height:0px ; margin-right: 4px;  margin-left: 7px;  border:0px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_economy") ?>'><span id="txt_human_p"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($umweltpunkte, 1) ?> - <?php echo round($umweltPercent, 1) ?>%</span></div>
                                                    <div class="col-xs-4"  style="font-size:10px;     color: #6168AE; padding-right: 0px; margin-left: -30px;"><img  style='width:0px; height:0px ; margin-right: 4px; margin-left: 7px;   border:0px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_environment") ?>'><span id="txt_human_p"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($wirtschaftpunkte, 1) ?> - <?php echo round($wirtschaftPercent, 1) ?>%</span></div>
                                                </div>   
                                                <div class='row' style="padding-left:15px; margin-top: 5px">
                                                    <div class="col-xs-11" ></div>
                                                    <div class="col-xs-11"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px; line-height: 11px;   margin-bottom: 2px;"><span id="txt_rated"><?php echo elgg_echo("rel_rated_2") ?></span></div>
                                                    <div class="col-xs-11"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px; line-height: 11px;   margin-bottom: 6px;"><span id="txt_bonitaet"><?php echo elgg_echo("rel_bonitaet_2") ?></span></div>

                                                </div>                                                            

                                            </div>

                                            <hr class="styleblue"></hr><div class="stylebluedisclaimer"><?php echo elgg_echo('rel_calculated_by') ?></div>
                                        </div>  </div>

                                </div>

                                <!--                                    <div class="row text">
                                                                        <h5>Benutze Snapshot für deine Dokumentation</h5>
                                                                    </div>-->

                        </div></div> Mit Rating

                    <!--Anfang Clip-->
                    <div class="container con-des" >

                        <div class="container-fluid cf-padding boder-padding" >

                            <div class="panel panel-default  col-md-12" >
                                <div class="panel-design-white-border">
                                    <div class="panel-body panel-design " style="background-color: white;">
                                        <span class="text-s3-rating" style="color: #3a6cac;"><?php echo elgg_echo('rel_sustainability_sub') ?>:&nbsp;<span class="total_percentage" style="color: #3a6cac;font-weight: bold">0.0%</span></span>
                                        <span class="space-text-s3-rating" ><?php echo elgg_echo('rel_rating') ?>:&nbsp;<img id="ratingcode_img" src="<?php echo $site_url ?>mod/reuleaux/images/codes/2.jpg" class="img-size rating_image this_hide_cls" ></span><br>


                                        <div class="row">
                                            <div class="col-sm-5 col-xs-5">

                                                <div  style=" margin-top:8px; margin-left:0px; padding: 0;   " id="derp"></div>

                                            </div>






                                            <div class='elgg-col elgg-col-3of5' style=' float: left;

                                                 width: 54%;

                                                 margin-top: 8px;

                                                 margin-left: 0px;' >        

                                                <table

                                                    style="margin-top:25px; margin-left: 19px; text-align: left; width: 100%;" border="1"

                                                    cellpadding="2" cellspacing="2">

                                                    <!--                    Linear gauge funktionierte einwandfrei, rausgenommen weil die prozentzahl wichtiger
                                                                            <tbody>
                                                    
                                                    
                                                    
                                                                            <tr>
                                                    
                                                                                <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge2' class='ui-corner-all'></div><div id="gauge2-text"   style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_acceptable") ?></div></td>
                                                    
                                                                            </tr>
                                                    
                                                                            <tr>
                                                    
                                                                                <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge3' class='ui-corner-all'></div><div id="gauge3-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_survivable") ?></div></td>
                                                    
                                                                            </tr>
                                                    
                                                                            <tr>
                                                    
                                                                                <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge4' class='ui-corner-all'></div><div id="gauge4-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_fair") ?></div></td>
                                                    
                                                                            </tr>
                                                    
                                                                                                    <tr>
                                                    
                                                                                <td><div style='float: left;  margin-top: -8px' display= 'inline' id='gauge1' class='ui-corner-all'></div><div id="gauge1-text"  style="color: #3a6cac; font-weight:normal; font-size: 12px;padding-top: 1px;"><?php echo elgg_echo("rel_sustainability") ?></div></td>
                                                    
                                                                            </tr>
                                                    
                                                                        </tbody>-->
                                                    <tbody>
                                                        <!--Gauge ohne Balken z. B. gauge2_OB-->



                                                        <tr>

                                                            <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/acceptable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge2_OB_text' class='resultfont'></div><div id="gauge2-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_acceptable") ?><div class="resultfont" id="is_acceptable"></div></div></td>

                                                        </tr>

                                                        <tr>

                                                            <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/ecosensitive.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge3_OB_text' class='resultfont'></div><div id="gauge3-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_survivable") ?><div class="resultfont" id="is_survivable"></div></div></td>

                                                        </tr>

                                                        <tr>

                                                            <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge4_OB_text' class='resultfont'></div><div id="gauge4-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_fair") ?><div class="resultfont" id="is_fair"></div></td>

                                                        </tr>

                                                        <tr>

                                                            <td><img  style='width:7px; height:7px ; margin-right: 10px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/sustainable.jpg' title='<?php elgg_echo("rel_acceptable") ?>'><div style='display: inline;  font-size: 11px; display: inline' id='gauge1_OB_text' class='resultfont'></div><div id="gauge1-text"   style="display: inline ;color: #3a6cac; font-weight:normal; font-size: 11px;"><?php echo elgg_echo("rel_sustainability") ?><div class="resultfont" id="is_sustainable"></div></td>

                                                        </tr>


                                                    </tbody>
                                                </table>

                                            </div> 
                                            <div class='row' style="padding-left:15px">
                                                <div class="col-xs-12" style="margin-top: -6px" ></div>
                                                <div class="col-xs-4"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/human.jpg' title='<?php elgg_echo("rel_human") ?>'><span id="txt_human"><?php echo elgg_echo("rel_human") ?></span></div>
                                                <div class="col-xs-5" style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-left: -10px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/environment.jpg' title='<?php elgg_echo("rel_economy") ?>'><span id="txt_economy"><?php echo elgg_echo("rel_economy") ?></span></div>
                                                <div class="col-xs-4" style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-left: -30px;"><img  style='width:7px; height:7px ; margin-right: 8px;   border:1px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/economy.jpg' title='<?php elgg_echo("rel_environment") ?>'><span id="txt_environment"><?php echo elgg_echo("rel_environment") ?></span></div>
                                            </div>
                                            <div class="row" style="padding-left:15px; margin-top: -2px">
                                                <div class="col-xs-12"></div>
                                                <div class="col-xs-4" style="font-size:10px;     margin-left: -12px;     color: #6168AE; padding-right: 0px; margin-right: -2px;"><img  style='width:0px; height:0px ; margin-right: 4px;  margin-left: 7px; border:0px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_human") ?>'><span id="txt_human_p"><?php echo round($menschmaxpunkte, 1) ?>/<?php echo round($menschpunkte, 1) ?> - <?php echo round($menschPercent, 1) ?>%</span></div>
                                                <div class="col-xs-5" style="font-size:10px;     color: #6168AE; padding-right: 0px; margin-left: -10px;"><img  style='width:0px; height:0px ; margin-right: 4px;  margin-left: 7px;  border:0px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_economy") ?>'><span id="txt_human_p"><?php echo round($umweltmaxpunkte, 1) ?>/<?php echo round($umweltpunkte, 1) ?> - <?php echo round($umweltPercent, 1) ?>%</span></div>
                                                <div class="col-xs-4"  style="font-size:10px;     color: #6168AE; padding-right: 0px; margin-left: -30px;"><img  style='width:0px; height:0px ; margin-right: 4px; margin-left: 7px;   border:0px solid whitesmoke' src='<?php echo $elgg_site_url ?>/mod/reuleaux/images/icons/fair.jpg' title='<?php elgg_echo("rel_environment") ?>'><span id="txt_human_p"><?php echo round($wirtschaftmaxpunkte, 1) ?>/<?php echo round($wirtschaftpunkte, 1) ?> - <?php echo round($wirtschaftPercent, 1) ?>%</span></div>
                                            </div>   
                                            <div class='row' style="padding-left:15px; margin-top: 5px">
                                                <div class="col-xs-11" ></div>
                                                <div class="col-xs-11"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px; line-height: 11px;   margin-bottom: 2px;"><span class="txt_rated"><?php echo elgg_echo("rel_rated_2") ?></span></div>
                                                <div class="col-xs-11"  style="font-size:11px;     color: #6168AE; padding-right: 0px; margin-right: -2px; line-height: 11px;   margin-bottom: 6px;"><span class="txt_bonitaet"><?php echo elgg_echo("rel_bonitaet_2") ?></span></div>

                                            </div>                                                            

                                        </div>

                                        <hr class="styleblue"></hr><div class="stylebluedisclaimer"><?php echo elgg_echo('rel_calculated_by') ?></div>
                                    </div>  </div>

                            </div>

                            <!--                                    <div class="row text">
                                                                    <h5>Benutze Snapshot für deine Dokumentation</h5>
                                                                </div>-->

                        </div></div> 
                    <!--Ende Clip-->
                    Mit Rating   

                    <!-- CSS Code: Place this code in the document's head (between the 'head' tags) -->



                    Mit Rating  
</div></div> </div> </div></div> 
                    <!--Ausgabe img-->

                    <div class="container con-des" >
                            <div class="row" >
                                <div class=" col-md-12" >
                                    <button type="button" id="go-back" class="btn btn-block button-step-3" style="    top: -10px; display:none"><?php echo elgg_echo('rel_btn_back')?></button>
                             </div>
                       
                            </div>       </div>   
                   
         
                    <!-- img bis elgg-body -->
                 
                 
                         <div id="img-out" style='display:none; background-color: white'  >
                    </div>         
<?php
