



<?php
// require_once(dirname(dirname(dirname(__FILE__))) . "/mod/audit/vendors/external/tcpdf/tcpdf.php");



$css_url = 'mod/reuleaux/vendors/bootstrap.min.css';
elgg_register_css('bootstrap', $css_url, 500);
elgg_load_css('bootstrap');

$css_url = 'mod/reuleaux/vendors/reuleaux_style.css';
elgg_register_css('reuleaux_style', $css_url, 500);
elgg_load_css('reuleaux_style');

//$css_url = 'mod/reuleaux/vendors/style_IE.css';
//elgg_register_css('style_IE', $css_url, 500);
//elgg_load_css('style_IE');

$css_url = 'mod/reuleaux/vendors/flags.css';
elgg_register_css('flags', $css_url, 500);
elgg_load_css('flags');

//$js_url = 'mod/reuleaux/vendors/calculatorentry.js';
//elgg_register_js('calculator', $js_url, 'head', 500);
//elgg_load_js('calculator');

$js_url = 'mod/reuleaux/vendors/bootstrap.min.js';
elgg_register_js('bootstrap', $js_url, 'head', 500);
elgg_load_js('bootstrap');
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script type="text/javascript">
        $(document).ready(function () {
            $(".error").hide();
            $("#check-input").attr("disabled", true);
            step2 = false;
            $(".form-input-set").val('');
            $(".form-input-set").on("keyup", function () {
                $(".error").hide();

                if (!$.isNumeric($(this).val())) {
                    $(this).parent().find(".error").html("only numbers allowed").show();
                    $(this).val('');
                    return;
                }

                var check = $(".form-input-set").filter(function () {
                    return $.trim($(this).val()) === '';

                });

                if (!check.length) {
                    $("#check-input").attr("disabled", false);
                    if (step2 === true) {
                        $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>');
                    }
                } else {
                    $("#check-input").attr("disabled", true);
                    if (step2 === true) {
                        $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
                    }
                }

            });

            $(".form-input-seth").on("keyup", function () {
                $(".error").hide();
                    if (!$.isNumeric($(this).val())) {
                        $(this).parent().find(".error").html("only numbers allowed").show();
                        $(this).val('');
                        return;
                    }

                    // hidden points fields
                    var checkh = $(".form-input-seth").filter(function () {
                        return $.trim($(this).val()) === '';

                    });
                    if (!checkh.length) {
                        $("#check-input").attr("disabled", false);
                        if (step2 === true) {
                      //      $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>');
                        }
                    } else {
                        $("#check-input").attr("disabled", true);
                        if (step2 === true) {
                   //         $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
                        }
                    }
                
            });


            $('.btn-primary').click(function () {
                $('.btn-primary').not(this).removeClass('active'); // remove buttonactive from the others
                $(this).toggleClass('active'); // toggle current clicked element
                $("#was").attr("value", $(this).attr('id'));

                if ($(this).attr('id') === 'percent') {
                    alert($(this).attr('id'));
                    $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_percent'); ?>');
                    $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_percent'); ?>');
                    step2 = false;
                         $(".form-input-set").attr('type','text');
                        $(".form-input-seth").attr('type','hidden');                   
                }
                if ($(this).attr('id') === 'points') {
                    $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_points'); ?>');
                    $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>');
 $(".form-input-set").attr('type','text');
                        $(".form-input-seth").attr('type','hidden');                      
                        step2 = true;


//                        checkpoints();
                      
                   

                }
            });

        });
        function isValidForm() {
            if ('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>' === $("#check-input").text()) {
                        $(".form-input-seth").attr('type','text');
                        $(".form-input-set").attr('type','hidden');
                              $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
                            $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_step2'); ?>');  
              return false;              
            }
            return true;
        }

        function setLanguage(lang_id) {
            setCookie("client_language", lang_id, 30);
            document.location.href = document.location.href;
        }
        function setCookie(c_name, value, expiredays) {
            var exdate = new Date();
            exdate.setDate(exdate.getDate() + expiredays);
            document.cookie = c_name + "=" + escape(value) + ";Path=/" + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
        }
        function checkpoints () {
                                    var check = $(".form-input-set").filter(function () {
                        return $.trim($(this).val()) === '';

                    });
                    if (!check.length) {
                        $("#check-input").attr("disabled", false);
                        if (step2 === true) {
                            $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step1'); ?>');
                            $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_points'); ?>');
                        }
                    } else {
                        $("#check-input").attr("disabled", true);
                        if (step2 === true) {
                            $("#check-input").text('<?php echo elgg_echo('rel_btn_calculate_step2'); ?>');
                            $("#label_hint").text('<?php echo elgg_echo('rel_label_hint_step2'); ?>');
                        }
                    }
        }

</script>
<div class="elgg-page-body">
    <div class="elgg-inner">
        <div class="elgg-layout elgg-layout-one-column clearfix">
            <div class="elgg-body elgg-main">
                <div class="container con-des">
                    <header>
                        <div class="container con-des clearfix">
                            <div class="row">
                                <div class="col-xs-7 header-text" style="color:blue;     margin-right: 0px;   padding-right: 0px;   margin-left: 15px;">
                                    <span class="clsfontsmall"><?php echo elgg_echo('rel_main_label') ?></span>
                                    <br>
                                    <span class="bold clsfontsmalltext"><?php echo elgg_echo('rel_main_label_sub') ?></span>
                                </div>
                                <div class="col-xs-4">
                                    <img src="<?php echo $site_url ?>mod/reuleaux/images/reuleaux-logo.png" alt="logo" class="img-responsive logo groesser">
                                </div>                                             
                            </div>
                        </div>
                        <!--        $(“#Opt2”).attr(“checked”, true);
$(“#Opt2”).wijradio(“refresh”);-->
                    </header>
                    <div class="container-fluid cf-padding">
                        <div class="row well well-sm bgbutton panel-padding" data-toggle="buttons">
                            <div class="col-xs-7 text-right"> 
                                <button type="button" id="percent" class="btn btn-primary active btn-prozent"><?php echo elgg_echo('rel_btn_percent') ?></button>
                            </div>
                            <div class="col-xs-5  btn-padding">
                                <button type="button" id="points" class="btn btn-primary btn-punkte"><?php echo elgg_echo('rel_btn_points') ?></button>
                            </div>
                        </div>
                        <?php
                        elgg_view('input/securitytoken');
                        $url = elgg_add_action_tokens_to_url("http://reuleauxcalculator/action/compute");
                        ?>
                        <form id="calculator" name="calculator" action="<?php echo $url ?>" enctype="multipart/form-data"  onsubmit="return isValidForm()" method="post" >
                            <div class="panel panel-default form-box col-md-12">
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-7 wps-padding-top">
                                            <span class="form-icon"><i class="fa fa-smile-o" aria-hidden="true"></i></span> 
                                            <span class="wps-form-right-txt bold box-text"><?php echo elgg_echo('rel_human_short'); ?></span> 
                                        </div>
                                        <div class="col-xs-5">
                                            <input type="text" name="mensch" id="mensch" class="form-control form-input-set">
                                            <input type="hidden" name="menschh" id="menschh" class="form-control form-input-seth">
                                            <div class="error"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-xs-7 wps-padding-top"> 
                                            <span class="form-icon"><i class="fa fa-globe" aria-hidden="true"></i></span>
                                            <span class="wps-form-right-txt bold box-text"><?php echo elgg_echo('rel_environment_short'); ?></span> 
                                        </div>                                                     
                                        <div class="col-xs-5"> 
                                            <input type="text" name="umwelt" id="umwelt" class="form-control form-input-set">
                                            <input type="hidden" name="umwelth" id="umwelth" class="form-control form-input-seth">
                                            <div class="error"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body"> 
                                    <div class="row">
                                        <div class="col-xs-7 wps-padding-top"> 
                                            <span class="form-icon wps-icon"><i class="fa fa-usd" aria-hidden="true"></i></span> 
                                            <span class="wps-form-right-txt bold box-text form-right-txt"><?php echo elgg_echo('rel_economy_short'); ?></span> 
                                        </div>                                                     
                                        <div class="col-xs-5">
                                            <input type="text" name="wirtschaft" id="wirtschaft" class="form-control form-input-set">
                                            <input type="hidden" name="wirtschafth" id="wirtschafth" class="form-control form-input-seth">
                                            <div class="error"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class=" col-md-12">
                                    <!--btn btn-block button-->
                                    <input type="hidden" name="was" id="was" value="percent">
                                    <button type="submit" id="check-input"  class="btn btn-block button"><?php echo elgg_echo('rel_btn_calculate_percent'); ?></button>
                                </div>
                            </div>                                         
                        </form>
                        <div class="row text" id="label_hint">
                            <h5><?php echo elgg_echo('rel_label_hint_percent'); ?></h5>
                        </div>
                        <footer>
                            <div class="container-fluid  footer-text">
                                <div class="col-md-4 col-xs-4 footer-drop">
                                    <p> <a style="font-size: 12px;" href="http://reuleaux-calculator.eu/reul/rating-codes.php"><?php echo elgg_echo('rel_label_link_ratingcodes'); ?></a></p>
                                </div>
                                <div class="col-md-4 col-xs-4 footer-drop-center">
                                    <!--<div id="options"  data-input-name="country2" data-selected-country="GB" class="flagstrap">
                            <select id="flagstrap-7V8EghLo" name="country2" style="display: none;"><option value="">Please select country</option><option value="AU">Australia</option><option value="GB" selected="selected">United Kingdom</option><option value="US">United States</option></select><button type="button" style="margin-left: -14px;" data-toggle="dropdown" id="flagstrap-drop-down-7V8EghLo" class="btn btn-info btn-sm dropdown-toggle" aria-expanded="false"><span class="flagstrap-selected-7V8EghLo"><i class="flagstrap-icon flagstrap-gb" style="margin-right: 10px;"></i>United Kingdom</span><span class="caret" style="margin-left: 10px;"></span></button><ul id="flagstrap-drop-down-7V8EghLo-list" aria-labelled-by="flagstrap-drop-down-7V8EghLo" class="dropdown-menu"><li><a data-val="">Please select country</a></li><li><a data-val="AU"><i class="flagstrap-icon flagstrap-au" style="margin-right: 10px;"></i>Australia</a></li><li><a data-val="GB"><i class="flagstrap-icon flagstrap-gb" style="margin-right: 10px;"></i>United Kingdom</a></li><li><a data-val="US"><i class="flagstrap-icon flagstrap-us" style="margin-right: 10px;"></i>United States</a></li></ul></div>
                                    -->

                                    <div class='language_selector'>
                                        <a href='javascript:setLanguage("en");' title='Englisch'>
                                            <img src='http://reuleauxcalculator/mod/language_selector/_graphics/flags/en.gif' alt='Englisch' title='Englisch'>
                                        </a>                                                                                                                                                             | 
                                        <img src='http://reuleauxcalculator/mod/language_selector/_graphics/flags/de.gif' alt='Deutsch' title='Deutsch'> | 
                                        <a href='javascript:setLanguage("es");' title='Spanisch'>
                                            <img src='http://reuleauxcalculator/mod/language_selector/_graphics/flags/es.gif' alt='Spanisch' title='Spanisch'>
                                        </a>
                                    </div>                                                 
                                </div>
                                <div class="col-md-4 col-xs-4 footer-drop">
                                    <p class="float-right"><a style="font-size: 12px;" href="http://reuleaux-calculator.eu/reul/impressum.php"><?php echo elgg_echo('rel_label_link_impressum'); ?></a></p>
                                </div>
                            </div>
                        </footer>
                    </div>                                 
                </div>

            </div>
        </div>
    </div>
</div>