<?php

/*
 * reuleaux-diagram calculator 
 * elgg-plugin
 * @purpose transform soziocultur, economy and ecology to sustainability
 * with sustainability metrics that are used in the quality-management system
 * @autor manfred salomon 
 * revision 27.07.2017
 * @link http://reuleaux-calculator.eu
 * 
 */
Global $CONFIG;

                                                $tokenID = get_input('goforit');
                        $audit_candidate = get_input('textinput');
                        $audit_link = get_input('textinput2');
                        $inputtextarea_en = get_input('inputtextarea_en');
                        $inputtextarea_de = get_input('inputtextarea_de');
                        $inputtextarea_fr = get_input('inputtextarea_fr');
                        $inputtextarea_es = get_input('inputtextarea_es');
                        $inputtextarea_it = get_input('inputtextarea_it');
                        $inputtextarea_nl = get_input('inputtextarea_nl');
                        $vars['audit_candidate'] =$audit_candidate ;
                        $vars['audit_link'] =$audit_link ;
                        $vars['audit_text'] = $audit_text;
                        $date_called = date("Y-m-d H:i:s");
                        $vars['audit_text'] = get_input('inputtextarea_' . get_language());

                        $query_data = "SELECT rel_query.*
FROM (rel_query INNER JOIN elgg_entities ON rel_query.file_guid = elgg_entities.guid) INNER JOIN elgg_entity_subtypes ON elgg_entities.subtype = elgg_entity_subtypes.id
WHERE (((rel_query.tokenID)='{$tokenID}') AND ((elgg_entity_subtypes.subtype)='file'));";
                        $result_data = get_data($query_data);
                        if ($result_data [0]->ID != Null) {
                        $ret = update_data("DELETE rel_query
FROM rel_query INNER JOIN elgg_entities ON rel_query.file_guid = elgg_entities.guid
                        WHERE ((rel_query.ID)!='{$result_data [0]->ID}') AND ((rel_query.tokenID)='{$tokenID}');");}
//                        If (($how_much =2) && (isset($audit_cadidate)) && (isset($audit_text))) {
                        $ret = update_data("update rel_query set file_guid = Null,  called=2,image_guid = Null, audit_text_en = '{$inputtextarea_en}'  ,audit_text_de = '{$inputtextarea_de}' ,audit_text_fr = '{$inputtextarea_fr}' ,audit_text_es = '{$inputtextarea_es}' ,audit_text_it = '{$inputtextarea_it}' , audit_text_nl = '{$inputtextarea_nl}' , change_date = '{$date_called}' ,audit_link = '{$audit_link}' ,audit_candidate = '{$audit_candidate}' WHERE tokenID = '{$tokenID}';");
//           }
//$result_data = "SELECT * from rel_query INNER JOIN elgg_entities ON rel_query.file_guid = elgg_entities.guid  WHERE ((elgg_entities.type)='file') and (rel_query.tokenID = '{$tokenID}');";
$file_entities = "SELECT elgg_metadata.entity_guid, elgg_metastrings_1.string,elgg_metastrings.string
FROM elgg_metastrings INNER JOIN elgg_metadata ON elgg_metastrings.id = elgg_metadata.name_id INNER JOIN elgg_metastrings AS elgg_metastrings_1 ON elgg_metadata.value_id = elgg_metastrings_1.id
GROUP BY elgg_metadata.entity_guid, elgg_metastrings.string, elgg_metastrings_1.string
HAVING (((elgg_metastrings.string)='rel_token') AND ((elgg_metastrings_1.string)='{$tokenID}'));";                     
                        $array_audits = get_data($file_entities);
                        $the_one = $result_data [0]->ID;
                        if ($array_audits) {
                                foreach ($array_audits as $data_row) {
                                        
                               
                                
                                 $access = elgg_set_ignore_access(true);
                                 if ($the_one <> $data_row->entity_guid) {
                                         $audit_file_entity = get_entity($data_row->entity_guid);
                                $audit_file_entity->delete();
                                 }
                                 $access = elgg_set_ignore_access(false);
                                      }   
                        }
    
$uploaded_files = elgg_get_uploaded_files('upload');                        
if (!$uploaded_files) {
        register_error("No PDF-file was uploaded");
  //      forward(REFERER);
}
else {
$uploaded_file = array_shift($uploaded_files);
if (!$uploaded_file->isValid()) {
        $error = elgg_get_friendly_upload_error($uploaded_file->getError());
        register_error($error);
//        forward(REFERER);
}

$supported_mimes = [
        'application/pdf'
];

$mime_type = ElggFile::detectMimeType($uploaded_file->getPathname(), $uploaded_file->getClientMimeType());
if (!in_array($mime_type, $supported_mimes)) {
        register_error("$mime_type is not supported");
 //       forward(REFERER);
}

$file = new ElggFile();
        $file->owner_guid = 36;
$file->access_id =2;

if ($file->acceptUploadedFile($uploaded_file)) {

$file->rel_token =$tokenID;

 $access = elgg_set_ignore_access(true);
        $file->save();
         $guid = $file->guid;
         $ret = update_data("update `rel_query` set file_guid = '{$guid}'  WHERE tokenID = '{$tokenID}';");
          $access = elgg_set_ignore_access(false);
}
}

//////////////////////////////////////////////////////


$uploaded_files = elgg_get_uploaded_files('upload2');                        
if (!$uploaded_files) {
        register_error("No image-file was uploaded");
 //       forward(REFERER);
}
else {

$uploaded_file = array_shift($uploaded_files);
if (!$uploaded_file->isValid()) {
        $error = elgg_get_friendly_upload_error($uploaded_file->getError());
        register_error($error);
 //       forward(REFERER);
}

$supported_mimes = [
        'image/jpeg',
        'image/png',
        'image/gif',
];

$mime_type = ElggFile::detectMimeType($uploaded_file->getPathname(), $uploaded_file->getClientMimeType());
if (!in_array($mime_type, $supported_mimes)) {
        register_error("$mime_type is not supported");
 //       forward(REFERER);
}

$file2 = new ElggFile();
        $file2->owner_guid = 36;
$file2->access_id =2;

if ($file2->acceptUploadedFile($uploaded_file)) {

$file2->rel_token =$tokenID;

 $access = elgg_set_ignore_access(true);
        $file2->save();
         $guid2 = $file2->guid;
         $file2->close();
                $dir = new \Elgg\EntityDirLocator(36);
		$filename = $file2->getFilenameOnFilestore();
		$filepath = $file2->filename;
                	$params = array(
                            'upscale' => true,
                            'square' => true,
                            'w'=>960,
                            'h'=>960);
                        $success = _elgg_services()->imageService->resize($filename,null,$params);

 //	$filename = $filehandler->getFilenameOnFilestore();
//
//	$sizes = array('tiny', 'small', 'medium', 'large', 'master');
//
//	$thumbs = array();
//	foreach ($sizes as $size) {
//		$thumbs[$size] = get_resized_image_from_existing_file(
//			$filename,
//			$icon_sizes[$size]['w'],
//			$icon_sizes[$size]['h'],
//			$icon_sizes[$size]['square']        
         $ret = update_data("update `rel_query` set image_guid = '{$guid2}'  WHERE tokenID = '{$tokenID}';");
          $access = elgg_set_ignore_access(false);
}
}
forward($CONFIG->wwwroot . "result/" . $tokenID);
