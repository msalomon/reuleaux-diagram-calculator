<?php

/*
 * reuleaux-diagram calculator 
 * elgg-plugin
 * @purpose transform soziocultur, economy and ecology to sustainability
 * with sustainability metrics that are used in the quality-management system
 * @autor manfred salomon 
 * revision 27.07.2017
 * @link http://reuleaux-calculator.eu
 * 
 */
Global $CONFIG;
$ts = get_input('__elgg_ts');
$tokenID = get_input('__elgg_token');
$MenschProzent = (float) get_input('mensch');
$UmweltProzent = (float) get_input('umwelt');
$WirtschaftProzent = (float) get_input('wirtschaft');
$MenschPunkte = (int) get_input('mensch');
$UmweltPunkte = (int) get_input('umwelt');
$WirtschaftPunkte = (int) get_input('wirtschaft');
$MenschMaxPunkte = (int) get_input('menschh');
$UmweltMaxPunkte = (int) get_input('umwelth');
$WirtschaftMaxPunkte = (int) get_input('wirtschafth');
$CalcWhat = get_input('was');
switch ($CalcWhat) {

        case "btn_points":
                $MenschProzent = (float) (100 / $MenschMaxPunkte) * (int)$MenschProzent; // Prozentfeld des Formulars wird auch als Punktefeld benutzt
                $UmweltProzent = (float) (100 / $UmweltMaxPunkte) * (int)$UmweltProzent;
                $WirtschaftProzent = (float) (100 / $WirtschaftMaxPunkte) * (int)$WirtschaftProzent;
}
// Beweis der Richtigkeit der Formeln
$p_standard = 116 / 100 * 100;                                               // 100 Prozent = 115.99999999999999
$f_standard = 42251.84 / 116 * $p_standard;                                   // 100 Prozent Fläche = 42251.899999999999  
$r_standard = sqrt($f_standard / 3.14);

// Brechnung des Radius aus X-Prozent Fläche vom Kreis
$p_human = 116 / 100 * $MenschProzent;     // ? Radius bei X Prozent Mensch e. g. 50% = 57.99999999999999
$f_human = 42251.84 / 116 * $p_human;                                         // Entprechen f_human-Fläche e. g. 50% = 21125.919999999995
$r_human = sqrt($f_human / 3.14);                                        // e. g. 50% Fläche = 21125.919999999995 entsprechen 82.02438661763951 Radius

$p_environment = 116 / 100 * $UmweltProzent;
$f_environment = 42251.84 / 116 * $p_environment;
$r_environment = sqrt($f_environment / 3.14);

$p_economic = 116 / 100 * $WirtschaftProzent;
$f_economic = 42251.84 / 116 * $p_economic; // FlÃ¤che
$r_economic = sqrt($f_economic / 3.14);  // Radius


$r_116 = 116;                                                                        // 
$f_116 = rel_areaOfIntersection(116, 0, 116, 116 + 116, 0, 116);                // Schnittflächen 100%
$a_max = $f_116;

$is_survivable = round(rel_areaOfIntersection(116, 0, $r_economic, 116 + 116, 0, $r_environment), 1); // Wirtschaft/Umwelt rot/blau / überlebensfähig, umweltbewußt, survivable                                                                                   alert(is_survivable);
$is_survivable_p = ((100 / $a_max * $is_survivable));
$is_survivable_p_t = round($is_survivable_p, 1);

$is_fair = round(rel_areaOfIntersection(116, 0, $r_economic, 174, (((sqrt(3) / 2) * $r_116)), $r_human), 1); // rot/gelb / fair
$is_fair_p = ((100 / $a_max * $is_fair));
$is_fair_p_t = round($is_fair_p, 1);

$is_acceptable = rel_areaOfIntersection(116, 0, $r_environment, 174, (((sqrt(3) / 2) * $r_116)), $r_human); // rot/gelb /acceptable 
$is_acceptable_p = ((100 / $a_max * $is_acceptable));
$is_acceptable_p_t = round($is_acceptable_p, 1);

$s_max = round(rel_intersectionArea($r_standard, $r_standard, $r_standard, $r_standard), 1);
$is_sustainable = round(rel_intersectionArea($r_standard, $r_human, $r_environment, $r_economic), 1);

$is_sustainable_p = ((100 / $s_max * $is_sustainable));
$is_sustainable_p_t = round($is_sustainable_p, 1);

$rating_ext = $is_sustainable_p_t * 0.22;

$rating_ext = round($rating_ext, 1);


switch ($CalcWhat) {
        case "btn_percent":
                $ret = update_data("INSERT INTO `rel_query`(CalcWhat, `MenschProzent`, `UmweltProzent`, `WirtschaftProzent`, `MenschPunkte`, `UmweltPunkte`, `WirtschaftPunkte`, `MenschMaxPunkte`, `UmweltMaxPunkte`, `WirtschaftMaxPunkte`, `tokenID`, r_standard, r_human, r_environment, r_economic,  a_max, is_survivable_p_t, is_fair_p_t, is_acceptable_p_t, s_max, is_sustainable, is_sustainable_p_t, rating_ext,`ts`,called,audit_candidate,change_date,last_call_date) VALUES ('{$CalcWhat}',{$MenschProzent},{$UmweltProzent},{$WirtschaftProzent},{$MenschPunkte},{$UmweltPunkte},{$WirtschaftPunkte},100,100,100,'{$tokenID}',{$r_standard}, {$r_human}, {$r_environment}, {$r_economic}, {$a_max}, {$is_survivable_p_t}, {$is_fair_p_t}, {$is_acceptable_p_t}, {$s_max}, {$is_sustainable}, {$is_sustainable_p_t}, {$rating_ext},{$ts}, 1,null,now(),now());");
                forward($CONFIG->wwwroot . "result/" . $tokenID);
                break;
        case "btn_points":
                 $ret = update_data("INSERT INTO `rel_query`(CalcWhat, `MenschProzent`, `UmweltProzent`, `WirtschaftProzent`, `MenschPunkte`, `UmweltPunkte`, `WirtschaftPunkte`, `MenschMaxPunkte`, `UmweltMaxPunkte`, `WirtschaftMaxPunkte`, `tokenID`, r_standard, r_human, r_environment, r_economic, a_max, is_survivable_p_t, is_fair_p_t, is_acceptable_p_t, s_max, is_sustainable, is_sustainable_p_t, rating_ext, `ts`, called,audit_candidate,change_date,last_call_date) VALUES ('{$CalcWhat}',{$MenschProzent},{$UmweltProzent},{$WirtschaftProzent},{$MenschPunkte},{$UmweltPunkte},{$WirtschaftPunkte},{$MenschMaxPunkte},{$UmweltMaxPunkte},{$WirtschaftMaxPunkte},'{$tokenID}',{$r_standard}, {$r_human}, {$r_environment}, {$r_economic},  {$a_max}, {$is_survivable_p_t}, {$is_fair_p_t}, {$is_acceptable_p_t}, {$s_max}, {$is_sustainable}, {$is_sustainable_p_t}, {$rating_ext},{$ts}, 1,null,null,now(),now());");
                forward($CONFIG->wwwroot . "result/" . $tokenID);
                break;
}
?>
