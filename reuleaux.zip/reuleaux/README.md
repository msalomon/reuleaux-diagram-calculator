Reuleaux Plugin
=============
Check at http://www.reuleaux-calculator.eu/ how the plugin works


Requirements
------------
Use rel_query.sql to make a reuleaux-table in your elgg database
Plugin needed:
custom_index 1.9 (On top of plugin list)
language_selector 2.0.1 by ColdTrick IT Solutions (Above reuleaux plugin) Settings: 20/Yes/Yes/Yes
reuleaux 0.9