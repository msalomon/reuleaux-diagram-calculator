<?php

/*
 * reuleaux-diagram calculator 
 * elgg-plugin
 * @purpose transform soziocultur, economy and ecology to sustainability
 * with sustainability metrics that are used in the quality-management system
 * @autor manfred salomon 
 * revision 27.07.2017
 * @link http://reuleaux-calculator.eu
 * 
 * Core change!!!!! index-page (entryform), init plugin, pagehandler
 */

//In Elgg Core Index-Page auf 'rate' geroutet !!!!
//C:\Users\lisha\Documents\NetBeansProjects\reuleauxcalculator\vendor\elgg\elgg\views\default\resources\index.php
//	forward('rate');


elgg_register_event_handler('init', 'system', 'dashboard_init');
elgg_register_library('elgg:tools', elgg_get_plugins_path() . 'reuleaux/lib/tools.php');
elgg_load_library('elgg:tools');

function dashboard_init() {
        elgg_register_page_handler('result', 'result_page_handler');
        elgg_register_page_handler('rate', 'rate_page_handler');
        elgg_register_page_handler('info', 'info_page_handler');
        elgg_register_page_handler('my', 'my_page_handler');
        elgg_register_page_handler('impressum', 'impressum_page_handler');
        elgg_register_page_handler('en', 'en_page_handler');
        elgg_register_page_handler('de', 'de_page_handler');
        elgg_register_page_handler('fr', 'fr_page_handler');
        elgg_register_page_handler('es', 'es_page_handler');
        elgg_register_page_handler('it', 'it_page_handler');
        elgg_register_page_handler('nl', 'nl_page_handler');
       
        $action_path = elgg_get_plugins_path() . 'reuleaux/actions/reuleaux';
        elgg_register_action("compute", "$action_path/compute.php", "public");
        elgg_register_action("extend", "$action_path/extend.php", "public");
//        elgg_extend_view('elgg.css', 'dashboard/css');
//        elgg_extend_view('elgg.js', 'dashboard/js');
//
//        elgg_register_menu_item('topbar', array(
//            'name' => 'dashboard',
//            'href' => 'dashboard',
//            'text' => elgg_view_icon('home') . elgg_echo('dashboard'),
//            'priority' => 450,
//            'section' => 'alt',
//        ));
}

//Core change !!!


function rate_page_handler($page) {
        if (!isset($page[0])) {
                $page[0] = 'index';
        }
        $page_type = $page[0];
        switch ($page_type) {
                case 'index':
                case 'entry':
                        echo elgg_view_resource('entry');
                        return true;
                        break;
        }
}

function result_page_handler($page) {
        global $CONFIG;
        if (!isset($page[0])) {
                $page[0] = 'index';
        }
        $page_type = $page[0];
        switch ('result') {
                case 'result':
                        if (isset($page[1])) {
                                $hilf = strtolower($page[1]);
                                switch ($hilf) {
                                        case 'de':
                                                $select_language = 'de';
                                                break;
                                        case 'en':
                                                $select_language = 'en';
                                                break;
                                        case 'es':
                                                $select_language = 'es';
                                                break;
                                        case 'it':
                                                $select_language = 'it';
                                                break;
                                        case 'tr':
                                                $select_language = 'tr';
                                                break;
                                        case 'fr':
                                                $select_language = 'fr';
                                                break;
                                        default:
                                                $select_language = 'de';
                                                break;
                                }
                        } else {
                                $select_language = 'de';
                        }
                        if (isset($page[1])) {
                                if (get_language() <> $select_language) {
                                        $new_lang = $_COOKIE['select_language'];
                                        $CONFIG->language = $select_language;
                                        reload_all_translations();
                                }
                        }
                        $vars['select_language'] = $select_language;
                        $result_data = "SELECT image_guid, file_guid,`MenschProzent`, `UmweltProzent`, `WirtschaftProzent`, `MenschPunkte`, `UmweltPunkte`, `WirtschaftPunkte`, MenschMaxPunkte,UmweltMaxPunkte,WirtschaftMaxPunkte,CalcWhat, `tokenID`, r_standard, r_human, r_environment, r_economic, a_max, is_survivable_p_t, is_fair_p_t, is_acceptable_p_t, s_max, is_sustainable, is_sustainable_p_t, rating_ext,`ts`, `ID`,called,last_call_date,audit_text_de,audit_text_en,audit_text_es,audit_text_fr,audit_text_it,audit_text_nl,audit_text_tr,	audit_candidate,change_date FROM `rel_query` WHERE (`tokenID` = '" . $page[0] . "');";
                        $array_points_data = get_data($result_data);
                        switch (get_current_language()) {
                                case 'de':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_de;
                                        break;
                                case 'en':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_en;
                                        break;
                                case 'es':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_es;
                                        break;
                                case 'it':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_it;
                                        break;
                                case 'tr':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_tr;
                                        break;
                                case 'fr':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_fr;
                                        break;
                                default:

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_de;
                                        break;
                        }

                        $vars['tokenID'] = $array_points_data[0]->tokenID;
                        $vars['mensch'] = $array_points_data[0]->MenschProzent;
                        $vars['umwelt'] = $array_points_data[0]->UmweltProzent;
                        $vars['wirtschaft'] = $array_points_data[0]->WirtschaftProzent;
                        $vars['menschpunkte'] = $array_points_data[0]->MenschPunkte;
                        $vars['umweltpunkte'] = $array_points_data[0]->UmweltPunkte;
                        $vars['wirtschaftpunkte'] = $array_points_data[0]->WirtschaftPunkte;
                        $vars['menschmaxpunkte'] = $array_points_data[0]->MenschMaxPunkte;
                        $vars['umweltmaxpunkte'] = $array_points_data[0]->UmweltMaxPunkte;
                        $vars['wirtschaftmaxpunkte'] = $array_points_data[0]->WirtschaftMaxPunkte;
                        $vars['was'] = $array_points_data[0]->CalcWhat;
                        $vars['called'] = $array_points_data[0]->called + 1;
                        $called = $vars['called'];
                        $tokenID = $vars['tokenID'];
                        $ret = update_data("update rel_query set called={$called} WHERE tokenID = '{$tokenID}';");


                        $vars['audit_candidate'] = $array_points_data[0]->audit_candidate;

                        $vars['change_date'] = $array_points_data[0]->change_date;
                        $vars['file_guid'] = $array_points_data[0]->file_guid;
                        $vars['image_guid'] = $array_points_data[0]->image_guid;
                        $file_entity = get_entity($array_points_data[0]->file_guid);
                        $vars['originalfilename'] = $file_entity->originalfilename;
                        $vars['r_standard'] = $array_points_data[0]->r_standard;
                        $vars['r_human'] = $array_points_data[0]->r_human;
                        $vars['r_environment'] = $array_points_data[0]->r_environment;
                        $vars['r_economic'] = $array_points_data[0]->r_economic;
                        $vars['a_max'] = $array_points_data[0]->a_max;
                        $vars['is_survivable_p_t'] = $array_points_data[0]->is_survivable_p_t;
                        $vars['is_fair_p_t'] = $array_points_data[0]->is_fair_p_t;
                        $vars['is_acceptable_p_t'] = $array_points_data[0]->is_acceptable_p_t;
                        $vars['s_max'] = $array_points_data[0]->s_max;
                        $vars['is_sustainable'] = $array_points_data[0]->is_sustainable;
                        $vars['is_sustainable_p_t'] = $array_points_data[0]->is_sustainable_p_t;
                        $vars['rating_ext'] = $array_points_data[0]->rating_ext;

                        switch ((int) $vars['rating_ext']) {
                                case 22:
                                        $vars['ampel_background'] = '#264D22';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#264D22';
                                        break;

                                case 21:
                                        $vars['ampel_background'] = '#387236';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#387236';
                                        break;
                                case 20:
                                        $vars['ampel_background'] = '#387236';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#387236';
                                        break;
                                case 19:
                                        $vars['ampel_background'] = '#387236';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#387236';
                                        break;

                                case 18:
                                        $vars['ampel_background'] = '#4C9947';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#4C9947';
                                        break;
                                case 17:
                                        $vars['ampel_background'] = '#4C9947';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#4C9947';
                                        break;
                                case 16:
                                        $vars['ampel_background'] = '#4C9947';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#4C9947';
                                        break;

                                case 15:
                                        $vars['ampel_background'] = '#9C6A23';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#9C6A23';
                                        break;
                                case 14:
                                        $vars['ampel_background'] = '#9C6A23';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#9C6A23';
                                        break;
                                case 13:
                                        $vars['ampel_background'] = '#9C6A23';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#9C6A23';
                                        break;

                                case 12:
                                        $vars['ampel_background'] = '#C49043';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C49043';
                                        break;
                                case 11:
                                        $vars['ampel_background'] = '#C49043';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C49043';
                                        break;
                                case 10:
                                        $vars['ampel_background'] = '#C49043';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C49043';
                                        break;

                                case 9:
                                        $vars['ampel_background'] = '#C4A16A';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C4A16A';
                                        break;
                                case 8:
                                        $vars['ampel_background'] = '#C4A16A';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C4A16A';
                                        break;
                                case 7:
                                        $vars['ampel_background'] = '#C4A16A';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C4A16A';
                                        break;

                                case 6:
                                        $vars['ampel_background'] = '#E5400F';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#E5400F';
                                        break;
                                case 5:
                                        $vars['ampel_background'] = '#E5400F';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#E5400F';
                                        break;
                                case 4:
                                        $vars['ampel_background'] = '#E5400F';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#E5400F';
                                        break;

                                case 3:
                                        $vars['ampel_background'] = '#CB0107';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#CB0107';
                                        break;
                                case 2:
                                        $vars['ampel_background'] = '#CB0107';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#CB0107';
                                        break;

                                case 1:
                                        $vars['ampel_background'] = '#780003';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#780003';
                                        break;
                                case 0:
                                        $vars['ampel_background'] = '#780003';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#780003';
                                        break;
                                default:
                                        $vars['ampel_background'] = '#780003';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#780003';
                                        break;
                        }

//$vars['ampel_background'] ='#800000'; $vars['ampel_fontcolor'] ='whitesmoke'; $vars['ampel_img_panel'] ='#c0c0c0';
//$vars['ampel_background'] ='#2e7231'; $vars['ampel_fontcolor'] ='lightgrey'; $vars['ampel_img_panel'] ='#c0c0c0';
//                                if ((int)$vars['rating_ext'] <= 22 && (int)$vars['rating_ext'] > 14 ){
//                                $vars['ampel_background']= '#c6fdc6';        
//                                }
//                        if ((int)$vars['rating_ext'] <= 14 && $vars['rating_ext'] > 7){
//                                $vars['ampel_background']= '#fcfdc6';
//                        }
//                        if ((int)$vars['rating_ext'] <= 7){
//                                $vars['ampel_background']= '#fdc6f2';
//                        }
//                         if ((int)$vars['rating_ext'] == 0){
//                                $vars['ampel_background']= '#fdc6f2';                     
//                                } 
                        $intro_message = elgg_view('reuleaux/calcresult', $vars);
                        $title = elgg_echo('rel_main_label_result');
                        $params = array(
                            'content' => $intro_message,
                            'show_access' => false,
                            'title' => false,
                        );
                        $body = elgg_view_layout('', $params);

                        echo elgg_view_page($title, $body);
                        return true;
        }
}

function info_page_handler($page) {
        if (!isset($page[0])) {
                $page[0] = 'index';
        }
        $page_type = $page[0];
        switch ($page_type) {
                case 'index':
                case 'info':
                        echo elgg_view_resource('berechnung');
                        return true;
                        break;
        }
}

function impressum_page_handler($page) {
        if (!isset($page[0])) {
                $page[0] = 'index';
        }
        $page_type = $page[0];
        switch ($page_type) {
                case 'index':
                case 'impressum':
                        echo elgg_view_resource('impressum');
                        return true;
                        break;
        }
}

function my_page_handler($page) {
        // if 'my' has a token
        if (!isset($page[0])) {
                $page[0] = 'index';
        }

        $page_type = $page[0];
        switch ($page_type) {
                case 'index':
                        break;
                case $page_type:
                        if (isset($page[1])) {
                                $hilf = strtolower($page[1]);
                                switch ($hilf) {
                                        case 'de':
                                                $select_language = 'de';
                                                break;
                                        case 'en':
                                                $select_language = 'en';
                                                break;
                                        case 'es':
                                                $select_language = 'es';
                                                break;
                                        case 'it':
                                                $select_language = 'it';
                                                break;
                                        case 'tr':
                                                $select_language = 'tr';
                                                break;
                                        case 'fr':
                                                $select_language = 'fr';
                                                break;
                                        default:
                                                $select_language = 'de';
                                                break;
                                }
                        } else {
                                $select_language = 'de';
                        }
                        if (get_language() == $select_language) {
                                $select_language = '';
                        }
                        $vars['select_language'] = $select_language;
                        $result_data = "SELECT image_guid, file_guid,`MenschProzent`, `UmweltProzent`, `WirtschaftProzent`, `MenschPunkte`, `UmweltPunkte`, `WirtschaftPunkte`, MenschMaxPunkte,UmweltMaxPunkte,WirtschaftMaxPunkte,CalcWhat, `tokenID`, r_standard, r_human, r_environment, r_economic, a_max, is_survivable_p_t, is_fair_p_t, is_acceptable_p_t, s_max, is_sustainable, is_sustainable_p_t, rating_ext,`ts`, `ID`,called,last_call_date,audit_text_de,audit_text_en,audit_text_es,audit_text_fr,audit_text_it,audit_text_nl,audit_text_tr,	audit_candidate,change_date FROM `rel_query` WHERE (`tokenID` = '" . $page[0] . "');";
                        $array_points_data = get_data($result_data);
                        switch (get_language()) {
                                case 'de':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_de;
                                        break;
                                case 'en':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_en;
                                        break;
                                case 'es':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_es;
                                        break;
                                case 'it':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_it;
                                        break;
                                case 'tr':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_tr;
                                        break;
                                case 'fr':

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_fr;
                                        break;
                                default:

                                        $vars['audit_text'] = $array_points_data[0]->audit_text_de;
                                        break;
                        }
                        $vars['tokenID'] = $array_points_data[0]->tokenID;
                        $vars['mensch'] = $array_points_data[0]->MenschProzent;
                        $vars['umwelt'] = $array_points_data[0]->UmweltProzent;
                        $vars['wirtschaft'] = $array_points_data[0]->WirtschaftProzent;
                        $vars['menschpunkte'] = $array_points_data[0]->MenschPunkte;
                        $vars['umweltpunkte'] = $array_points_data[0]->UmweltPunkte;
                        $vars['wirtschaftpunkte'] = $array_points_data[0]->WirtschaftPunkte;
                        $vars['menschmaxpunkte'] = $array_points_data[0]->MenschMaxPunkte;
                        $vars['umweltmaxpunkte'] = $array_points_data[0]->UmweltMaxPunkte;
                        $vars['wirtschaftmaxpunkte'] = $array_points_data[0]->WirtschaftMaxPunkte;
                        $vars['was'] = $array_points_data[0]->CalcWhat;
                        $vars['called'] = $array_points_data[0]->called;



                        $vars['audit_candidate'] = $array_points_data[0]->audit_candidate;

                        $vars['change_date'] = $array_points_data[0]->change_date;
                        $vars['file_guid'] = $array_points_data[0]->file_guid;
                        $vars['image_guid'] = $array_points_data[0]->image_guid;
                        $file_entity = get_entity($array_points_data[0]->file_guid);
                        $vars['originalfilename'] = $file_entity->originalfilename;
                        $vars['r_standard'] = $array_points_data[0]->r_standard;
                        $vars['r_human'] = $array_points_data[0]->r_human;
                        $vars['r_environment'] = $array_points_data[0]->r_environment;
                        $vars['r_economic'] = $array_points_data[0]->r_economic;
                        $vars['a_max'] = $array_points_data[0]->a_max;
                        $vars['is_survivable_p_t'] = $array_points_data[0]->is_survivable_p_t;
                        $vars['is_fair_p_t'] = $array_points_data[0]->is_fair_p_t;
                        $vars['is_acceptable_p_t'] = $array_points_data[0]->is_acceptable_p_t;
                        $vars['s_max'] = $array_points_data[0]->s_max;
                        $vars['is_sustainable'] = $array_points_data[0]->is_sustainable;
                        $vars['is_sustainable_p_t'] = $array_points_data[0]->is_sustainable_p_t;
                        $vars['rating_ext'] = $array_points_data[0]->rating_ext;
                        switch ((int) $vars['rating_ext']) {
                                case 22:
                                        $vars['ampel_background'] = '#264D22';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#264D22';
                                        break;

                                case 21:
                                        $vars['ampel_background'] = '#387236';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#387236';
                                        break;
                                case 20:
                                        $vars['ampel_background'] = '#387236';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#387236';
                                        break;
                                case 19:
                                        $vars['ampel_background'] = '#387236';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#387236';
                                        break;

                                case 18:
                                        $vars['ampel_background'] = '#4C9947';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#4C9947';
                                        break;
                                case 17:
                                        $vars['ampel_background'] = '#4C9947';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#4C9947';
                                        break;
                                case 16:
                                        $vars['ampel_background'] = '#4C9947';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#4C9947';
                                        break;

                                case 15:
                                        $vars['ampel_background'] = '#9C6A23';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#9C6A23';
                                        break;
                                case 14:
                                        $vars['ampel_background'] = '#9C6A23';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#9C6A23';
                                        break;
                                case 13:
                                        $vars['ampel_background'] = '#9C6A23';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#9C6A23';
                                        break;

                                case 12:
                                        $vars['ampel_background'] = '#C49043';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C49043';
                                        break;
                                case 11:
                                        $vars['ampel_background'] = '#C49043';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C49043';
                                        break;
                                case 10:
                                        $vars['ampel_background'] = '#C49043';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C49043';
                                        break;

                                case 9:
                                        $vars['ampel_background'] = '#C4A16A';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C4A16A';
                                        break;
                                case 8:
                                        $vars['ampel_background'] = '#C4A16A';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C4A16A';
                                        break;
                                case 7:
                                        $vars['ampel_background'] = '#C4A16A';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#C4A16A';
                                        break;

                                case 6:
                                        $vars['ampel_background'] = '#E5400F';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#E5400F';
                                        break;
                                case 5:
                                        $vars['ampel_background'] = '#E5400F';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#E5400F';
                                        break;
                                case 4:
                                        $vars['ampel_background'] = '#E5400F';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#E5400F';
                                        break;

                                case 3:
                                        $vars['ampel_background'] = '#CB0107';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#CB0107';
                                        break;
                                case 2:
                                        $vars['ampel_background'] = '#CB0107';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#CB0107';
                                        break;

                                case 1:
                                        $vars['ampel_background'] = '#780003';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#780003';
                                        break;
                                case 0:
                                        $vars['ampel_background'] = '#780003';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#780003';
                                        break;
                                default:
                                        $vars['ampel_background'] = '#780003';
                                        $vars['ampel_fontcolor'] = 'whitesmoke';
                                        $vars['ampel_img_panel'] = '#780003';
                                        break;
                        }
                        echo elgg_view_resource('mystatement', $vars);
                        return true;
                        break;
        }
}

function en_page_handler($page) {
        Global $CONFIG;
        Global $_COOKIE;
        if (!isset($page[0])) {
                echo elgg_view_resource('entry');
        } else {
                $CONFIG->language = 'en';
                $page_type = $page[0];
                switch ($page_type) {
                        case 'impressum':
                                echo elgg_view_resource('impressum');
                                return true;
                                break;
                        case 'info':
                                echo elgg_view_resource('berechnung');
                                return true;
                                break;
                        case 'result':
                                echo elgg_view_resource('result');
                                return true;
                                break;
                        case 'rate':
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                                deault:
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                }
        }
}
function de_page_handler($page) {
        Global $CONFIG;
        if (!isset($page[0])) {
                echo elgg_view_resource('entry');
        } else {
                $CONFIG->language = 'de';
                $page_type = $page[0];
                switch ($page_type) {
                        case 'impressum':
                                echo elgg_view_resource('impressum');
                                return true;
                                break;
                        case 'info':
                                echo elgg_view_resource('berechnung');
                                return true;
                                break;
                        case 'result':
                                echo elgg_view_resource('result');
                                return true;
                                break;
                        case 'rate':
                                echo elgg_view_resource('entry');
                              
                                break;
                                deault:
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                }
        }
}
function es_page_handler($page) {
        Global $CONFIG;
        Global $_COOKIE;

        if (!isset($page[0])) {
                echo elgg_view_resource('entry');
        } else {
                $CONFIG->language = 'es';
                $page_type = $page[0];
                switch ($page_type) {
                        case 'impressum':
                                echo elgg_view_resource('impressum');
                                return true;
                                break;
                        case 'info':
                                echo elgg_view_resource('berechnung');
                                return true;
                                break;
                        case 'result':
                                echo elgg_view_resource('result');
                                return true;
                                break;
                        case 'rate':
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                                deault:
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                }
        }
}
function fr_page_handler($page) {
        Global $CONFIG;
        Global $_COOKIE;

        if (!isset($page[0])) {
                echo elgg_view_resource('entry');
        } else {
                $CONFIG->language = 'fr';
                $page_type = $page[0];
                switch ($page_type) {
                        case 'impressum':
                                echo elgg_view_resource('impressum');
                                return true;
                                break;
                        case 'info':
                                echo elgg_view_resource('berechnung');
                                return true;
                                break;
                        case 'result':
                                echo elgg_view_resource('result');
                                return true;
                                break;
                        case 'rate':
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                                deault:
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                }
        }
}
function it_page_handler($page) {
        Global $CONFIG;
        Global $_COOKIE;

        if (!isset($page[0])) {
                echo elgg_view_resource('entry');
        } else {
                $CONFIG->language = 'it';
                $page_type = $page[0];
                switch ($page_type) {
                        case 'impressum':
                                echo elgg_view_resource('impressum');
                                return true;
                                break;
                        case 'info':
                                echo elgg_view_resource('berechnung');
                                return true;
                                break;
                        case 'result':
                                echo elgg_view_resource('result');
                                return true;
                                break;
                        case 'rate':
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                                deault:
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                }
        }
}
function nl_page_handler($page) {
        Global $CONFIG;
        Global $_COOKIE;

        if (!isset($page[0])) {
                echo elgg_view_resource('entry');
        } else {
                $CONFIG->language = 'nl';
                $page_type = $page[0];
                switch ($page_type) {
                        case 'impressum':
                                echo elgg_view_resource('impressum');
                                return true;
                                break;
                        case 'info':
                                echo elgg_view_resource('berechnung');
                                return true;
                                break;
                        case 'result':
                                echo elgg_view_resource('result');
                                return true;
                                break;
                        case 'rate':
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                                deault:
                                echo elgg_view_resource('entry');
                                return true;
                                break;
                }
        }
}