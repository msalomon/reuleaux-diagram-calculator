#resize_avatars_panel {padding:15px;}
#resize_avatars_panel .elgg-module > .elgg-body {padding:15px;}
#resize_avatars_panel .elgg-input-text {width: 6em!important;}
#icon_table {margin: 2% 2em;}
#icon_table tr, #icon_table {width:100%;}
#icon_table td {padding: 5px;}
.center_p {text-align:center;}